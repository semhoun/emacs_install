#pragma once

#include <vector>
#include <map>

#include "cpptools/nettone_tools_Exception.h"
#include "api_common_StrategyBase.h"


namespace nettone
{
	namespace tools
	{
		class ServerTimer;
	}
}


namespace api
{
	namespace common
	{
		/**
		 * Implement a strategy to select a madiastreamer in a set.
		 * This class is NOT THREADSAFE [FIXME - should be ?].
		 */
		class StrategyRoundRobin
			: public StrategyBase
		{
		public:
			typedef unsigned long ContextId;

			/**
			 * Constructor.
			 */
			StrategyRoundRobin(nettone::tools::ServerTimer* const p_timesource)
				throw ();

			/**
			 * Destructor.
			 */
			virtual ~StrategyRoundRobin()
				throw ();

			/**
			 * @see IStrategy::start
			 */
			virtual void start()
				throw (nettone::tools::Exception);

			/**
			 * @see IStrategy::stop
			 */
			virtual void stop()
				throw ();

			/**
			 * @see IStrategy::requestStop
			 */
			virtual bool requestStop(IStop* const p_handler)
				throw ();

			/**
			 *  @see IStrategy::addRequester
			 */
			virtual void addRequester(IRequester* const p_requester)
				throw (nettone::tools::Exception);

			/**
			 *  @see IStrategy::requestRemoveRequester
			 */
			virtual void requestRemoveRequester(IRequester* const p_requester,
												IRemoveRequester* const p_handler)
				throw (nettone::tools::Exception);

			/**
			 *  @see IStrategy::createContext
			 */
			virtual ContextId createContext()
				throw (nettone::tools::Exception);

			/**
			 *  @see IStrategy::releaseContext
			 */
			virtual void releaseContext(const ContextId& p_cid)
				throw ();

			/**
			 *  @see IStrategy::getNextTarget
			 */
			virtual IRequester* getNextTarget(const ContextId& p_contextId)
				throw (nettone::tools::Exception);

			/**
			 *  @see IStrategy::getCurrentTarget
			 */
			virtual IRequester* getCurrentTarget(const ContextId& p_contextId)
				throw (nettone::tools::Exception);
 
			/**
			 *  @see IStratey::getRequesterNumber
			 */
			virtual int getRequesterNumber() const
				noexcept(true) 
			{
				return m_requesters.size();
			}


		private:
			/// @name Forbidden methods
			/// @{
			StrategyRoundRobin(const StrategyRoundRobin& p_other);
			const StrategyRoundRobin& operator =(const StrategyRoundRobin& p_other);
			/// @}


			/**
			 * Next requester to use in m_requesters
			 */
			unsigned short int  m_requesterIdToUse;

			/**
			 * @var IRequesters m_requesters
			 * Vector of IRequester.
			 */
			typedef std::vector<IRequester*> Requesters;
			Requesters m_requesters;

			/**
			 * @var MapContext m_contextById
			 * Map contexts by id associated to m_requesterIdToUse
			 */
			typedef std::map<ContextId, unsigned short> MapContext;
			MapContext m_contextById;

			/**
			 * Timesource.
			 */
			nettone::tools::ServerTimer* const m_timesource;
		};
	}
}
