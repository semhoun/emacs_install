#pragma once
#include <list>
#include <vector>

#include "cpptools/nettone_tools_ServerTimer.h"
#include "cpptools/nettone_net_ServerTcpClient.h"
#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_Guid.h"


namespace nettone
{
    namespace tools
    {
        class Mutex;
        class ServerDeferred;
    }
}


namespace api
{
    namespace bridge
    {
        /**
         * Api for incas dialog.
         */
        class Server
            : public nettone::net::ServerTcpClient::IConnectionHandler,
              public nettone::net::ServerTcpClient::IReadOpHandler,
              public nettone::net::ServerTcpClient::IWriteOpHandler,
              public nettone::tools::ServerTimer::ITimeout
        {
        public:
            /**
             * Configuration
             */
            struct Config {
                /**
                 * Incas IP
                 */
                std::string serverIP;

                /**
                 * Incas Port
                 */
                unsigned long serverPort;

                /**
                 * Incas query timeout in second
                 */
                unsigned long queryTimeOut;

                /**
                 * Incas keep alive period in second
                 */
                unsigned long keepAlivePeriod;
            };

            /**
             * Constructor.
             */
            Server(const Config& p_conf,
                   nettone::tools::ServerDeferred* p_serverDeferred)
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~Server()
                throw ();

            /**
             * Start the server.
             */
            void start()
                throw (nettone::tools::Exception);

            /**
             * Stop the server.
             */
            void stop()
                throw ();

            /**
             * Message hanswer handler
             */
            class IMessageAnswer
            {
            public:
                struct Result {
                    /**
                     * Src number
                     */
                    std::string srcNum;

                    /**
                     * Src number
                     */
                    std::string srcNumPivot;

                    /**
                     * Src NDI
                     */
                    std::string srcNDI;

                    /**
                     * Src alpha
                     */
                    std::string srcAlpha;

                    /**
                     * Src company id
                     */
                    std::string srcCompanyId;

                    /**
                     * Src company id
                     */
                    std::string srcCompanySearchDN;

                    /**
                     * Src user id
                     */
                    std::string srcUserId;

                    /**
                     * Src geo zone
                     */
                    std::string srcGeoZone;

                    /**
                     * Src clir
                     */
                    bool srcClir;

                    /**
                     * Src hold music id
                     */
                    unsigned long srcHoldMusicId;

                    /**
                     * Src is relayed forced
                     */
                    bool srcRelayedForced;

                    /**
                     * Src is recorded forced
                     */
                    bool srcRecordedForced;

                    /**
                     * Src nat zone
                     */
                    unsigned long srcNatZone;

                    /**
                     * Src must learn addr/ip
                     */
                    unsigned long srcNatLearn;

                    /**
                     * Is redirected call
                     */
                    bool hasRedirect;

                    /**
                     * Redirector number
                     */
                    std::string redirectNum;

                    /**
                     * Redirector alpha
                     */
                    std::string redirectAlpha;

                    /**
                     * Redirector clir
                     */
                    bool redirectClir;

                    /**
                     * Show Redirector
                     */
                    bool redirectShow;

                    /**
                     * Dst alias
                     */
                    std::vector<std::string> dstAlias;

                    /**
                     * Dst num
                     */
                    std::string dstNum;

                    /**
                     * Dst num pivot
                     */
                    std::string dstNumPivot;

                    /**
                     * Src NDI
                     */
                    std::string dstNDI;

                    /**
                     * Dst Alpha
                     */
                    std::string dstAlpha;

                    /**
                     * Dst company id
                     */
                    std::string dstCompanyId;

                    /**
                     * Dst company id
                     */
                    std::string dstCompanySearchDN;

                    /**
                     * Dst user id
                     */
                    std::string dstUserId;

                    /**
                     * Dst geo zone
                     */
                    std::string dstGeoZone;

                    /**
                     * Show destinator
                     */
                    bool dstShow;

                    /**
                     * Dst hold music id
                     */
                    unsigned long dstHoldMusicId;

                    /**
                     * Dst is relayed forced
                     */
                    bool dstRelayedForced;

                    /**
                     * Dst is recorded forced
                     */
                    bool dstRecordedForced;

                    /**
                     * Dst nat zone
                     */
                    unsigned long dstNatZone;

                    /**
                     * Dst must learn addr/ip
                     */
                    unsigned long dstNatLearn;

                    /**
                     * CallId
                     */
                    std::string callId;

                    /**
                     * Ring time out
                     */
                    int timeout;

                    int nodeId;
                    bool hasTrunkInfo;
                    int trunkId;

                    /**
                     * is rejected call
                     */
                    bool isRejected;
                };

                virtual ~IMessageAnswer() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleAnswer(const Result& p_result)
                    throw () = 0;

                /**
                 * Serialize result to string
                 */
                static void serializeResult(const Result& p_from,
                                            std::string& p_dest)
                    throw (nettone::tools::Exception);

                /**
                 * Deserialize result fom string
                 */
                static void deserializeResult(const std::string& p_from,
                                              Result& p_dest)
                    throw (nettone::tools::Exception);
            };

            /**
             * Incoming call message
             */
            struct MessageIncomingCall {
                /**
                 * Call uuid
                 */
                nettone::tools::Guid uuid;

                /**
                 * Caller line id
                 */
                std::string srcLineId;

                /**
                 * Is caller clir
                 */
                bool srcClir;

                /**
                 * Dialed string
                 */
                std::string dialed;

                /**
                 * Has the incoming call been forwarded
                 */
                bool hasForward;

                /**
                 * Number of the last forwarder.
                 */
                std::string lastForward;
            };

            /**
             * Request to send incoming call message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageIncomingCall(const MessageIncomingCall& p_msg,
                                                IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Connect message
             */
            struct MessageConnect {
                /**
                 * CallId
                 */
                std::string callId;
            };

            /**
             * Request to send connect message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageConnect(const MessageConnect& p_msg,
                                           IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Disconnect message
             */
            struct MessageDisconnect {
                /**
                 * CallId
                 */
                std::string callId;

                /**
                 * Is Caller
                 */
                bool isCaller;
            };

            /**
             * Request to send disconnect message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageDisconnect(const MessageDisconnect& p_msg,
                                              IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * TimeOut message
             */
            struct MessageTimeOut {
                /**
                 * CallId
                 */
                std::string callId;
            };

            /**
             * Request to send timeout message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageTimeOut(const MessageTimeOut& p_msg,
                                           IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * NoAnswer message
             */
            struct MessageNoAnswer {
                /**
                 * CallId
                 */
                std::string callId;
            };

            /**
             * Request to send no answer message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageNoAnswer(const MessageNoAnswer& p_msg,
                                            IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Busy message
             */
            struct MessageBusy {
                /**
                 * CallId
                 */
                std::string callId;
            };

            /**
             * Request to send busy message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageBusy(const MessageBusy& p_msg,
                                        IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * NoRoute message
             */
            struct MessageNoRoute {
                /**
                 * CallId
                 */
                std::string callId;
            };

            /**
             * Request to send noRoute message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageNoRoute(const MessageNoRoute& p_msg,
                                           IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Refused message
             */
            struct MessageRefused {
                /**
                 * CallId
                 */
                std::string callId;
            };

            /**
             * Request to send refused message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageRefused(const MessageRefused& p_msg,
                                           IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Divert message
             */
            struct MessageDivert {
                /**
                 * CallId
                 */
                std::string callId;

                /**
                 * Divert to number
                 */
                std::string toNumber;
            };

            /**
             * Request to send divert message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageDivert(const MessageDivert& p_msg,
                                          IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Transfer message
             */
            struct MessageTransfer {
                /**
                 * First CallId
                 */
                std::string callIdA;

                /**
                 * Second CallId
                 */
                std::string callIdB;

                /**
                 * Transferer phone id
                 */
                std::string middleLineId;
            };

            /**
             * Request to send transfer message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessageTransfer(const MessageTransfer& p_msg,
                                            IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Pickup message
             */
            struct MessagePickup {
                /**
                 * CallId
                 */
                std::string callId;

                /**
                 * Pickuper phone id
                 */
                std::string lineId;

                /**
                 * Additional data
                 */
                std::string datas;
            };

            /**
             * Request to send pickup message.
             *
             * @param p_msg Message to send.
             */
            void requestSendMessagePickup(const MessagePickup& p_msg,
                                          IMessageAnswer* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Force tcp connection to reconnect
             */
            void forceReconnect()
                throw(nettone::tools::Exception);

            /**
             * Is connected to incas
             */
            bool isConnected()
                throw();

            /**
             * Transform a result message to a string
             */
            static std::string resultMessage2Str(const IMessageAnswer::Result& p_result)
                throw();

        private:
            /**
             * Add a new message info
             *
             * @param p_messageId Message id
             * @param p_handler handler for answer
             */
            unsigned long pushMessageInfoAndGetId(IMessageAnswer* p_handler)
                throw (nettone::tools::Exception);

            /**
             * Get message answer handler associated to a message id
             *
             * @param p_messageId Message id
             *
             * @return handler for answer
             */
            IMessageAnswer* popMessageInfo(const unsigned long p_messageId)
                throw (nettone::tools::Exception);

            /**
             * Notify all message of error
             * Call when an disconnection occur
             */
            void sendErrorForAllMessage(const std::string& p_error)
                throw();

            /// @see nettone::net::ServerTcpClient
            /// @{
            virtual void handleDisconnect()
                throw();
            virtual void handleConnect()
                throw();
            virtual void handleReadError()
                throw();
            virtual void handleIncomingMessage()
                throw();
            virtual void handleWriteError(const nettone::net::Buffer* const p_buffer,
                                          void* p_key)
                throw();
            virtual void handleOutgoingMessage(void* p_key)
                throw();
            /// @}

            /// @see nettone::tools::ServerTimer
            /// @{
            virtual void handleTimeout(const nettone::tools::ServerTimer::RequestId p_reqId,
                                       void* const p_key,
                                       const unsigned long p_delta)
                throw ();
            /// @}

            /// @name Forbidden methods
            /// @{
            Server(const Server& p_other);
            const Server& operator =(const Server& p_other);
            /// @}

            /**
             * Server TCP.
             */
            std::unique_ptr<nettone::net::ServerTcpClient> m_connection;

            /**
             * @var Requesters m_requesters;
             *
             * Requesters handling MediaStramer instances.
             */
            struct MessageInfo {
                /**
                 * Message Id
                 */
                unsigned long id;

                /**
                 * Date of message sending
                 */
                unsigned long sendedAt;

                /**
                 * Answer handler
                 */
                IMessageAnswer* handler;
            };
            typedef std::list<MessageInfo> MessageInfoList;
            MessageInfoList m_messagesInfo;

            /**
             * Lock used when accessing message info list.
             */
            std::unique_ptr<nettone::tools::Mutex> m_lock;

            /**
             * Next message id
             */
            unsigned long m_messageId;

            /**
             * Last incas keep alive answer
             */
            unsigned long m_lastKeepAliveAnswer;

            /**
             * Configuration
             */
            Config m_config;

            /**
             * Server deferred.
             */
            nettone::tools::ServerDeferred* m_serverDeferred;

            /**
             * Timesource.
             */
            std::unique_ptr<nettone::tools::ServerTimer> m_timesource;

            /**
             * Must stop
             */
            bool m_mustStop;
        };
    }
}
