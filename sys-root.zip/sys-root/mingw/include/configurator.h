// charset=utf-8
#ifndef __CONFIGURATOR_H_
#define __CONFIGURATOR_H_

#include "msg_error.h"

#include <string>         /*pour l'utilisation des strings*/
#include <iostream>
#include <stdio.h>		  /*pour fopen*/
#include <map>            /*pour le tableau associatif*/
#include <sys/types.h>    /*pour fstat et fileno*/
#include <sys/stat.h>     /*pour fstat et fileno*/

//*********************************************************************************************************

class configurator_t
{
public:

    class error : public msg_error_t
    {
    public:
        error(int code=0, const string msg="", int line=0);
        /*		enum {
        			variable_not_found			= -1,
        			wrong_type					= -2,
        			cannot_access_database		= -3,
        			open_file           		= -4,
        			syntax_error				= -6,
        			file_access					= -7,
        			registry_error				= -8
        		};*/
    };

    virtual long get_long(const string name, bool mandatory=true, long def=0);
    virtual bool get_bool(const string name, bool mandatory=true, bool def=true) ;
    virtual string get_string(const string name, bool mandatory=true)=0;
    virtual bool isset(string varName)=0;
    virtual void clear(void) {};
    virtual ~configurator_t(void) {}
};

/*********************************************************************************************************
											parsed_configurator_t

Cette classe parse un fichier config et stocke les paires clé/valeur dans un tableau associatif.

read_file() doit être appelée en premier afin de charger les valeurs à partir du fichier.
Dans le cas oÃ¹ une erreur de type syntax_error est renvoyé, le contenu du message peut être montré à l'utilisateur.

dump() permet de voire le contenu du tableau à des fins de debug

Limitations: la totalité du fichier config est chargée en mémoire d'un coup. Il faut donc que sa taille soit raisonnable.

Syntaxe du fichier:
----------------
# commentaire

clé_1 valeur_1
clé_2 valeur_2
------------
un espace est ' ' ou '\t'
une ligne dont le premier non-espace est un # est un commentaire
une clé se termine par un ou plusieurs (espace ou '=')
une valeur commence soit par un '"' soit par autre chose.
Dans le premier cas tout est pris jusqu'au prochain '"', y compris les retours de ligne. On peut échapper un '"' ou un '\' par un '\'.
Dans le deuxième cas tout est pris jusqu'à la fin de la ligne. Les espaces enfin de ligne sont supprimés. Attention dans ce cas le caracère '\' est normal.

*********************************************************************************************************/

class parsed_configurator_t : public configurator_t
{
public:
    /********************** variables **********************/
    enum DupMode { dm_undef, dm_overwrite, dm_ignore, dm_warning, dm_error } dupMode;
    string recent_file;
    map<string, string> table;

    /********************** fonctions **********************/
    void add_var(string varName, string varVal, int line=0);
    string dump(void);
    string get_string(const string name, bool mandatory=true);
    void clear(void);
    bool isset(string varName);

    void read_url(string url, bool questionMark, DupMode newDupMode=dm_undef);
    void read_env(const string envName, string varName="", DupMode newDupMode=dm_undef);
    void read_param(int argc, char** argv, DupMode newDupMode=dm_undef);
    void read_file(const string fichier, DupMode newDupMode=dm_undef);
    void read_conf(parsed_configurator_t& conf, DupMode newDupMode=dm_undef);

    string autofind_and_load(string envName, int argc, char** argv);	// renvoie le fichier config lu

    parsed_configurator_t(void) : dupMode(dm_error) {}
};

#endif
