#pragma once

#include <list>

#include "cpptools/nettone_tools_Exception.h"
#include "api_common_IStrategy.h"


namespace api
{
	namespace common
	{
		/**
		 * Base strategy implementation
		 */
		class StrategyBase
			: public IStrategy
		{
		public:
			/**
			 * Destructor.
			 */
			virtual ~StrategyBase()
				throw ();

		protected:
			/**
			 * Constructor.
			 */
			StrategyBase();

			/**
			 * Get a context Id
			 */
			ContextId getContextId()
				throw (nettone::tools::Exception);

			/**
			 * Release contextId
			 */
			virtual void releaseContextId(const ContextId& p_cid)
				throw ();

		private:
			/**
			 * Next context id to use
			 */
			ContextId m_nextId;

			/**
			 * List of released ContextId, so reusable
			 */
			std::list<IStrategy::ContextId> m_contextTrash;

			/// @name Forbidden methods
			/// @{
			StrategyBase(const StrategyBase& p_other);
			const StrategyBase& operator =(const StrategyBase& p_other);
			/// @}

		};
	}
}
