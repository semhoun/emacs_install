#ifndef __UDPBRIDGE_API_SERVERLOGGING_H__
#define __UDPBRIDGE_API_SERVERLOGGING_H__


#define MODULE_NAME "udpbridge.api.server"

#define MODULE_LOG_DEBUG 1
#define MODULE_LOG_INFO  1
#define MODULE_LOG_WARN  1
#define MODULE_LOG_ERROR 1
#define MODULE_LOG_FATAL 1


#include "cpptools/nettone_log_Logging.h"


#endif // __UDPBRIDGE_API_SERVERLOGGING_H__
