#ifndef __EVENT_H__
#define __EVENT_H__

#include "adex_class.h"
#include "BeoBuf.h"
#include <vector>

class call_t;

class CallEvent
{
public:

    static char const idPrefix_tty[];
    static char const idPrefix_tty_callcenter[];
    static char const idPrefix_tty_mgcp[];
    static char const idPrefix_tty_sip[];
    static char const idPrefix_tty_waitqueue[];
    static char const idPrefix_tty_group[];
    static char const idPrefix_subst_fax[];
    static char const idPrefix_subst_voice[];
    static char const idPrefix_gw[];
    static char const idPrefix_ivr[];
    static char const idPrefix_conf[];
    static char const idPrefix_user[];

    enum {
        st_Incoming		= 14,
        st_General		= 17,
        st_Control		= 19,
        st_Result		= 16
    };

    static adep_at build_class(BeoBuf& b) {
        switch (b.read_int()) {
        case st_Incoming:
            return (new Incoming)->extract(b);
        case st_General:
            return (new General)->extract(b);
        case st_Control:
            return (new Control)->extract(b);
        case st_Result:
            return (new Result)->extract(b);
        default:
            return 0;
        }
    }

    /***********/
    class Result : public adeo_mt_t
    {
    public:
        /*************************************** variables ***************************************/
        bool rejected;
        string src_num;
        string src_num_pivot;
        string src_ndi;
        string src_alpha;
        string src_company_id;
        string src_company_dn;
        string src_user_id;
        string src_geo_zone;
        bool src_clir;
        int src_hold_music;
        bool src_relayed_forced;
        bool src_recorded_forced;
        int src_nat_zone;
        bool src_nat_learn;
        bool has_redirect;
        string redirect_num;
        string redirect_alpha;
        bool redirect_clir;
        bool redirect_show;
        std::vector<string> dst_alias;
        string dst_num;
        string dst_num_pivot;
        string dst_ndi;
        string dst_alpha;
        string dst_company_id;
        string dst_company_dn;
        string dst_user_id;
        string dst_geo_zone;
        bool dst_show;
        int dst_hold_music;
        bool dst_relayed_forced;
        bool dst_recorded_forced;
        int dst_nat_zone;
        bool dst_nat_learn;
        string call_id;
        int timeout;
        int node_id;
        bool has_trunk_info;
        int trunk_id;

        /*************************************** méthodes ***************************************/
        Result* extract(BeoBuf& b) {
            call_id = b.read_string();
            rejected = b.read_int() ? true : false;
            src_num = b.read_string();
            src_num_pivot = b.read_string();
            src_ndi = b.read_string();
            src_alpha = b.read_string();
            src_company_id = b.read_string();
            src_company_dn = b.read_string();
            src_user_id =  b.read_string();
            src_geo_zone = b.read_string();
            src_clir = b.read_int() ? true : false;
            src_hold_music = b.read_int();
            src_relayed_forced = b.read_int() ? true : false;
            src_recorded_forced = b.read_int() ? true : false;
            src_nat_zone = b.read_int();
            src_nat_learn = b.read_int() ? true : false;
            has_redirect = b.read_int() ? true : false;
            redirect_num = b.read_string();
            redirect_alpha = b.read_string();
            redirect_clir = b.read_int() ? true : false;
            redirect_show = b.read_int() ? true : false;
			size_t nbAlias = (size_t)b.read_int();
			for (size_t i = 0; i< nbAlias; i++) {
				dst_alias.push_back(b.read_string());
			}
            dst_num = b.read_string();
            dst_num_pivot = b.read_string();
            dst_ndi = b.read_string();
            dst_alpha = b.read_string();
            dst_company_id = b.read_string();
            dst_company_dn = b.read_string();
            dst_user_id = b.read_string();
            dst_geo_zone = b.read_string();
            dst_show = b.read_int() ? true : false;
            dst_hold_music = b.read_int();
            dst_relayed_forced = b.read_int() ? true : false;
            dst_recorded_forced = b.read_int() ? true : false;
            dst_nat_zone = b.read_int();
            dst_nat_learn = b.read_int() ? true : false;
            timeout = b.read_int();
            node_id = b.read_int();
            has_trunk_info = b.read_int() ? true : false;
            trunk_id = b.read_int();
            return this;
        }

        void insert(BeoBuf& b, bool with_id) {
            if (with_id) {
                b.write_int(st_Result);
            }
            b.write_string(call_id);
            b.write_int(rejected);
            b.write_string(src_num);
            b.write_string(src_num_pivot);
            b.write_string(src_ndi);
            b.write_string(src_alpha);
            b.write_string(src_company_id);
            b.write_string(src_company_dn);
            b.write_string(src_user_id);
            b.write_string(src_geo_zone);
            b.write_int(src_clir);
            b.write_int(src_hold_music);
            b.write_int(src_relayed_forced);
            b.write_int(src_recorded_forced);
            b.write_int(src_nat_zone);
            b.write_int(src_nat_learn);
            b.write_int(has_redirect);
            b.write_string(redirect_num);
            b.write_string(redirect_alpha);
            b.write_int(redirect_clir);
            b.write_int(redirect_show);
            b.write_int((int)(dst_alias.size()));
			for (size_t i = 0; i < dst_alias.size(); i++) {
				b.write_string(dst_alias[i]);
			}
            b.write_string(dst_num);
            b.write_string(dst_num_pivot);
            b.write_string(dst_ndi);
            b.write_string(dst_alpha);
            b.write_string(dst_company_id);
            b.write_string(dst_company_dn);
            b.write_string(dst_user_id);
            b.write_string(dst_geo_zone);
            b.write_int(dst_show);
            b.write_int(dst_hold_music);
            b.write_int(dst_relayed_forced);
            b.write_int(dst_recorded_forced);
            b.write_int(dst_nat_zone);
            b.write_int(dst_nat_learn);
            b.write_int(timeout);
            b.write_int(node_id);
            b.write_int(has_trunk_info);
            b.write_int(trunk_id);
        }

        string to_txt(void);
        string to_log(void) {
			std::string dst;
			for (size_t i = 0; i < dst_alias.size(); i++) {
				if (i > 0) dst += "|";
				dst += dst_alias[i];
			}			
			
            return "Result(call_id=" + call_id
                + ", rejected=" + bool2string(rejected)
                + ", src_num=" + src_num
                + ", src_num_pivot=" + src_num_pivot
                + ", src_alpha=" + src_alpha
                + ", src_company_id=" + src_company_id
                + ", src_company_dn=" + src_company_dn
                + ", src_user_id=" + src_user_id
                + ", src_geo_zone=" + src_geo_zone
                + ", src_hold_music=" + long2string(src_hold_music)
                + ", src_relayed_forced=" + bool2string(src_relayed_forced)
                + ", src_recorded_forced=" + bool2string(src_recorded_forced)
                + ", src_nat_zone=" + long2string(src_nat_zone)
                + ", src_nat_learn=" + bool2string(src_nat_learn)
                + ", has_redirect=" + bool2string(has_redirect)
                + ", redirect_num=" + redirect_num
                + ", redirect_alpha=" + redirect_alpha
                + ", redirect_clir=" + bool2string(redirect_clir)
                + ", redirect_show=" + bool2string(redirect_show)
                + ", dst_alias=" + dst
                + ", dst_num=" + dst_num
                + ", dst_num_pivot=" + dst_num_pivot
                + ", dst_ndi=" + dst_ndi
                + ", dst_alpha=" + dst_alpha
                + ", dst_company_id=" + dst_company_id
                + ", dst_company_dn=" + dst_company_dn
                + ", dst_user_id=" + dst_user_id
                + ", dst_geo_zone=" + dst_geo_zone
                + ", dst_show=" + bool2string(dst_show)
                + ", dst_hold_music=" + long2string(dst_hold_music)
                + ", dst_relayed_forced=" + bool2string(dst_relayed_forced)
                + ", dst_recorded_forced=" + bool2string(dst_recorded_forced)
                + ", dst_nat_zone=" + long2string(dst_nat_zone)
                + ", dst_nat_learn=" + bool2string(dst_nat_learn)
                + ", timeout=" + long2string(timeout)
                + ", node_id=" + long2string(node_id)
                + ", has_trunk_info=" + bool2string(has_trunk_info)
                + ", trunk_id=" + long2string(trunk_id)
                + ")";
        }
        Result* rej(void);
        Result* cont(void);
        bool is_rejected(void);

/*** constructors & destructor ***/
    Result(void) :
        rejected(false),
            src_clir(false),
            src_hold_music(-1),
            src_relayed_forced(false),
            src_recorded_forced(false),
            src_nat_zone(-1),
            src_nat_learn(false),
            has_redirect(false),
            redirect_clir(false),
            redirect_show(false),
            dst_show(false),
            dst_hold_music(-1),
            dst_relayed_forced(false),
            dst_recorded_forced(false),
            dst_nat_zone(-1),
            dst_nat_learn(false),
            timeout(0),
            node_id(-1),
            has_trunk_info(false),
            trunk_id(0) {
        }
    Result(string s) :
        rejected(false),
            src_clir(false),
            src_hold_music(-1),
            src_relayed_forced(false),
            src_recorded_forced(false),
            src_nat_zone(-1),
            src_nat_learn(false),
            has_redirect(false),
            redirect_clir(false),
            redirect_show(false),
            dst_show(false),
            dst_hold_music(-1),
            dst_relayed_forced(false),
            dst_recorded_forced(false),
            dst_nat_zone(-1),
            dst_nat_learn(false),
            timeout(0),
            node_id(-1),
            has_trunk_info(false),
            trunk_id(0) {
			dst_alias.push_back(s);
        }
    };
    typedef adep_t<Result> ResultA;

    /***********/
    class BaseEvent : public adeo_mt_t
    {
    public:
        virtual void insert(BeoBuf& b, bool with_id)=0;
        virtual std::string to_log(void)=0;
        virtual ResultA do_it(void)=0;
    };
    typedef adep_t<BaseEvent> BaseEventA;
    /***********/
    class Control : public BaseEvent
    {
    public:
        /*************************************** variables ***************************************/
        string param;
        /*************************************** méthodes ***************************************/
        Control* extract(BeoBuf& b) {
            param = b.read_string();
            return this;
        }
        void insert(BeoBuf& b, bool with_id) {
            if (with_id) {
                b.write_int(st_Control);
            }
            b.write_string(param);
        }
        ResultA make_rv(string query, string resp);
        ResultA do_it(void);
        std::string to_log(void) {
            return "control(param=" + param + ")";
        }
    };
    typedef adep_t<Control> ControlA;
    class Incoming : public BaseEvent
    {
    public:
    Incoming()
        : src_hidden(false),
            has_forward(false) {
        }

        /*************************************** variables ***************************************/
        string src_tty;
        bool src_hidden;
        string input_string;
        string call_id;
        bool has_forward; ///< Set to true if there is a forward (in the operator world) before entering MOSAICA
        string last_forward; ///< Phone number of the last forward. Used to avoid loops between an operator and MOSAICA

        /*************************************** méthodes ***************************************/
        Incoming* extract(BeoBuf& b) {
            call_id = b.read_string();
            src_tty = b.read_string();
            src_hidden = b.read_int() ? true : false;
            input_string = b.read_string();
            has_forward = b.read_int() ? true : false;
            last_forward = b.read_string();
            return this;
        }

        void insert(BeoBuf& b, bool with_id) {
            if (with_id) {
                b.write_int(st_Incoming);
            }
            b.write_string(call_id);
            b.write_string(src_tty);
            b.write_int(src_hidden);
            b.write_string(input_string);
            b.write_int(has_forward);
            b.write_string(last_forward);
        }

        ResultA do_it(void);
        string to_txt(void);
        string to_log(void) {
            return "Incoming(call_id=" + call_id
                + ", src_tty=" + src_tty
                + ", src_hidden=" + bool2string(src_hidden)
                + ", input_string=" + input_string
                + ", has_forward=" + bool2string(has_forward)
                + ", last_forward=" + last_forward
                + ")";
        }
    };
    /***********/
    class General : public BaseEvent
    {
    public:
        /*************************************** constantes ***************************************/
        enum reason_t {
            busy_reason		= 0,
            noanswer_reason	= 1,
            noroute_reason	= 2,
            connect_reason	= 3,
            disconnect_reason	= 4,
            disconnect2_reason	= 5,
            setup_reason	= 6,
            abort_reason	= 7,
            transfer_reason	= 8,
            divert_reason 	= 9,
            pickup_reason	= 10,
            max_reason		= 11
        };

        /*************************************** variables ***************************************/
        string call_id;
        reason_t reason;
        string data;
        string data2;
        /*************************************** méthodes ***************************************/
        void validate(void) {
            ValStr::isNum(call_id, "call_id");
            if (((unsigned int)reason)>=max_reason) {
                throw msg_error_t(0,"CallEvent::General::reason out of range");
            }
        }
        General* extract(BeoBuf& b) {
            call_id = b.read_string();
            reason = (reason_t)b.read_int();
            data = b.read_string();
            data2 = b.read_string();
            return this;
        }

        void insert(BeoBuf& b, bool with_id) {
            if (with_id) {
                b.write_int(st_General);
            }
            b.write_string(call_id);
            b.write_int(reason);
            b.write_string(data);
            b.write_string(data2);
        }

        static string reason_to_string(reason_t reason);
        ResultA do_it(void);
        string to_txt(void);
        string to_log(void) {
            std::string log;
            log = "General(call_id=" + call_id;

            switch (reason) {
            case setup_reason:
                log += ", reason=setup";
                break;
            case busy_reason:
                log += ", reason=busy";
                break;
            case noanswer_reason:
                log += ", reason=noanswer";
                break;
            case noroute_reason:
                log += ", reason=noroute";
                break;
            case connect_reason:
                log += ", reason=connect";
                break;
            case disconnect_reason:
                log += ", reason=disconnect";
                break;
            case disconnect2_reason:
                log += ", reason=disconnect2";
                break;
            case abort_reason:
                log += ", reason=abort";
                break;
            case transfer_reason:
                log += ", reason=transfer";
                break;
            case divert_reason:
                log += ", reason=divert";
                break;
            case pickup_reason:
                log += ", reason=pickup";
                break;
            default:
                log += ", reason=unknown reason("+long2string((int)reason)+")";
                break;
            }

            log +=", data=" + data + ", data2=" + data2 + ")";
            return log;
        }
        /*** constructors & destructor ***/
    General(void) : reason(max_reason) {}
    };
    typedef adep_t<General> GeneralA;
    static Result* blog(CallEvent::Result* r, string& dbg_msg, call_t& call);
    static Result* reject(string& dbg_msg, call_t& call);
    /***********/
};

#endif
