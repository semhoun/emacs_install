// charset=utf-8
#ifndef __ADEX_CLASS_H_
#define __ADEX_CLASS_H_

#include "thread_utils.h"
#include <assert.h>
#include <string>
using namespace std;

// AutoDEleteXXXXXX classes

//! AutoDEleteObject
/*! All objects intended to be manipulated via adep_t pointers must inherit from adeo_t */

class adeo_mt_t
{
    friend class adeo_access_t;
    int nb;
    mutex_t m;
    bool destruction_in_progress;

    bool inc(void) {
        m.lock();
        if (destruction_in_progress) {
            m.unlock();
            return true;
        }
        ++nb;
        m.unlock();
        return false;
    }
    bool dec(void) {
        m.lock();
        if (destruction_in_progress) {
            m.unlock();
            return false;
        }
        if (--nb==0) {
            destruction_in_progress=true;
            m.unlock();
            return true;
        }
        m.unlock();
        return false;
    }

public:
    int get_adep_count(void)   {
        return nb;    /* for debugging */
    }
    adeo_mt_t(void) :               nb(0),  destruction_in_progress(false) {}
    adeo_mt_t(const adeo_mt_t& a) : nb(0), destruction_in_progress(false) {}
    adeo_mt_t& operator=(const adeo_mt_t& a)	 {
        return *this;
    }
    /* in "operator=" no protection of "nb" is necessary since the application is already *
     * supposed to have protected *this, which turns to be a lvalue in this operation     */
    virtual ~adeo_mt_t(void) {}
};

class adeo_access_t
{
public:
    static bool inc(adeo_mt_t* a) {
        return a->inc();
    }
    static bool dec(adeo_mt_t* a) {
        return a->dec();
    }
};

//! AutoDEletePointer
/*! A clever kind of pointer that delete automaticaly objects when not used.
Manipulated objects must inherit from adeo_t so that a reference counter be available */

template<class T>
class adep_t
{
    adeo_mt_t* p;
    void inc(void) {
        if (p && adeo_access_t::inc(p)) {
            p=0;
        }
    }
    void del(void) {
        if (p && adeo_access_t::dec(p)) {
            delete p;
        }
        p=0;
    }
    void swap(adeo_mt_t* q) {
        if (q && adeo_access_t::inc(q)) {
            q=0;
        }
        del();
        p=q;
    }
public:

    bool		operator==(T* q)        {
        return p==q;
    }
    T*			drop(void)              {
        if (p) {
            adeo_access_t::dec(p);    // stops monitoring the object
        }
        T* rv=p;
        p=0;
        return rv;
    }

    T*	        x(void) const           {
        return static_cast<T*>(p);
    }
    operator T* (void) const {
        return static_cast<T*>(p);
    }
    T*			operator ->(void) const {
        assert(p);
        return static_cast<T*>(p);
    }
    // une erreur du genre "adex_class.h:81: static_cast from `adeo_t *const' to `mon_type *'" peut être dÃ» à ce que le type utilisé pour T n'a pas été déclaré complètement (déclaration forward uniquement)

    template<class U>
    adep_t&    operator=(const adep_t<U>& a) {
        operator=(a.x());
        return *this;
    }
    adep_t&    operator=(const adep_t& a)    {
        operator=(a.x());    /* pour le bug g++ qui n'utilise pas le template ci-dessus */
        return *this;
    }
    adep_t&    operator=(T* q)               {
        swap(q);
        return *this;
    }

    template<class U>
    adep_t (const adep_t<U>& a)   {
        p=static_cast<adeo_mt_t*>(a.x());
        inc();
    }
    adep_t (const adep_t& a) {
        p=const_cast<adeo_mt_t*>(a.p);    // pour le bug g++ qui n'utilise pas le template ci-dessus
        inc();
    }
    adep_t (const T* q=0)   {
        p=const_cast<T*>(q);
        inc();
    }

    ~adep_t(void)           {
        del();
    }
    static void	mark_static(adeo_mt_t* a)  {
        assert(a);    /* prevents deletetion of a static object */
        bool ok=!adeo_access_t::inc(a);
        assert(ok);
    }
    void		mark_static(void)       {
        assert(p);    /* prevents deletetion of a static object */
        bool ok=!adeo_access_t::inc(p);
        assert(ok);
    }
};

typedef adep_t<adeo_mt_t> adep_at;

class AdeoString
    : public adeo_mt_t
{
public:
    string s;
    AdeoString(string s) : s(s) {}
};

#endif
