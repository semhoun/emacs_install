#ifndef __FILE_UTILS_H__
#define __FILE_UTILS_H__

#include "msg_error.h"
#include <stdio.h>

class AutoFile
{
public:
    FILE* x;

    void close(void) {
        if (x) {
            fclose(x);
            x=0;
        }
    }
    AutoFile(FILE* x=0) : x(x) {}
    ~AutoFile(void) {
        close();
    }
};
typedef AutoFile autoclose_file_t; // backward compatibility

class FileUtils
{
public:
    class error : public msg_error_t
    {
    public:
        ERROR_PREFIX("FileUtils: ")
    };
    static void throwErrno(string msg);
    static void copy(string oldfile, string newfile);
    static void unlink(string path);
    static void rename(string oldpath, string newpath);
    static void smartMove(string oldfile, string newfile);
    static bool fileExists(string fn);
    static bool isReg(string fn);
    static int getSize(string fn, bool genExcept);
};

class DirSearch
{
    /******************** types ********************/
public:
    class error : public msg_error_t
    {
    public:
        ERROR_PREFIX("DirSearch: ")
    };
    typedef bool (*Handle)(void* pThis, string filename); // if the return value is false, stops walking

    /******************** methods ********************/
protected:
    static int alphaSort(const void* a, const void* b);
    static void freeRemaining(struct dirent** list, int n);

public:
    static void walkDir(string directory, Handle handle, void* handleThis);
};


#endif
