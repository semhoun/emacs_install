#pragma once

#include "cpptools/nettone_tools_Exception.h"
#include "api_common_IRequester.h"

namespace api
{
	namespace common
	{
		/**
		 * Strategy Interface
		 * This class is NOT THREADSAFE [FIXME - should be ?].
		 */
		class IStrategy
		{
		public:
			typedef unsigned long ContextId;

			/**
			 * Destructor.
			 */
			virtual ~IStrategy()
				throw () {}

			/**
			 * Start the server.
			 */
			virtual void start()
				throw (nettone::tools::Exception) = 0;

			/**
			 * Stop the server.
			 */
			virtual void stop()
				throw () = 0;

			/**
			 *
			 */
			class IStop
			{
			public:
				virtual ~IStop() {}
				virtual void handleStop(IStrategy* const p_strategy)
					throw () = 0;
			};

			/**
			 * Stop the Strategy
			 *
			 * @return false if no handleStop will be called
			 */
			virtual bool requestStop(IStop* const p_handler)
				throw () = 0;

			/**
			 * Add a IRequester in the algorithm.
			 */
			virtual void addRequester(IRequester* const p_IRequester)
				throw (nettone::tools::Exception) = 0;

			/**
			 * Interface notified on completion of a IRequester removal operation.
			 */
			class IRemoveRequester
			{
			public:
				virtual ~IRemoveRequester() {}
				virtual void handleRemoveRequester(IRequester* const p_Requester)
					throw () = 0;
			};

			/**
			 * Remove a Requester from the decision algorithm.
			 *
			 * @param p_Requester The IRequester to remove.
			 * @param p_handler   Whe to notify when removal is done.
			 *
			 * @exception nettone::tools::Exception thrown if the IRequester is unknown.
			 */
			virtual void requestRemoveRequester(IRequester* const p_Requester,
												IRemoveRequester* const p_handler)
				throw (nettone::tools::Exception) = 0;

			/**
			 * Create a context.
			 *
			 * @return the id of the context.
			 */
			virtual ContextId createContext()
				throw (nettone::tools::Exception) = 0;

			/**
			 * Release a context.
			 *
			 * @param p_cid Id of the context.
			 */
			virtual void releaseContext(const ContextId& p_cid)
				throw () = 0;

			/**
			 * Get the next solution for a context.
			 *
			 * @param p_contextId ID of the context.
			 *
			 * @return The IRequester to use.
			 */
			virtual IRequester* getNextTarget(const ContextId& p_contextId)
				throw (nettone::tools::Exception) = 0;

			/**
			 * Get the current target for a context.
			 *
			 * @param p_contextId ID of the context.
			 *
			 * @return The current IRequester.
			 *
			 * @note Can be called only after a successful call to getNextTarget().
			 */
			virtual IRequester* getCurrentTarget(const ContextId& p_contextId)
				throw (nettone::tools::Exception) = 0;

			/**
			 * Get number of requesters inserted in available requesters tab
			 * 
			 * @return The number of requester 
			 */
			virtual int getRequesterNumber() const
				noexcept(true) = 0;
		};
	}
}
