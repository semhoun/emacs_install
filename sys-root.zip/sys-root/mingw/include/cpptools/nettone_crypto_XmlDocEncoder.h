#ifndef __NETTONE_CRYPTO_XMLDOCENCODER_H__
#define __NETTONE_CRYPTO_XMLDOCENCODER_H__


#include <list>
#include <libxml/parser.h>
#include <libxml/xpath.h>

#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		class RSA;
	
		/**
		 * XmlDocEncoder toolkit
		 */
		class XmlDocEncoder
		{
		public:
			typedef std::list<std::string> StringList;

			/** 
			 * Encrypt specified xpath of p_xml with rsa private key
			 * 
			 * @param p_xml		xml doc to encrypt
			 * @param p_xpaths	xpaths of node to encode
			 * @param p_rsa		private key for encryption
			 * 
			 * @return an encoded xmlDoc, caller is responsible for deletion
			 */
			static xmlDoc* encrypt(const xmlDoc* p_xml,
											  const StringList& p_xpaths,
											  const RSA* p_rsa)
				throw (nettone::tools::Exception);

		private:
			/**
			 * Constructor.
			 */
			XmlDocEncoder()
				throw ();
		};
	}
}


#endif // __NETTONE_CRYPTO_XMLDOCENCODER_H__
