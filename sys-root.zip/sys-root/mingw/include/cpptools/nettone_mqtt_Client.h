#pragma once


#include <cpptools/nettone_tools_Exception.h>
#include <mosquittopp.h>
#include <json/json.h>
#include <map>
#include <atomic>


namespace nettone::tools
{
	class Synchro;
}


namespace nettone::mqtt
{
	/**
	 * Mqtt mosquitto client
	 */
	class Client
		: protected mosqpp::mosquittopp
	{
	public:
		struct Config
		{
			// MQTT Broker host
			std::string host;

			// MQTT Broker port
			int port = 1883;

			// TLS CA cert if empty no TLS
			std::string caFile;

			// Login
			std::string username;

			// Password
			std::string password;

			// keepalive in seconds
			int keepalive = 60;

			// Autoreconnect to server
			bool autoReconnect = true;

			// Autoreconnect delay in s
			unsigned int reconnectDelay = 2;

			// Autoreconnect delay max in s
			unsigned int reconnectDelayMax = 300;

			// Exponentionial reconnect delay
			bool reconnectExponentialBackoff = true;
		};

		class IConnection
		{
		public:
			virtual void connected()
				throw() = 0;
			virtual void connectionError(const std::string& p_msg)
				throw() = 0;
			virtual void subscribeError(const std::string& p_topic,
										const std::string& p_msg)
				throw() = 0;
			virtual void disconnected()
				throw() = 0;
		};

		class IMessage
		{
		public:
			virtual void message(const std::string& p_topic,
								 const std::string& p_msg)
				throw() = 0;
			virtual void message(const std::string& p_topic,
								 const Json::Value& p_msg)
				throw() = 0;
		};

		/**
		 * Constructor
		 */
		Client()
			noexcept(true);

		~Client()
			noexcept(true);

		/**
		 * Connect to MQTT Broker
		 * Disconnection will occur on destroy
		 */
		void connect(const Config& p_conf,
					 IConnection* p_handler,
					 const bool p_async = true)
			noexcept(false);

		/**
		 * Publish to a topic
		 */
		void publish(const std::string& p_topic,
					 const Json::Value& p_msg)
			noexcept(false);

		/**
		 * Publish to a topic
		 */
		void publish(const std::string& p_topic,
					 const std::string& p_msg)
			noexcept(false);

		/**
		 * Subscribe to a topic
		 *
		 * Must be called before connect, so when will connected or reconnecte subscribe will be done
		 *
		 * p_json Decode incoming message as JSON
		 */
		void subscribe(const std::string& p_topic,
					   IMessage* p_handler,
					   const bool p_json = false)
			noexcept(false);

		/**
		 * Is Conneced
		 */
		bool isConnected()
			throw();

	private:
		/// @name Forbidden methods
		/// @{
		Client(const Client& p_other);
		const Client& operator =(const Client& p_other);
		/// @}

		/// @name Mosquitto methods
		/// @{
		virtual void on_connect(int p_rc);
		virtual void on_disconnect(int p_rc);
		virtual void on_message(const struct mosquitto_message* p_message);
		/// @}

		/**
		 * Current config
		 */
		Config m_conf;

		/**
		 * Is connected
		 */
		bool m_connected;

		/**
		 * Connection handler
		 */
		std::atomic<IConnection*> m_connectionHandler;

		/**
		 * Message Handler
		 */
		struct MHandler
		{
			// Message handler
			IMessage* handler;

			// Decode as json
			bool json;

			// Topic
			std::string topic;
		};
		typedef std::map<std::string, MHandler> MessagesHandler;
		MessagesHandler m_messagesHandler;
	};
}
