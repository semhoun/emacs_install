#ifndef __NETTONE_TOOLS_SERVERDEFERRED_H__
#define __NETTONE_TOOLS_SERVERDEFERRED_H__

#include <memory>
#include <list>

#include "nettone_tools_Exception.h"
#include "nettone_tools_Monitor.h"
#include "nettone_tools_Thread.h"

namespace
{
    /// Magic number value
    const unsigned long l_idefrredMagicNumber = 20130910;
}

namespace nettone
{
    namespace tools
    {
        /**
         * Processor of deferred tasks.
         */
        class ServerDeferred
        {
        public:
            /**
             * Type of the request ID.
             */
            class RequestId
            {
            public:
                /**
                 * The null object.
                 */
                static const RequestId null;

                /**
                 * Return a new unique RequestId object.
                 * Value loops on 32 bits unsigned.
                 */
                static RequestId getNewId()
                    throw();

                /**
                 * Constructor.
                 */
                RequestId()
                    throw();

                /**
                 * Casting to a unsigned long.
                 */
                operator unsigned long() const
                    throw();

                /**
                 * Comparison operator.
                 */
                bool operator ==(const RequestId& p_other)
                    throw();

                /**
                 * Comparison operator.
                 */
                bool operator !=(const RequestId& p_other)
                    throw();

                /**
                 * Assignement operator.
                 */
                const RequestId& operator =(const RequestId& p_other)
                    throw();

            private:
                /**
                 * Constructor.
                 */
                RequestId(const unsigned long p_reqId)
                    throw();

                /**
                 * The ID itself.
                 */
                unsigned long m_reqId;
            };

            /**
             * Base class of all deferred tasks
             */
            class IDeferred
            {
            public:
                /**
                 * Destructor.
                 */
                virtual ~IDeferred() {
                    m_magicNumber = 0;
                }

                /**
                 * Methods called by the processor.
                 *
                 * @param p_reqId ID of the request.
                 * @param p_key   The key provided at registration time.
                 */
                virtual void process(const RequestId p_reqId,
                                     void* const p_key)
                    throw() = 0;

                /**
                 * Try to get the class name
                 * Must be overload by son
                 */
                virtual std::string className() throw() { return "IDeferred"; }

                // Magic number for precess execution
                unsigned long m_magicNumber = l_idefrredMagicNumber;
            };

            /**
             * Constructor.
             */
            ServerDeferred(const std::string& p_threadName = "DeferredProcessor")
                throw(nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~ServerDeferred()
                throw();

            /**
             * Possible states.
             */
            enum State
            {
                IDLE, /**< do nothing. */
                RUNNING, /**< process pending requests and accept new */
                STOPPING /**< process pending requests and, please, stopping scheduling new jobs. */
            };

            /**
             * Get the current state.
             */
            State getState() const
                throw();

            /**
             * Start the server.
             */
            virtual void start()
                throw(nettone::tools::Exception);

            /**
             * Interface notified when the stop request is conpleted.
             */
            class IStop
            {
            public:
                virtual ~IStop()
                    {
                    }
                virtual void handleServerDeferredStop(ServerDeferred* const p_server)
                    throw() = 0;
            };

            /**
             * Request the server to stop.
             *
             * @param p_handler    Who to notify when the last deferred task has been processed.
             * @param p_smoothStop Flag indicating if we stop after the currently processed
             *                     task (false) or when all pending task has been processed (true).
             */
            void requestStop(IStop* const p_handler,
                             const bool p_smoothStop = false)
                throw();

            /**
             * Wait for the termination of the internal processor.
             *
             * @warning Must be call in another thread the server it-self.
             */
            void join()
                throw();

            /**
             * Request the server to stop, and wait for request completion.
             *
             * @warning Must be call in another thread the server it-self (i.e not in a
             * process() method.
             */
            void stop()
                throw();

            /**
             * Schedule an event for further processing.
             *
             * @param p_reqId    Where to stock the ID of request.
             * @param p_deferred The deferred task to schedule.
             * @param p_key      Request identifier.
             *
             * @return The ID of the request.
             */
            void postDeferred(RequestId& p_reqId,
                              IDeferred* const p_deferred,
                              void* const p_key)
                throw(nettone::tools::Exception);

            /**
             * Cancel a task processing.
             *
             * @param p_reqId The request ID.
             */
            void cancelDeferred(const RequestId p_reqId)
                throw(nettone::tools::Exception);

            template<typename C> class LateRunner0
                : public IDeferred {
            public:
                virtual std::string className() throw() { return "LateRunner0"; }
                typedef void (C::*Func)();
            LateRunner0(C* const p_target,
                        Func p_func)
                : m_target(p_target),
                    m_func(p_func)
                    {
                    }

            private:
                void process(const RequestId p_reqId,
                             void* const p_key)
                    throw()
                {
                    std::unique_ptr<IDeferred> thisAD(this);
                    (m_target->*m_func)();
                }

                C* m_target;
                Func m_func;
            };

            template<typename C, typename P1> class LateRunner1
                : public IDeferred
            {
            public:
                virtual std::string className() throw() { return "LateRunner1"; }
                typedef void (C::*Func)(const P1&);
            LateRunner1(C* const p_target,
                        Func p_func,
                        const P1& p_p1)
                : m_target(p_target),
                    m_func(p_func),
                    m_p1(p_p1)
                    {
                    }

            private:
                void process(const RequestId p_reqId,
                             void* const p_key)
                    throw()
                {
                    std::unique_ptr<IDeferred> thisAD(this);
                    (m_target->*m_func)(m_p1);
                }

                C* m_target;
                Func m_func;
                const P1 m_p1;
            };

            template<typename C, typename P1, typename P2>
                class LateRunner2
                :
                public IDeferred
            {
            public:
                virtual std::string className() throw() { return "LateRunner1"; }
                typedef void (C::*Func)(const P1&,
                                        const P2&);
            LateRunner2(C* const p_target,
                        Func p_func,
                        const P1& p_p1,
                        const P2& p_p2)
                : m_target(p_target),
                    m_func(p_func),
                    m_p1(p_p1),
                    m_p2(p_p2)
                    {
                    }

            private:
                void process(const RequestId p_reqId,
                             void* const p_key)
                    throw()
                {
                    std::unique_ptr<IDeferred> thisAD(this);
                    (m_target->*m_func)(m_p1, m_p2);
                }

                C* m_target;
                Func m_func;
                const P1 m_p1;
                const P2 m_p2;
            };

            template<typename C, typename P1, typename P2, typename P3>
                class LateRunner3
                :
                public IDeferred
            {
            public:
                virtual std::string className() throw() { return "LateRunner3"; }
                typedef void (C::*Func)(const P1&,
                                        const P2&,
                                        const P3&);
            LateRunner3(C* const p_target,
                        Func p_func,
                        const P1& p_p1,
                        const P2& p_p2,
                        const P3& p_p3)
                : m_target(p_target),
                    m_func(p_func),
                    m_p1(p_p1),
                    m_p2(p_p2),
                    m_p3(p_p3)
                    {
                    }

            private:
                void process(const RequestId p_reqId,
                             void* const p_key)
                    throw()
                {
                    std::unique_ptr<IDeferred> thisAD(this);
                    (m_target->*m_func)(m_p1, m_p2, m_p3);
                }

                C* m_target;
                Func m_func;
                const P1 m_p1;
                const P2 m_p2;
                const P3 m_p3;
            };

            template<typename C, typename P1, typename P2, typename P3, typename P4>
                class LateRunner4
                :
                public IDeferred
            {
            public:
                virtual std::string className() throw() { return "LateRunner4"; }
                typedef void (C::*Func)(const P1&,
                                        const P2&,
                                        const P3&,
                                        const P4&);
            LateRunner4(C* const p_target,
                        Func p_func,
                        const P1& p_p1,
                        const P2& p_p2,
                        const P3& p_p3,
                        const P4& p_p4)
                :m_target(p_target),
                    m_func(p_func),
                    m_p1(p_p1),
                    m_p2(p_p2),
                    m_p3(p_p3),
                    m_p4(p_p4)
                    {
                    }

            private:
                void process(const RequestId p_reqId,
                             void* const p_key)
                    throw()
                {
                    std::unique_ptr<IDeferred> thisAD(this);
                    (m_target->*m_func)(m_p1, m_p2, m_p3, m_p4);
                }

                C* m_target;
                Func m_func;
                const P1 m_p1;
                const P2 m_p2;
                const P3 m_p3;
                const P4 m_p4;
            };

// -----

            template<typename P1>
                class LateFuncRunner1
                :  public IDeferred
                {
                public:
                    virtual std::string className() throw() { return "LateFuncRunner1"; }
                    typedef void (*Func)(const P1&);
                LateFuncRunner1(Func p_func,
                                const P1& p_p1)
                    : m_func(p_func),
                        m_p1(p_p1)
                        {
                        }

                private:
                    void process(const RequestId p_reqId,
                                 void* const p_key)
                        throw()
                    {
                        std::unique_ptr<IDeferred> thisAD(this);
                        (*m_func)(m_p1);
                    }

                    Func m_func;
                    const P1 m_p1;
                };

            template<typename P1, typename P2>
                class LateFuncRunner2
                : public IDeferred
            {
            public:
                virtual std::string className() throw() { return "LateFuncRunner2"; }
                typedef void (*Func)(const P1&,
                                     const P2&);
            LateFuncRunner2(Func p_func,
                            const P1& p_p1,
                            const P2& p_p2)
                : m_func(p_func),
                    m_p1(p_p1),
                    m_p2(p_p2)
                    {
                    }

            private:
                void process(const RequestId p_reqId,
                             void* const p_key)
                    throw()
                {
                    std::unique_ptr<IDeferred> thisAD(this);
                    (*m_func)(m_p1, m_p2);
                }

                Func m_func;
                const P1 m_p1;
                const P2 m_p2;
            };

// -----

            template<typename P1>
                IDeferred* buildRunner(void (*p_func)(const P1&),
                                       const P1& p_p1)
                {
                    return new LateFuncRunner1<P1>(p_func, p_p1);
                }

            template<typename P1, typename P2>
                IDeferred* buildRunner(void (*p_func)(const P1&,
                                                      const P2&),
                                       const P1& p_p1,
                                       const P2& p_p2)
            {
                return new LateFuncRunner2<P1, P2>(p_func, p_p1, p_p2);
            }

            template<typename C>
                IDeferred* buildRunner(C* const p_target,
                                       void (C::*p_func)())
                {
                    return new LateRunner0<C>(p_target, p_func);
                }

            template<typename C, typename P1>
                IDeferred* buildRunner(C* const p_target,
                                       void (C::*p_func)(const P1&),
                                       const P1& p_p1)
            {
                return new LateRunner1<C, P1>(p_target, p_func, p_p1);
            }

            template<typename C, typename P1, typename P2>
                IDeferred* buildRunner(C* const p_target,
                                       void (C::*p_func)(const P1&,
                                                         const P2&),
                                       const P1& p_p1,
                                       const P2& p_p2)
            {
                return new LateRunner2<C, P1, P2>(p_target, p_func, p_p1, p_p2);
            }

            template<typename C, typename P1, typename P2, typename P3>
                IDeferred* buildRunner(C* const p_target,
                                       void (C::*p_func)(const P1&,
                                                         const P2&,
                                                         const P3&),
                                       const P1& p_p1,
                                       const P2& p_p2,
                                       const P3& p_p3)
            {
                return new LateRunner3<C, P1, P2, P3>(p_target, p_func, p_p1, p_p2,
                                                      p_p3);
            }

            template<typename C, typename P1, typename P2, typename P3, typename P4>
                IDeferred* buildRunner(C* const p_target,
                                       void (C::*p_func)(const P1&,
                                                         const P2&,
                                                         const P3&,
                                                         const P4&),
                                       const P1& p_p1,
                                       const P2& p_p2,
                                       const P3& p_p3,
                                       const P4& p_p4)
            {
                return new LateRunner4<C, P1, P2, P3, P4>(p_target, p_func, p_p1, p_p2,
                                                          p_p3, p_p4);
            }

// -----

            template<typename P1>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      void (*p_func)(const P1&),
                                      const P1& p_p1)
                {
                    std::unique_ptr<IDeferred> laterRunnerAD(buildRunner(p_func, p_p1));
                    postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                    laterRunnerAD.release();
                }

            template<typename P1, typename P2>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      void (*p_func)(const P1&,
                                                     const P2&),
                                      const P1& p_p1,
                                      const P2& p_p2)
            {
                std::unique_ptr<IDeferred> laterRunnerAD(
                    buildRunner(p_func, p_p1, p_p2));
                postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                laterRunnerAD.release();
            }

            template<typename C>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      C* const p_target,
                                      void (C::*p_func)())
                {
                    std::unique_ptr<IDeferred> laterRunnerAD(
                        buildRunner(p_target, p_func));
                    postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                    laterRunnerAD.release();
                }

            template<typename C, typename P1>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      C* const p_target,
                                      void (C::*p_func)(const P1&),
                                      const P1& p_p1)
            {
                std::unique_ptr<IDeferred> laterRunnerAD(
                    buildRunner(p_target, p_func, p_p1));
                postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                laterRunnerAD.release();
            }

            template<typename C, typename P1, typename P2>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      C* const p_target,
                                      void (C::*p_func)(const P1&,
                                                        const P2&),
                                      const P1& p_p1,
                                      const P2& p_p2)
            {
                std::unique_ptr<IDeferred> laterRunnerAD(
                    buildRunner(p_target, p_func, p_p1, p_p2));
                postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                laterRunnerAD.release();
            }

            template<typename C, typename P1, typename P2, typename P3>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      C* const p_target,
                                      void (C::*p_func)(const P1&,
                                                        const P2&,
                                                        const P3&),
                                      const P1& p_p1,
                                      const P2& p_p2,
                                      const P3& p_p3)
            {
                std::unique_ptr<IDeferred> laterRunnerAD(
                    buildRunner(p_target, p_func, p_p1, p_p2, p_p3));
                postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                laterRunnerAD.release();
            }

            template<typename C, typename P1, typename P2, typename P3, typename P4>
                inline void callAsync(RequestId& p_requestId,
                                      void* const p_key,
                                      C* const p_target,
                                      void (C::*p_func)(const P1&,
                                                        const P2&,
                                                        const P3&,
                                                        const P4&),
                                      const P1& p_p1,
                                      const P2& p_p2,
                                      const P3& p_p3,
                                      const P4& p_p4)
            {
                std::unique_ptr<IDeferred> laterRunnerAD(
                    buildRunner(p_target, p_func, p_p1, p_p2, p_p3, p_p4));
                postDeferred(p_requestId, laterRunnerAD.get(), p_key);
                laterRunnerAD.release();
            }

            /**
             * Return true if the calling thread is the internal task processor.
             */
            bool isProcessorCurrentThread() const
                throw(Exception);

        private:
            /// @name Forbidden methods
            /// @{
            ServerDeferred(const ServerDeferred& p_other);
            const ServerDeferred& operator =(const ServerDeferred& p_other);
            /// @}

            /**
             * Deferred processing internal task.
             */
            class DeferredProcessor
                :
                public nettone::tools::Thread
            {
            public:
                /**
                 * Constructor.
                 *
                 * @param p_visitor The ServerDeferred itself.
                 */
                DeferredProcessor(ServerDeferred* p_serve,
                                  const std::string& p_threadName)
                    throw();

                /**
                 * Destructor.
                 */
                virtual ~DeferredProcessor()
                    throw();

            private:
                /// @name Methods from Thread
                /// @{
                virtual bool mustStop()
                    throw();
                virtual void run()
                    throw();
                /// @}

                /**
                 * The event server.
                 */
                ServerDeferred* m_server;
            };
            friend class DeferredProcessor;

            /**
             * Descriptor of a processing request.
             */
            struct Request
            {
            public:
                /**
                 * The deferred task to process.
                 */
                IDeferred* deferred;

                /**
                 * The key identifying the request.
                 */
                void* key;

                /**
                 * Request ID.
                 */
                RequestId reqId;

                /**
                 * Deferred class name
                 */
                std::string deferredClassName;
            };

            /**
             * Current state.
             */
            State m_state;

            /**
             * Deferred tasks queue.
             */
            std::list<Request> m_deferredQueue;

            /**
             * The deferred tasks processor.
             */
            DeferredProcessor* m_deferredProcessor;

            /**
             * Monitor access to the list of pending requests.
             */
            nettone::tools::Monitor* m_monitor;

            /**
             * Handler of completion of stop request.
             */
            IStop* m_handler;

            /**
             * Indicate if the server must stop just after the current deferred task,
             * or if it must process all pending request.
             */
            bool m_smoothStop;
        };
    }
}

#endif // __NETTONE_TOOLS_SERVERDEFERRED_H__
