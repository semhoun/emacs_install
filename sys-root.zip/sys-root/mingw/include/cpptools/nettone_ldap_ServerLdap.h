#ifndef __NETTONE_LDAP_SERVERLDAP__
#define __NETTONE_LDAP_SERVERLDAP__

#include <list>
#include "cpptools/nettone_tools_Thread.h"
#include "cpptools/nettone_tools_Monitor.h"
#include "nettone_ldap_LdapRequestor.h"

namespace nettone
{
    namespace ldap
    {
        /**
         * Server of LDAP requests
         */
        class ServerLdap
        {
        public:

            struct Config
            {
                /**
                 * Ideal number of requests processors
                 */
                unsigned short nbProcessors;

                /**
                 * Minimal number of requestor processsors
                 */
                unsigned short nbProcessorsRequired;

                /**
                 * Max of pending requests
                 */
                unsigned short nbMaxPendingRequests;

                /**
                 * LdapRequestor configuration
                 */
                LdapRequestor::Config requestorConf;
            }; //STRUCTURE CONFIG /////////////////////////////////////////////////////////////////

            /**
             * Constructor
             */
            ServerLdap()
                throw(nettone::tools::Exception);

            /**
             * Destructor
             */
            ~ServerLdap()
                throw(nettone::tools::Exception);

            /**
             * Start the server
             *
             * @param_p config the runtime configuration
             */
            void start(const Config& p_config)
                throw(nettone::tools::Exception);

            /**
             * Stop the server
             */
            void stop()
                throw();

            /**
             * Type of the request ID
             */
            class RequestId
            {
            public:
                /**
                 * the null object
                 */
                static const RequestId null;

                /**
                 * Return a new unique RequestId object.
                 * Value loops 32 bits unsigned
                 */
                static RequestId getNewId()
                    throw();

                /**
                 * Constructor
                 */
                RequestId()
                    throw();

                /**
                 * Casting to an unsigned long
                 */
                operator unsigned long() const
                    throw();

                /**
                 * Comparison operator
                 */
                bool operator ==(const RequestId& p_other)
                    throw();

                /**
                 * Comparison operator
                 */
                bool operator !=(const RequestId& p_other)
                    throw();

                /**
                 * Assigment operator
                 */
                const RequestId& operator =(const RequestId& p_other)
                    throw();

            private:
                /*²*
                 * Constructor
                 */
                RequestId(const unsigned long p_reqId)
                    throw();
                /**
                 * the id itself
                 */
                unsigned long m_reqId;
            }; // CLASS REQUESTID END //

            /**
             * Base interface for handlers of request result
             */
            class IHandlerQuery
            {
            public:
                /**
                 * Destructor
                 */
                virtual ~IHandlerQuery() {}

                /**
                 * Callback invoked on error on the server side
                 *
                 * @param p_reqId Id of the erroneous request
                 * @param p_error text of the error
                 */
                virtual void handleError(const RequestId& p_reqId,
                                         const std::string& p_error)
                    throw();
            }; // IHANDLERQUERY CLASS END //

            class IHandlerQueryWithResult
                : public IHandlerQuery
            {
            public:
                /**
                 * Callback method called when the request has been successfully processed.
                 *
                 * @param p_result the extracted data
                 */
                virtual void handleResult(const RequestId& p_reqId,
                                          const LdapRequestor::Result& p_result)
                    throw() = 0;
            }; // IHANDLERQUERYWITHRESULT CLASS END //

            // TODO
            // IMPLEMENT IN THE FUTURE IHANDLERQUERYWITHOUTRESULT

            template <typename C>
                class LateRunner0
                : public IHandlerQueryWithResult
                {
                public:
                    typedef void (C::* Func) (const RequestId&,
                                              const LdapRequestor::Result &);
                LateRunner0(C* const p_target, Func p_func)
                    : m_target(p_target),
                        m_func(p_func)
                        {}

                private:
                    virtual void handleResult(const RequestId& p_reqId,
                                              const LdapRequestor::Result& p_result)
                        throw()
                    {
                        std::unique_ptr<IHandlerQueryWithResult> thisAD(this);
                        (m_target->*m_func) (p_reqId, p_result);
                    }
                    C*	m_target;
                    Func	m_func;
                }; // LATERUNNER0 END //

            template <typename C>
                IHandlerQueryWithResult* buildRunner(C* const p_target, void (C::* p_func) ())
                {
                    return new LateRunner0<C>(p_target, p_func);
                }

            // TODO penser à rajouter les bons paramètres pour effectuer une requete LDAP
            template <typename C>
                inline void queryWithResult(RequestId& p_reqId,
                                            const std::string& p_base,
                                            int p_scope,
                                            const std::string& p_filter,
                                            const std::vector<std::string>& p_attrs,
                                            C* const p_target,
                                            void (C::* p_func) (const RequestId&,
                                                                const LdapRequestor::Result&))
                {
                    std::unique_ptr<IHandlerQueryWithResult> laterRunnerAD(buildRunner(p_target, p_func));
                    queryWithResult(p_reqId, p_base, p_scope, p_filter, p_attrs, laterRunnerAD.get());
                    laterRunnerAD.release();
                }

            /**
             * Request a LDAP operation that will return a result
             *
             * @param p_reqId	Where to store the requestId
             * @param p_ldapQuery the query to execute
             * @param p_handler the handler of request
             *
             */
            void queryWithResult(RequestId& p_reqId,
                                 const std::string& p_base,
                                 int p_scope,
                                 const std::string &p_filter,
                                 const std::vector<std::string> &p_attrs,
                                 IHandlerQueryWithResult* const p_handler)
                throw(nettone::tools::Exception);



        private:
            /**
             *  PRIVATE MEMBERS
             */

            /**
             * Task managin the timers.
             */
            class RequestProcessor
                : public nettone::tools::Thread
            {
            public:
                /**
                 * Constructor
                 *
                 * @param p_this the outter object
                 */
                RequestProcessor(ServerLdap* const p_this)
                    throw(nettone::tools::Exception);

                /**
                 * Destructor
                 */
                virtual ~RequestProcessor()
                    throw();
            private:
                /// @name methods from Thread
                ///  @{
                virtual void run()
                    throw();
                /// @}

                /**
                 * Outer object
                 */
                ServerLdap*	m_this;
            }; // REQUESTPROCESSOR CLASS END //
        friend class RequestorProcessor;


        /**
         * Common base of all the descriptor of pending request
         */
        class RequestBase
        {
        public:
            /**
             * Constructor
             *
             * @param p_query the LDAP query
             * @param p_key the key identifiying the request
             */
            RequestBase(const std::string& p_base,
                        int p_scope,
                        const std::string& p_filter,
                        const std::vector<std::string>& p_attrs,
                        void* const p_key)
                throw();

            /**
             * Destructor
             */
            virtual ~RequestBase()
                throw() {}

            /**
             * The ldap query
             */
            std::string m_base;

            /**
             * Scope
             */
            int m_scope;

            /**
             * LDAP search filter
             */
            std::string m_filter;

            /**
             * String attributs
             */
            std::vector<std::string> m_attrs;

            /**
             * the key identifying the request
             */
            void* m_key;

            /**
             * Request ID
             */
            RequestId reqId;

            /**
             * Error Handler
             */
            IHandlerQuery* m_errorHandler;

            /**
             * Process the request
             *
             * !!!  Method that NEED to be implemented !!!
             */
            virtual void process(ServerLdap* const p_server)
                throw(nettone::tools::Exception) = 0;
        }; // REQUESTBASE CLASS END


        /**
         * Describe a query that will return some rows
         */
        class RequestQueryWithResult
            : public RequestBase
        {
        public:
            /**
             * Constructor
             *
             * @param p_query		The LDAP query
             * @param p_key		the key identifying the request
             * @param p_handler	The handler of result
             */
            RequestQueryWithResult(const std::string& p_base, int p_scope, const std::string& p_filter,
                                   const std::vector<std::string> &p_attributes, void* const p_key,
                                   IHandlerQueryWithResult* const p_handler)
                throw();
        private:
            /// @name Methods from RequestBase
            /// @{
            virtual void process(ServerLdap* const p_server)
                throw(nettone::tools::Exception);
            /// @}

            /**
             * Callback handler
             */
            IHandlerQueryWithResult* const m_handler;

        }; // REQUESTQUERYWITHRESULT CLASS END ////////////////////////////////////////////////////////
        friend class RequestQueryWithResult;


        /// @name Forbidden methods
        /// @ {
        ServerLdap(const ServerLdap& p_other);
        const ServerLdap& operator =(const ServerLdap& p_other);
        /// @}

        /**
         * Post a request
         * @param p_reqId where to store the request ID
         * @param p_request the request to process
         *
         * @return the id of the request.
         */
        void postRequest(RequestId& p_reqId, RequestBase* const p_request)
            throw(nettone::tools::Exception);

        /**
         * Processors of request
         */
        std::list<RequestProcessor*>	m_procs;

        /**
         * Server configuration
         */
        Config				m_config;

        /**
         * The Ldap connection manager
         */
        LdapRequestor			m_ldap;

        /**
         * Monitor the request queue
         */
        nettone::tools::Monitor*		m_monitor;

        /**
         * Request queue
         */
        std::list<RequestBase*>		m_requests;

        };
    }// namespace ldap

} //namespace nettone

#endif
