#ifndef __NETTONE_LUA_CHUNK_H__
#define __NETTONE_LUA_CHUNK_H__


#include "nettone_tools_Exception.h"


namespace nettone
{
    namespace lua
    {
        class Stack;

        /**
         * A precompiled code chunk.
         */
        class Chunk
        {
        public:
            /**
             * Constructor.
             *
             * @param p_chunkSize Size in byte of the chunk.
             */
            Chunk(const unsigned long p_chunkSize)
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            ~Chunk()
                throw ();

            /**
             * Append byte code to the current end of the chunk.
             * Beware of not adding mode byte than specified in constructor.
             *
             * @param p_data Pointer to the data to add.
             * @param p_size Amount of data in bytes.
             */
            void appendBytecode(const char* p_data,
                                const unsigned long p_size)
                throw ();

            /**
             * Return a pointer to the buffer containing the byte code.
             * Use this only to feed the LUA interpreter it-self.
             */
            const char* getBytecode() const
                throw ();

            /**
             * Get thte size of the code chunk.
             */
            unsigned long getBytecodeSize() const
                throw ();

        private:
            /// @name Forbidden methods
            /// @{
            Chunk(const Chunk& p_other);
            const Chunk& operator =(const Chunk& p_other);
            /// @}

            /**
             * Pointer to the buffer containing the Bytecode.
             */
            char* const m_bytecode;

            /**
             * Current length of the chunk.
             */
            unsigned long m_length;

            /**
             * Maximum amount of data copiable in the chunk.
             */
            const unsigned long m_maxsize;
        };
    }
}


#endif // __NETTONE_LUA_CHUNK_H__
