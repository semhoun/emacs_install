#ifndef __NETTONE_TOOLS_HANDLE_H__
#define __NETTONE_TOOLS_HANDLE_H__


namespace nettone
{
	namespace tools
	{
		template <typename T, typename K>
		class ObjectManager;

		template <typename T, typename K>
		class Handle
		{
		public:
			/**
			 * Constructor.
			 */
			inline Handle()
				throw ();

			/**
			 * Constructor.
			 * 
			 * @param p_manager The resource manager holding the object.
			 * @param p_key     The identifier of the handled object.
			 */
			inline Handle(ObjectManager<T, K>* const p_manager,
						  const K& p_key)
				throw ();

			/**
			 * Copy constructor.
			 */
			inline Handle(const Handle<T, K>& p_other)
				throw ();

			/**
			 * Assignement operator.
			 */
			inline const Handle<T, K>& operator =(const Handle<T, K>& p_other)
				throw ();

			/**
			 * Dereferencement operator.
			 * Asked the managed for the handled resource, identified by its id.
			 */
			inline T operator ->()
				throw (nettone::tools::Exception);

		private:
			/**
			 * The key identifying the handled object in the manager.
			 */
			K m_key;

			/**
			 * The resource manager.
			 */
			ObjectManager<T, K>* m_manager;
		};
	}
}


#include "nettone_tools_Handle.ih"


#endif // __NETTONE_TOOLS_HANDLE_H__
