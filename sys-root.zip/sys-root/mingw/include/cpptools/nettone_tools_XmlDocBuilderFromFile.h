#ifndef __NETTONE_TOOLS_XMLDOCBUILDERFROMFILE_H__
#define __NETTONE_TOOLS_XMLDOCBUILDERFROMFILE_H__


#include "nettone_tools_Configxml.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Parse a xml file.
		 */
		class XmlDocBuilderFromFile
			: public IXmlDocBuilder
		{
		public:
			/**
			 * Constructor
			 */
			XmlDocBuilderFromFile(const std::string& p_filename)
				throw (Exception);
			
			/**
			 * Destructor
			 */
			virtual ~XmlDocBuilderFromFile()
				throw ();

		private:
			/// @name Forbidden methods
			/// @{
			XmlDocBuilderFromFile(const XmlDocBuilderFromFile& p_other);
			const XmlDocBuilderFromFile& operator =(const XmlDocBuilderFromFile& p_other);
			/// @}
			
			/// @name Method from IXmlDocBuilder
			/// @{
			virtual xmlDocPtr getDoc() const;
			/// @}
			
			/**
			 * Pointer to the parsed document
			 */
			xmlDocPtr m_doc;
		};
	}
}


#endif // __NETTONE_TOOLS_XMLDOCBUILDERFROMFILE_H__
