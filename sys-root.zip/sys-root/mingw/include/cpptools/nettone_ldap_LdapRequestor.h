#pragma once

#include <vector>
#include <list>
#include <memory>
#include <map>
#include "cpptools/nettone_tools_Mutex.h"

#include <ldap.h>


namespace nettone::ldap
{
	/**
	 * Access to the LDAP and execute LDAP request
	 */
	class LdapRequestor
	{
	public :

		class Result;
		class ResultEntry;
		class ResultValue;

		/**
		 * A set of structure Result used to store results of multi-queries
		 */
		typedef std::vector<Result*> ResultSet;

		class Result
		{
		public:

			friend class ResultValue;

			class const_iterator
			{
			public:
				/**
				 * Constructor
				 */
				const_iterator(const Result* const p_result,
							   const unsigned long p_entryId)
					throw();

				/**
				 * Constructor
				 */
				const_iterator(const const_iterator& p_other)
					throw();
				/**
				 * Destructor
				 */
				~const_iterator()
					throw();

				/**
				 * Operator =
				 */
				const const_iterator& operator=(const const_iterator& p_other)
					throw();

				/**
				 * Prefic ++ operator
				 */
				const_iterator& operator ++()
					throw(nettone::tools::Exception);

				const_iterator operator ++(int)
					throw(nettone::tools::Exception);

				/**
				 * Operator *
				 */
				const ResultEntry& operator *() const
					throw();

				/**
				 * Operator ->
				 */
				const ResultEntry* operator ->() const
					throw();

				/**
				 * Operator ==
				 */
				bool operator ==(const_iterator p_other) const
					throw();

				/**
				 * Operator !=
				 */
				bool operator !=(const_iterator p_other) const
					throw();

			private:
				/**
				 * Poiner to the result table on which this const_iterator  iterates
				 */
				const Result* const	m_result;

				/**
				 * Temporarily entry used in operator * and ->
				 * equivalent to m_row in SQL requestor
				 */
				mutable ResultEntry* m_entry;

				/**
				 * Offset of this current entry in the resultSet
				 */
				unsigned long m_entryId;

				/**
				 * Distinguish name of the entr;y
				 */
				std::string m_dn;


			}; // End of the class  ResultConstIterator;

			/**
			 * Constructor
			 */
			Result()
				throw();

			/**
			 * Destructor
			 */
			~Result()
				throw();

			/**
			 * Set th econtent of the Result struct
			 */
			void setContent(LDAP* const p_sock, LDAPMessage* const p_result)
				throw(nettone::tools::Exception);

			/**
			 * Move to the first attribute in the resultSet
			 * @return const_iterator to the first attribute
			 */
			const_iterator begin() const
				throw();

			/**
			 * Move to the last attributes in resultSet
			 *
			 * @return const_iterator to the last attribute
			 */
			const_iterator end() const
				throw();

			/**
			 * Size of the result table, in number of rows
			 *
			 * @return number of attributes in resultsset
			 */
			unsigned long size() const
				throw();

			/**
			 * Get the number of rows of the resultSet
			 *
			 * @return number of rows of the resultSet
			 */
			unsigned long getEntriesCount() const
				throw();

			/**
			 * Get the number of attributes
			 */
			unsigned long getAttributesCount(int p_offset) const
				throw(nettone::tools::Exception);

			/**
			 * Get the attribute name of a specific entry with the specific attributeId
			 */
			std::string getAttributeName(int p_entryId, int p_attributeId) const
				throw(nettone::tools::Exception);

			/**
			 * Get the dn for a specific entry
			 */
			std::string getDn(int p_offset) const
				throw(nettone::tools::Exception);

			LDAPMessage* getResult()
				throw();


			LDAPMessage* getEntry(int p_offset) const
				throw(nettone::tools::Exception);

			/**
			 * Operator
			 */
			const_iterator operator[] (const unsigned long p_at) const
				throw(nettone::tools::Exception);

			/**
			 * Set Ldap handler
			 */

			void setLdapSock(LDAP *p_sock)
				throw(nettone::tools::Exception);

		private :
			/// @name Forbidden methods
			/// @ {
			Result (const Result& p_other);
			const Result& operator=(const Result& p_other);
			/// @ }

			/**
			 * Looking for the value and store it.
			 * @param p_value the value to retrieve
			 */
			void retrieveValueContent(const ResultValue* const p_value) const
				throw(nettone::tools::Exception);

			// equivalent de m_numRows
			//
			unsigned long m_numEntries;

			// equivalent de m_numfields

			// pas de unsigned long m_field car a chaque row correspond une value;
			// 1 Entries  = n Attributes
			// 1 attributes = n values


			// resultat de la requete, début de la liste de résultat
			//
			LDAPMessage *m_result;

			// Curseur permettant de se déplacer dans la list
			//
			mutable LDAPMessage *m_current;

			// Structure that allow to manage attributes in entry
			//
			mutable BerElement *m_ber;

			/**
			 * Socket structure used to manage result
			 */
			LDAP *m_sock;

			/**
			 * Stock the recent entries retrieved
			 */
			mutable std::map<const unsigned long,  std::pair<int, std::vector<std::string>> > m_cache;

		}; // End of CLASS Result

		class ResultEntry
		{
		public:
			class const_iterator
			{
			public:
				/**
				 * constructor.
				 */
				const_iterator(const Result* const p_result,
							   unsigned long p_entryId,
							   unsigned long p_attributeId)
					throw();

				/**
				 * constructor
				 */
				const_iterator(const const_iterator& p_other)
					throw();

				/**
				 * Destructor
				 */
				~const_iterator()
					throw();

				/**
				 * Operator =
				 */
				const const_iterator& operator =(const const_iterator&p_other)
					throw();

				/**
				 * Prefix ++ operator
				 */
				const_iterator& operator ++()
					throw(nettone::tools::Exception);

				/**
				 * Postfix ++ operator
				 */
				const_iterator operator ++(int)
					throw(nettone::tools::Exception);

				/**
				 * Operator *
				 */
				const ResultValue& operator *() const
					throw();

				/**
				 * operator ->
				 */
				const ResultValue* operator ->() const
					throw();

				/**
				 * Operator ==
				 */
				bool operator ==(const_iterator p_other) const
					throw();

				/**
				 * Operator !=
				 */
				bool operator !=(const_iterator p_other) const
					throw();

			private:
				/**
				 *  Pointer to the resul table on which this const_iterator iterage
				 */
				const Result* const m_result;

				/**
				 * Pointer to the spécific entry.
				 */

				/**
				 * entry number of the value pointed by the iterator
				 */
				unsigned long m_entryId;

				/**
				 * atribute id of the value pointed by the iterator
				 */
				unsigned long m_attributeId;

				/**
				 * attribute id of the value pointed by the iterator * and ->
				 */
				mutable ResultValue *m_value;

			};
			//
			// End of RESULT_ENTRY::CONST_ITERATOR
			//


			/**
			 * Constructor
			 */
			ResultEntry(const Result* const p_result,
						unsigned long p_entryId, unsigned long p_numberAttributes,
						const std::string &p_dn)
				throw();

			/**
			 * Constructor
			 */
			ResultEntry(const ResultEntry& p_other)
				throw();

			/**
			 * Assignment operator
			 */
			const ResultEntry& operator =(const ResultEntry& p_other)
				throw();

			/**
			 *  Move to the first cell in the Current entry;
			 */
			const_iterator begin() const
				throw();

			/**
			 * Move to the last cell in the current entry;
			 */
			const_iterator end() const
				throw();

			/**
			 * size of the entry in number of attributes
			 */
			unsigned long size() const
				throw();

			/**
			 * operator []
			 */
			const_iterator operator [] (const unsigned long p_at) const
				throw(nettone::tools::Exception);

			/**
			 * Get the number to of the attribute in the entry
			 */
			unsigned long getAttributesCount() const
				throw();

			/**
			 * Get the Dn of the entry
			 */
			std::string getDn() const
				throw();
		private:
			/**
			 * Pointer to the resultSet that contains this entry
			 */
			const Result* const m_result;


			/**
			 * Offset of the entry in the resultSet
			 */
			unsigned long m_entryId;

			/**
			 * Number of attributes for the entry
			 */
			unsigned long m_numberAttributes;

			/**
			 * The distinguish name of the entry in the resultSet;
			 */
			std::string m_dn;

		};
		//
		// End of class ResultEntry;
		//

		/**
		 * A value in the resultSet
		 */
		class ResultValue
		{
		public:
			friend class Result;
			// retrieveCellConten can access to m_entry;
			/**
			 * constructor
			 */
			ResultValue(const Result* const p_result,
						const unsigned long p_entryId,
						const unsigned long p_attributeId,
						const std::string &p_attributeName)
				throw();

			/**
			 * Contructor
			 */
			ResultValue(const ResultValue &p_other)
				throw();
			/**
			 * Destructor
			 */
			~ResultValue()
				throw();

			/**
			 * Assignment operator
			 */
			const ResultValue& operator =(const ResultValue& p_other)
				throw();

			/**
			 * Retrieve the text content of the value
			 * @return Text contet of the value
			 */
			const std::vector<std::string > & getText() const
				throw(nettone::tools::Exception);

			/**
			 * Retrieve all the value in one string
			 * @eturn Text value of the attribute
			 */
			std::string	getString() const
				throw(nettone::tools::Exception);

			/**
			 * Retrieve the attributeName of the value
			 * @return String value
			 */
			std::string	getAttributeName() const
				throw(nettone::tools::Exception);


			/**
			 * Verify is the Value is null
			 * @return true if the Value is null
			 */
			bool	isNull() const
				throw(nettone::tools::Exception);

		private :
			/**
			 * Structure to store the content of the Value
			 */
			struct Content
			{
				std::vector<std::string>	text;
				bool				isNull;
			};

			/**
			 * Looking for the conten this value and store it
			 */
			void retrieveContent() const
				throw(nettone::tools::Exception);

			/**
			 * Set the content of this value
			 *
			 * @param p_text	Content in text format
			 * @param p_isNull	true if cell is null, otherwise false
			 */
			void setContent(const std::vector<std::string>& p_text,
							bool p_isNull) const
				throw();

			/**
			 * Pointer to the resultset that containt this value
			 */
			const Result* const	m_result;

			/**
			 * Entry number that contain this value;
			 */
			unsigned long		m_entryId;

			/**
			 * id attribute;
			 */
			unsigned long		m_attributeId;

			/**
			 *  name of the attribute
			 */
			mutable std::string	 m_attributeName;

			/**
			 * Content of the value
			 */

			mutable Content*	m_content;

		}; // End of the class LdapRequestor::Resultvalue

		class Connexion
		{
		public:
			/**
			 * Connexion configuration struct
			 */
			struct Config {
				/**
				 * Name of the host where LDAP server is located
				 */
				std::string		hostname;

				/**
				 * Username for access to the database
				 */
				std::string		username;

				/**
				 *  Password for access LDAP
				 */
				std::string		password;

				/**
				 * Optional Port
				 * Default is LDAP port 389
				 */
				short			port;

				/**
				 * Limit time for a request to wait for the result of a seache to complete
				 */
				struct timeval	*timeout;

			}; // End of struct Config

			/**
			 * Status of connection
			 */
			enum CnxStatus
			{
			 CONNECTED,
			 NOT_CONNECTED
			};
			/**
			 * Constructor
			 */
			Connexion()
				throw();

			/**
			 * Destructor
			 */
			~Connexion()
				throw();

			/**
			 * Configure and initialize the connection
			 *
			 * @param conf Configuration information
			 */
			void init (const Config& p_config)
				throw(nettone::tools::Exception);

			/**
			 * Send a LDAP Query to LDAP client that the result
			 *
			 * @param p_query the query to be executed
			 * @param p_result a pointer to the result retrieved
			 */
			void search(const std::string& p_base,
						int p_scope,
						const std::string& p_filter,
						const std::vector<std::string>& p_attrs,
						Result* const p_result)
				throw(nettone::tools::Exception);

			/**
			 * Send a LDAP Query to LDAP client that the result
			 * Scope is Subtree
			 *
			 * @param p_query the query to be executed
			 * @param p_result a pointer to the result retrieved
			 */
			void search(const std::string& p_base,
						const std::string& p_filter,
						const std::vector<std::string>& p_attrs,
						Result* const p_result)
				throw(nettone::tools::Exception);

			/**
			 * Add data to ldap
			 * This add is only for single values attribute
			 */
			void add(const std::string& p_dn,
					 const std::map<std::string, std::string>& p_attrs)
				throw(nettone::tools::Exception);

			/**
			 * Delete DN to ldap (not recursive)
			 */
			void del(const std::string& p_dn)
				throw(nettone::tools::Exception);

			/**
			 * Add attribute value
			 * This add is only for single values attribute
			 */
			void modAdd(const std::string& p_dn,
						const std::map<std::string, std::string>& p_attrs)
				throw(nettone::tools::Exception);

			/**
			 * Replace attribute value
			 * This add is only for single values attribute
			 */
			void modRep(const std::string& p_dn,
						const std::map<std::string, std::string>& p_attrs)
				throw(nettone::tools::Exception);

			/**
			 * Delete attribute value, if attr is empty string, will remove all values
			 * This delete is only for single values attribute
			 */
			void modDel(const std::string& p_dn,
						const std::map<std::string, std::string>& p_attrs)
				throw(nettone::tools::Exception);

			/**
			 * Get status of the connection
			 * @return Statu of the connection
			 */
			CnxStatus getCnxStatus() const
				throw();

			/**
			 *  Get hostname of the connection
			 *
			 * @return hostname of this connection
			 */
			const std::string& getHostname() const
				throw();

		private:
			/// @name Forbidden methodes
			/// @{
			Connexion(const Connexion& p_other);
			const Connexion& operator =(const Connexion& p_other);
			////@}

			/**
			 * Set the status for this connexion.
			 *
			 * @param p_status New connection status
			 */
			void setStatus(const CnxStatus& p_status) const
				throw();

			/**
			 * Connect to the LDAP directory
			 */
			void connect()
				throw(nettone::tools::Exception);

			/**
			 * Disconnect to the LDAP library
			 */
			void disconnect()
				throw();

			/**
			 * Handle of LDAP connection
			 */
			LDAP			*m_sock;

			/**
			 * LDAP Result
			 */
			LDAPMessage		*m_result;

			/**
			 * Status of the connexion
			 */
			mutable CnxStatus	m_status;

			/**
			 * Connexion Configuration
			 */
			Config m_config;

		}; // End of class LdapRequestor::Connection

		struct Config
		{
			/**
			 * configuration struct of the connexion
			 */
			Connexion::Config	cnxConf;

			/**
			 * Maximal number of connexions;
			 */
			unsigned		maxNbCnx;

			/**
			 * Maximal number of stand by connexions
			 */
			unsigned		maxSbCnx;

			/**
			 * Default maximal number of connexions
			 */

			/*
			  enum {
			  DEFAULT_MAX_CONNEXIONS = 5,
			  DEFAULT_MAX_STANDBYCONNEXIONS = 2;
			  };
			*/
		}; // End of struct LdapRequestor::Config

		/**
		 * Constructor
		 */
		LdapRequestor()
			throw();

		/**
		 * Destructor
		 */
		~LdapRequestor()
			throw();

		/**
		 * Configure and initialize LdapRequestor
		 *
		 * @param conf Configuration information.
		 */
		void init(const Config& p_config)
			throw();

		/**
		 * Get a connexion from the pool
		 *
		 * @return Pointer to a connexion, NULL if no connexion is available
		 */
		Connexion* getCnx()
			throw(nettone::tools::Exception);

		/**
		 * Release a connexion
		 *
		 * @param p_cnx Connexion to be released
		 */
		void releaseCnx(Connexion*  const p_cnx)
			throw(nettone::tools::Exception);

		/**
		 * Number of active Connection
		 *
		 * @return Number of active connexion
		 */
		unsigned long getActiveConnexionsCount() const
			throw(nettone::tools::Exception);

		/**
		 * Number of stand by Connexions
		 *
		 * @return Numberof stand-by connexions
		 */
		unsigned long getStandbyConnexionsCount() const
			throw(nettone::tools::Exception);

	private:
		/// @name Forbidden methods
		/// @{
		LdapRequestor(const LdapRequestor& p_other);
		const LdapRequestor& operator =(const LdapRequestor& p_other);
		///@}

		/**
		 * Release all connexions
		 */
		void releaseAllCnx()
			throw();

		/**
		 * List of active Connexions
		 */
		std::list<Connexion*>			m_activeConnexions;

		/**
		 * List of stand by connexion
		 */
		std::list<Connexion*>			m_standbyConnexions;

		/**
		 * Mutex
		 */
		std::unique_ptr<nettone::tools::Mutex>	m_mutex;

		/**
		 * Ldap configuration
		 */
		Config					m_config;

		/**
		 * Indicator 'true' if LdapRequestor is initialized, 'false' otherwise
		 */
		bool					m_initialized;

	}; // End of class LdapRequestor
}
