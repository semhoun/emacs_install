#ifndef __NETTONE_TOOLS_IDMANAGER_H__
#define __NETTONE_TOOLS_IDMANAGER_H__


#include <ostream>
#include <list>

#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Id Manager ports.
		 */
		template <class T>
		class IdManager
		{
		public:
			IdManager(const T& p_first,
					  const T& p_last,
					  const bool p_checkRelease = false)
				throw (nettone::tools::Exception);

			~IdManager()
				throw ();

			void release(const T& p_entry)
				throw (nettone::tools::Exception);

			T get()
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			IdManager(const IdManager& p_other);
			const IdManager& operator = (const IdManager& p_other);
			/// @}

			/**
			 * Ids.
			 */
			typedef std::list<T> IdList;
			IdList m_ids;
			
			/**
			 * Last id to create
			 */
			T m_lastId;

			/**
			 * Last created id
			 */
			T m_currentId;

			/**
			 * Check if entry released has not already been released
			 */
			bool m_checkRelease;
		};
	}
}


#include "nettone_tools_IdManager.ih"


#endif // __NETTONE_TOOLS_IDMANAGER_H__
