#ifndef __NETTONE_TOOLS_THREADPOOL_H__
#define __NETTONE_TOOLS_THREADPOOL_H__


#include <list>

#include "nettone_tools_Thread.h"
#include "nettone_tools_Monitor.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Pool of thread
		 */
		class ThreadPool
		{
		public:
			/**
			 * Configuration.
			 */
			struct Config
			{
				/**
				 * Ideal number of request processors.
				 */
				unsigned short nbProcessors;

				/**
				 * Minimal number of request processors.
				 */
				unsigned short nbProcessorsRequired;

				/**
				 * Max number of pending requests.
				 */
				unsigned short nbMaxPendingRequests;
			};

			/**
			 * Type of the request ID.
			 */
			class RequestId
			{
			public:
				/**
				 * The null object.
				 */
				static const RequestId null;

				/**
				 * Return a new unique RequestId object.
				 * Value loops on 32 bits unsigned.
				 */
				static RequestId getNewId()
					throw ();

				/**
				 * Constructor.
				 */
				RequestId()
					throw ();

				/**
				 * Casting to a unsigned long.
				 */
				operator unsigned long() const
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator ==(const RequestId& p_other)
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator !=(const RequestId& p_other)
					throw ();

				/**
				 * Assignement operator.
				 */
				const RequestId& operator =(const RequestId& p_other)
					throw ();

			private:
				/**
				 * Constructor.
				 */
				RequestId(const unsigned long p_reqId)
					throw ();

				/**
				 * The ID itself.
				 */
				unsigned long m_reqId;
			};

			/**
			 * Base class of all requests
			 */
			class IRequest
			{
			public:
				/**
				 * Destructor.
				 */
				virtual ~IRequest() {}

				/**
				 * Methods called by the processor.
				 *
				 * @param p_reqId ID of the request.
				 * @param p_key   The key provided at registration time.
				 */
				virtual void process(const RequestId p_reqId,
									 void* const p_key)
					throw () = 0;
			};

			/**
			 * Constructor.
			 */
			ThreadPool()
				throw (Exception);

			/**
			 * Destructor.
			 */
			~ThreadPool()
				throw ();
				
			/**
			 * Possible states.
			 */
			enum State
			{
				IDLE,    /**< do nothing. */
				RUNNING, /**< process pending requests and accept new */
				STOPPING /**< process pending requests and, please, stopping scheduling new jobs. */
			};
			
			/**
			 * Start the pool.
			 *
			 * @param p_config The runtime configuration.
			 */
			void start(const Config& p_config)
				throw (Exception);

			/**
			 * Request the thred pool to stop, and wait for request completion.
			 */
			void stop()
				throw ();

			/**
			 * Schedule an event for further processing.
			 *
			 * @param p_reqId    Where to stock the ID of request.
			 * @param p_request  The task to schedule.
			 * @param p_key      Request identifier.
			 */
			void postRequest(RequestId& p_reqId,
							 IRequest* const p_request,
							 void* const p_key)
				throw (Exception);

			/**
			 * Cancel a task processing.
			 * 
			 * @param p_reqId The request ID.
			 */
			void cancelRequest(const RequestId p_reqId)
				throw (Exception);

		private:
			/// @name Forbidden methods
			/// @{
			ThreadPool(const ThreadPool& p_other);
			const ThreadPool& operator =(const ThreadPool& p_other);
			/// @}

			/**
			 * Task managing the requests.
			 */
			class RequestProcessor
				: public Thread
			{
			public:
				/**
				 * Constructor.
				 *
				 * @param p_this The outer object.
				 */
				RequestProcessor(ThreadPool* const p_this)
					throw (Exception);

				/**
				 * Destructor.
				 */
				virtual ~RequestProcessor()
					throw ();

			protected:
				/**
				 * Interface notified when the stop request is conpleted.
				 */ 
				class IStop
				{
				public:
					virtual ~IStop() {}
					virtual void handleRequestProcessorStop()
						throw () = 0;
				};
				
				/**
				 * Request the thread pool to stop.
				 *
				 * @param p_handler    Who to notify when the last task has been processed.
				 */
				void requestStop(IStop* const p_handler)
					throw ();
					
			private:
				/// @name Methods from Thread
				/// @{
				bool mustStop()
					throw ();
					
				virtual void run()
					throw ();
				/// @}

				/**
				 * Outer object.
				 */
				ThreadPool* const m_this;
				
				/**
				 * Handler to notify when thread stopped.
				 */
				IStop* m_handler;
			};
			friend class RequestProcessor;

			/**
			 * Processors of request.
			 */
			std::list<RequestProcessor*> m_procs;
			
			/**
			 * Descriptor of a processing request.
			 */
			struct Request
			{
			public:
				/**
				 * The task to process.
				 */
				IRequest* req;

				/**
				 * The key identifying the request.
				 */
				void* key;

				/**
				 * Request ID.
				 */
				RequestId reqId;
			};

			/**
			 * Deferred tasks queue.
			 */
			std::list<Request> m_requests;
			
			/**
			 * Monitor access to the list of pending requests.
			 */
			Monitor* m_monitor;
			
			/**
			 * Server configuration
			 */
			Config m_config;

			/**
			 * Current state.
			 */
			State m_state;

			/**
			 * Indicate if the server must stop just after the current deferred task,
			 * or if it must process all pending request.
			 */
			bool m_smoothStop;
		};
	}
}


#endif // __NETTONE_TOOLS_THREADPOOL_H__

