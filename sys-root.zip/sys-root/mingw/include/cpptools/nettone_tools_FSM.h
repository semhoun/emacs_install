#ifndef __NETTONE_TOOLS_FSM_H__
#define __NETTONE_TOOLS_FSM_H__


#include <map>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		/** 
		 * Base class of user-defined FSM.
		 */
		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		class FSM
		{
		public:
			/// @name Construction/destruction
			/// @{
			FSM(const STATE& p_initialState,
				const DEFAULTHANDLER& p_defaultHandler);
			virtual ~FSM() {}
			/// @}
			
			void handleEvent(const EVENT& p_event,
							 void* const& p_data);
			bool isInFinalState() const;

		protected:
			void registerHook(const STATE& p_state,
							  const EVENT& p_event,
							  const HANDLER& p_handler,
							  const STATE& p_nextState,
							  const bool p_isFinal = false)
				throw (Exception);

			STATE getPreviousState() const;
			STATE getCurrentState() const;

		private:
			bool isFinalState(const STATE& p_state) const;

			DEFAULTHANDLER m_defaultHandler;

			STATE m_previousState;
			STATE m_currentState;

			typedef std::map<STATE, bool> FinalStatesMap;
			FinalStatesMap m_finalStatesMap;

			typedef std::pair<STATE, EVENT> TKey;
			typedef std::pair<HANDLER, STATE> TChange;
			typedef std::map<TKey, TChange> TransitionMap;
			TransitionMap m_transitionMap;
		};

		template <typename T>
		struct SHandler
		{
			SHandler(T* const p_this,
					 void (T::* p_handler)(void* const& p_data))
				: m_this(p_this),
				  m_handler(p_handler)
			{
			}

			T* m_this;
			void (T::* m_handler)(void* const& p_data);
			void operator ()(void* const& p_data)
			{
				(m_this->*m_handler)(p_data);
			}
		};

		template <typename T>
		SHandler<T> makeFSMHandler(T* const p_this,
								   void (T::* p_handler)(void* const& p_data))
		{
			return SHandler<T>(p_this, p_handler);
		}

		template <typename T, typename STATE, typename EVENT>
		struct SDefaultHandler
		{
			SDefaultHandler(T* const p_this,
							void (T::* p_handler)(const STATE& p_state,
												  const EVENT& p_event,
												  void* const& p_data))
				: m_this(p_this),
				  m_handler(p_handler)
			{
			}

			T* m_this;
			void (T::* m_handler)(const STATE& p_state,
								  const EVENT& p_event,
								  void* const& p_data);
			void operator ()(const STATE& p_state,
							 const EVENT& p_event,
							 void* const& p_data)
			{
				(m_this->*m_handler)(p_state, p_event, p_data);
			}
		};

		template <typename T, typename STATE, typename EVENT>
		SDefaultHandler<T, STATE, EVENT> makeFSMDefaultHandler(T* const p_this,
															   void (T::* p_handler)(const STATE& p_state,
																					 const EVENT& p_event,
																					 void* const& p_data))
		{
			return SDefaultHandler<T, STATE, EVENT>(p_this, p_handler);
		}
	}
}


#include "nettone_tools_FSM_i.h"


#endif // __NETTONE_TOOLS_FSM_H__
