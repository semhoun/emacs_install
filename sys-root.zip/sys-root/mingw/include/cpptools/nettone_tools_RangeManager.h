#ifndef __NETTONE_TOOLS_RANGEMANAGER_H__
#define __NETTONE_TOOLS_RANGEMANAGER_H__


#include <ostream>
#include <list>

#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Manager of range of values.
		 */
		template <class T>
		class RangeManager
		{
		public:
			RangeManager()
				throw ();

			~RangeManager()
				throw ();

			/**
			 * A range.
			 */
			class Range
			{
				friend class RangeManager;

			public:
				Range(const T& p_first,
					  const T& p_last,
					  const bool p_fill = true)
					throw (nettone::tools::Exception);

				bool isEmpty() const
					throw ();

				T get()
					throw (nettone::tools::Exception);

				void release(const T& p_entry)
					throw (nettone::tools::Exception);

				struct Span
				{
					T first;
					T last;
				};

				const Span& getBounds() const
					throw ();

				unsigned short getSpanCount() const
					throw ();

				const Span& getSpan(const unsigned short p_at) const
					throw (nettone::tools::Exception);

			private:
				/// @name Forbidden methods
				/// @{
				Range(const Range& p_other);
				const Range& operator = (const Range& p_other);
				/// @}
				
				Span m_full;
				
				typedef std::list<Span> SpanList;
				SpanList m_spans;
			};

			void addRange(const T& p_first,
						  const T& p_last,
						  const bool p_fill = true)
				throw (nettone::tools::Exception);

			void removeRange(const T& p_first,
							 const T& p_last)
				throw (nettone::tools::Exception);

			T get()
				throw (nettone::tools::Exception);
			
			void release(const T& p_entry)
				throw (nettone::tools::Exception);

			unsigned short getRangeCount() const
				throw ();

			const Range& getRange(const unsigned short p_at) const
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			RangeManager(const RangeManager& p_other);
			const RangeManager& operator = (const RangeManager& p_other);
			/// @}

			/**
			 * Ranges.
			 */
			typedef std::list<Range*> RangeList;
			RangeList m_ranges;
		};

// -----

		template <unsigned short OFFSET>
		struct TSpan
		{
			TSpan(const unsigned short p_base = 0)
				: m_base(p_base)
			{
			}
			
			TSpan operator +(const unsigned short p_inc) const
			{
				return TSpan(m_base + p_inc * OFFSET);
			}
			
			TSpan operator -(const unsigned short p_inc) const
			{
				return TSpan(m_base - p_inc * OFFSET);
			}
			
			void operator ++()
			{
				m_base += OFFSET;
			}
			
			void operator --()
			{
				m_base -= OFFSET;
			}
			
			bool operator >(const TSpan& p_other) const
			{
				return m_base > p_other.m_base;
			}

			bool operator <(const TSpan& p_other) const
			{
				return m_base < p_other.m_base;
			}

			bool operator <=(const TSpan& p_other) const
			{
				return m_base <= p_other.m_base;
			}

			bool operator ==(const TSpan& p_other) const
			{
				return p_other.m_base == m_base;
			}

			const TSpan& operator =(const TSpan& p_other)
			{
				m_base = p_other.m_base;
				return *this;
			}

			unsigned short m_base;
		};
	}
}


#include "nettone_tools_RangeManager.ih"


#endif // __NETTONE_TOOLS_RANGEMANAGER_H__
