#ifndef __NETTONE_TOOLS_THREAD_H__
#define __NETTONE_TOOLS_THREAD_H__


#include <string>
#include <pthread.h>

#include "nettone_tools_Exception.h"
#include "nettone_tools_IRunnable.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Wrapper around Pthread threads.
         *
         * In the case the constructor is provided a IRunnable object, that object is NOT owned by the thread. It is thereby
         * the responsability of the caller to destroy that object, AFTER the thread is finished with it.
		 */
		class Thread
		{
		public:
			class IObserver
			{
			public:
				virtual ~IObserver() {}
				
				/** 
				 * This handler is provided by the initiator thread, but called once by
				 * the NEW thread, just before processing the run() method.
				 */
				virtual void handleThreadStarted()
					throw () = 0;
                
				/**
				 * This handler is provided by the initiator thread, but called once by
				 * the NEW thread, just before it is terminated.
				 */
				virtual void handleThreadStopped()
					throw () {};
			};

            /// @name Construction/destruction
            /// @{
			Thread(const char* const p_name);
			Thread(IRunnable* const& p_target,
                   const char* const p_name);
			virtual ~Thread();
            /// @}

			/**
			 * Return the thread ID.
			 */
			unsigned long getId() const
				throw ();

			/**
			 * Start the thread.
			 */
			virtual void start(const bool p_detach = false,
							   IObserver* const p_observer = NULL)
				throw (Exception);

			class IStop
			{
			public:
				virtual ~IStop() {}
				virtual void handleStop()
					throw () = 0;
			};

			/**
			 * Request the thread to stop.
			 */
			virtual void stop(IStop* const p_observer = NULL)
				throw ();

			/**
			 * Join the thread. The caller is blocked until the target thread ends.
			 */
			void join()
				throw (Exception);

			/**
			 * Return true if the tested Thread object "is" the caller thread. 
			 */
			bool isCurrent() const
				throw ();

			/**
			 * Make sleep the calling thread for the delay specified in millisec.
			 *
			 * @param p_delay The delay in millisec.
			 */
			static void sleep(const unsigned long p_delay)
				throw (Exception);

		protected:
			/**
			 * Tell if the task must stop.
			 *
			 * @retval true  If the task must stop.
			 * @retval false If the task is not requested to stop.
			 */
			virtual bool mustStop()
				throw ();

			/**
			 * Body of the thread.
			 */
			virtual void run();

		private:
			void setId(const unsigned long p_id)
				throw ();

			/**
			 * Routine bootstraping a Thread. Call run() and catch exceptions.
			 */
			static void* threadBootRoutine(void* const p_this);

			/// @name Forbidden methods
			/// @{
			Thread(const Thread& p_other);
			const Thread& operator =(const Thread& p_other);
			/// @}

			/**
			 * Tell if the thread is successfully started.
			 */
			bool m_isStarted;

			/**
			 * id of the underlying pthread.
			 */
			pthread_t m_threadId;

			/**
			 * ID of the linux process incarnating the thread. 
			 */
			unsigned long p_linuxProcId;

			/**
			 * Task name
			 */
			std::string m_name;

			/**
			 * Set to true when the thread is ask to stop
			 */
			bool m_mustStop;
			
			/** Observer to notify when run() is finished.
			 *
			 */
			IStop* m_stopObserver;

            /** The object whose run method is called. */
            IRunnable* const m_target;
		};
	}
}


#endif // __NETTONE_TOOLS_THREAD_H__
