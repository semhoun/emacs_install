#ifndef __KERTEL_CONVERTER_PCM_TO_MP3_FLAG__
#define __KERTEL_CONVERTER_PCM_TO_MP3_FLAG__


// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <vector>
#include <cstring>
#include <sstream>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "lame/lame.h"


namespace nettone {
	namespace codec {

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Constants
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	const int32_t	PCM_TO_MP3_CONVERTER_MP3_BUFFER_SIZE 		= 8192;
	const int32_t	PCM_TO_MP3_CONVERTER_PCM_INPUT_SAMPLE_RATE 	= 8000;


	//==============================================================
	// Conversion time comparison betweem [RTP->PCM] and [PCM->MP3]
	//==============================================================

	class ConverterPcmToMp3
	{
	private:
		ConverterPcmToMp3 (const ConverterPcmToMp3&) throw ();			// forbid copy
		ConverterPcmToMp3& operator= (const ConverterPcmToMp3&) throw (); // forbid copy

		bool						m_ConversionInProgress;
		lame_t						m_LameHandle;
		uint8_t						m_Mp3Buffer[PCM_TO_MP3_CONVERTER_MP3_BUFFER_SIZE]; // result of conversion from PCM to MP3
		uint64_t					m_ConversionDurationInSecondLast;
		uint64_t					m_ConversionDurationInSecondMax;

	public:
		ConverterPcmToMp3			() throw ();
		~ConverterPcmToMp3			() throw ();
		void	Reset				() throw ();
		void	BeginConversion		(int32_t& p_Iret) throw ();
		int32_t ConvertFromPcmToMp3	(int16_t *	p_EncodedData, uint32_t	p_EncodedDataLen, uint8_t *& p_DecodedData, int32_t& p_DecodedDataLen) throw ();
		int32_t FlushConversion		(uint8_t *&  p_DecodedData, int32_t& p_DecodedDataLen) throw ();
		int32_t EndConversion		() throw ();
		void	GetStats			(uint64_t& p_ConversionDurationInSecondLast, uint64_t& p_ConversionDurationInSecondMax) throw ();
	};

	}// namespace codec
} // namespace nettone

#endif // __KERTEL_CONVERTER_PCM_TO_MP3_FLAG__
