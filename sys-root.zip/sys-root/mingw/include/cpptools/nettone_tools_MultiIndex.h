#ifndef __NETTONE_TOOLS_MULTIINDEX_H__
#define __NETTONE_TOOLS_MULTIINDEX_H__


#include <map>


namespace nettone
{
	namespace tools
	{
		template <typename K1, typename K2>
		class MultiIndex
		{
		public:
			struct Value
			{
				K1 k1;
				K2 k2;
			};

			void insert(const K1& p_k1,
						const K2& p_k2)
			{
				Value v = {p_k1, p_k2};

				typename MapByK1::value_type v1 = std::make_pair(p_k1, v);
				m_index1.insert(v1);

				typename MapByK2::value_type v2 = std::make_pair(p_k2, v);
				m_index2.insert(v2);
			}

			void erase1(const K1& p_k)
			{
				try {
					Value v = find1(p_k);
					erase(v);
				}
				catch (...) {
				}
			}

			void erase2(const K2& p_k)
			{
				try {
					Value v = find2(p_k);
					erase(v);
				}
				catch (...) {
				}
			}

			Value& find1(const K1& p_k)
				throw (nettone::tools::Exception)
			{
				typename MapByK1::iterator i = m_index1.find(p_k);
				if (i == m_index1.end()) {
					throw nettone::tools::Exception("not found"); // <==
				}

				return i->second;
			}
		
			Value& find2(const K2& p_k)
				throw (nettone::tools::Exception)
			{
				typename MapByK2::iterator i = m_index2.find(p_k);
				if (i == m_index2.end()) {
					throw nettone::tools::Exception("not found"); // <==
				}

				return i->second;
			}
		
		private:
			void erase(const Value& p_v)
			{
				m_index1.erase(p_v.k1);
				m_index2.erase(p_v.k2);
			}

			typedef std::map<K1, Value> MapByK1;
			MapByK1 m_index1;

			typedef std::map<K2, Value> MapByK2;
			MapByK2 m_index2;
		};
	}
}


#endif // __NETTONE_TOOLS_MULTIINDEX_H__
