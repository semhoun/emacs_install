/**
 * @file   nettone_tools_LineParser.h
 * @author Nathanael Semhoun
 * @date   Mon Oct 17 10:57:06 2005
 * 
 * @brief  Line parser
 */

#ifndef __NETTONE_TOOLS_LINEPARSER__
#define __NETTONE_TOOLS_LINEPARSER__


#include <map>

#include "nettone_tools_Exception.h"
#include "nettone_tools_Mutex.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Parser of command lines.
		 * Extract pairs parameter/value.
		 * Each parameter must be defined as follow :
		 *   -parameterName=parameterValue
		 * or 
		 *   -parameterName
		 *
		 * example :
		 *     ./mycommand -conf=filename.txt -useConfig
		 *     param "conf" is "filename.txt"
		 *     param "useConfig" is defined.
		 */
		class LineParser
		{
		public:
			/**
			 * Contructor.
			 */
			LineParser() throw ();

			/**
			 * Destructor.
			 */
			~LineParser() throw ();
			
			/** 
			 * Parse a command line defined by the standardized argc/argv and 
			 * extract a map of pair <parameter/value>. If a parameter is simply
			 * defined (e.g. -useParam) without value, it associated value is the
			 * empty string ("").
			 * 
			 * @param p_argc Number of arguments.
			 * @param p_argv List of arguments.
			 */
			void parse(const int p_argc,
					   const char* const * const p_argv) throw (Exception);
			
			/**
			 * Get the value of a parameter.
			 * 
			 * @param p_param Name of the parameter.
			 *
			 * @return The value of the parameter, or "" if the parameter has
			 *         no value.
			 */
			std::string getValue(const std::string& p_param) throw (Exception);

		private:
			/// @name Forbidden methods.
			/// @{
			LineParser(const LineParser& p_other);
			const LineParser& operator =(const LineParser& p_other);
			/// @}

			/**
			 * @var StringMap m_paramValue
			 * Map of pair <parameter/value>, indexed by parameter name.
			 */
			typedef std::map<std::string, std::string> StringMap;
			StringMap m_paramValue;

			/**
			 * Mutex for the map
			 */
			Mutex m_mutex;
		};
	}
}


#endif // __NETTONE_TOOLS_LINEPARSER__
