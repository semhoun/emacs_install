#ifndef __NETTONE_CRYPTO_PKCS7_H__
#define __NETTONE_CRYPTO_PKCS7_H__


#include <openssl/pkcs7.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		class PKCS7Verify;


		/**
		 * Toolkit class to handle PKCS7 certificate
		 *  openssl crl2pkcs7 -nocrl -certfile user.crt -certfile server.crt -out user.p7c
		 */
		class PKCS7
		{
			friend class PKCS7Verify;

		public:
			/**
			 * Constructor.
			 */
			PKCS7(const char* p_data,
				  const unsigned long p_length)
				throw(nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			~PKCS7()
				throw();

			RSA* getRSA()
				throw (nettone::tools::Exception);
			
		private:
			/// @name Forbidden methods
			/// @{
			PKCS7(const PKCS7& p_other);
			const PKCS7& operator =(const PKCS7& p_other);
			/// @}

			::PKCS7* m_pkcs7;
		};
	}
}


#endif // __NETTONE_CRYPTO_X509_H__
