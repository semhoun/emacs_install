#ifndef __NETTONE_TOOLS_MENDELEIV_H__
#define __NETTONE_TOOLS_MENDELEIV_H__


#include <string>

#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Utility class used to print out Mendeleiev table.
		 */ 
		class Mendeleiev
		{
		public:
			/**
			 * Return the name of an element identified by its number.
			 *
			 * @param p_element   The number of the element to be highlighted.
			 *
			 * @note This method should be in a separated classe, because it has no depencies
			 *        from element to Mendeleiev table.
			 */
			static const std::string getElementName(const unsigned short p_element)
				throw (nettone::tools::Exception);

			/**
			 * Return a string containing the Mendeleiev table.
			 * 
			 * @note http://fr.wikipedia.org/wiki/Tableau_p%C3%A9riodique_des_%C3%A9l%C3%A9ments) 
			 */
			static const std::string& getMendeleievTable()
				throw ();

			/**
			 * Return a string containing the Mendeleiev table, with an element highlighted.
			 *
			 * @param p_element   The number of the element to be highlighted.
			 * @param p_outString Where to store the string.
			 * 
			 * @note http://fr.wikipedia.org/wiki/Tableau_p%C3%A9riodique_des_%C3%A9l%C3%A9ments) 
			 */
			static void getMendeleievTable(const unsigned short p_element, 
										   std::string& p_outString)
				throw (nettone::tools::Exception);
		};
	}
}


#endif // __NETTONE_TOOLS_MENDELEIV_H__
