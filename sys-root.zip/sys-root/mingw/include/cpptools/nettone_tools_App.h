#ifndef __NETTONE_TOOLS_APP_H__
#define __NETTONE_TOOLS_APP_H__


#include <memory>
#include <vector>
#include <string>

#include "cpptools/nettone_tools_LineParser.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Application class.
		 *
		 * @warning This class is not thread safe.
		 */
		class App
		{
		public:
			/**
			 * Constructor.
			 */
			App();

			/**
			 * Destructor.
			 */
			virtual ~App();

			/**
			 * Start the application.
			 * Return when the application is finished initialized and run()
			 * can be called.
			 * 
			 * @param p_argc Argument count.
			 * @param p_argv Array of string pointers.
			 *
			 * @return Application return code.
			 * @retval  0 Application initialized successfully.
			 * @retval -1 Application errored during initialization.
			 */
			virtual int start(const int p_argc,
							  const char* const * const p_argv) = 0;

			/**
			 * Body of the application. Must be called only is start() has
			 * returned 0.
			 */
			virtual void run() = 0;

			/**
			 * Stop the application.
			 * Usually, post a stop request, that will yield run() to quit.
			 */
			virtual void stop() = 0;

			/**
			 * Try to get the value associated to a parameter of the command line,
			 * whatever its place in the list of parameters.
			 * If not defined, a exception is raised.
			 * If the parameter has no value, an empty string is returned.
			 * 
			 * @param p_paramName Name of the parameter to get.
			 */ 
			std::string getParam(const std::string& p_paramName) const;

		protected:
			/**
			 * Initialize attribute m_params.
			 * Developper will use this method when overriding the start() method.
			 * 
			 * @param p_argc Argument count.
			 * @param p_argv Array of string pointers.
			 */
			void setupParameters(const int p_argc,
								 const char* const * const p_argv);

		private:
			/// @name Forbiden methods
			/// @{
			App(const App& p_other);
			App& operator =(const App& p_other);
			/// @}

			/** Command line parameters. */
			std::unique_ptr<nettone::tools::LineParser> m_lineParser;

			/** Set to true when the application has been started. */
			bool m_started;
		};
	}
}


#endif // __NETTONE_TOOLS_APP_H__
