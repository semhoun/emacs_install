#ifndef __nettone_tools_Buffer__
#define __nettone_tools_Buffer__


namespace nettone
{
	namespace tools
	{
		/**
		 * A Buffer is a one chunk memory block used to store simple data objects.
		 */
		template <typename DataType>
		class Buffer
		{
		public:
			typedef DataType value_type;

			/** @name Iterators */
			//@{
			typedef DataType* iterator;
			typedef const DataType* const_iterator;
			//@}

			/**
			 * Constructor.
			 * 
			 * @param p_size Number of item in the buffer.
			 * 
			 * @exception Exception Thrown on memory allocation failure.
			 */
			Buffer(unsigned long p_size);

			/**
			 * Destructor.
			 */
			~Buffer();

			/**
			 * Cast operator. Enable to use a Buffer where a pointer is required.
			 *
			 * @return An iterator to the first element of the buffer.
			 */
            operator iterator ();

			/**
			 * Gets the number of items the buffer can contain.
			 * 
			 * @return An unsigned long.
			 */
			unsigned long maxSize() const;

			/**
			 * Gets the number of items the buffer really contains.
			 * 
			 * @return An unsigned long.
			 */
			unsigned long realSize() const;

			/**
			 * Gets the number of items the buffer really contains.
			 * 
			 * @param p_size The number of items the buffer contains.
			 */
			void setRealSize(const unsigned long& p_size);

			/**
			 * Gets an iterator on the first element of the buffer.
			 * 
			 * @return A iterator object pointing at the first element.
			 */
			iterator begin();

			/**
			 * @todo [FIXME : Comment !]
			 */
			const_iterator begin() const;

			/**
			 * @todo [FIXME : Comment !]
			 */
			const_iterator end() const;

			/**
			 * @todo [FIXME : Comment !]
			 */
			const DataType& operator[](const unsigned long p_index) const;

			/**
			 * @todo [FIXME : Comment !]
			 */
			DataType& operator[](const unsigned long p_index);

		private:
			/** @name Forbiden methods */
			//@{
			Buffer(const Buffer<DataType>& p_other);
			const Buffer<DataType>& operator =(const Buffer<DataType>& p_other);
			//@}

			/** Data buffer. */
			DataType* m_data;

			/** Data buffer length (in item). */
			unsigned long m_size;

			/** Real number of item. */
			unsigned long m_realSize;
		};
	}
}


#include "nettone_tools_Buffer.ih"


#endif // __nettone_tools_Buffer__
