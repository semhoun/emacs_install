#ifndef __NETTONE_MAIL_SERVERMAILER_H__
#define __NETTONE_MAIL_SERVERMAILER_H__


#include <list>
#include <memory>
#include <mailutils/message.h>
#include <mailutils/address.h>

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_Thread.h"
#include "cpptools/nettone_tools_Monitor.h"


namespace nettone
{
	namespace mail
	{
		class Message;
		class Mailer;

		/**
		 * Mailer manager
		 */
		class ServerMailer
		{
		public:
			/**
			 * Creation configuration.
			 */
			struct Config
			{
				/**
				 * Max number of pending mail.
				 */
				unsigned short maxPendingMails;

				/**
				 * Number of mailer.
				 */
				unsigned short nbMailer;

				/**
				 * SMTP Server (if not set use sendmail)
				 */
				std::string smptServer;
			};

			/**
			 * Constructor
			 */
			ServerMailer()
				throw (nettone::tools::Exception);

			/**
			 * Destructor
			 */
			~ServerMailer()
				throw ();

			/**
			 * Start the server.
			 *
			 * @param p_config The runtime configuration.
			 */
			void start(const Config& p_config)
				throw (nettone::tools::Exception);
			
			/**
			 * Stop the server.
			 */
			void stop()
				throw ();

			/**
			 * Type of the request ID.
			 */
			class RequestId
			{
			public:
				/**
				 * The null object.
				 */
				static const RequestId null;

				/**
				 * Return a new unique RequestId object.
				 * Value loops on 32 bits unsigned.
				 */
				static RequestId getNewId()
					throw ();

				/**
				 * Constructor.
				 */
				RequestId()
					throw ();

				/**
				 * Casting to a unsigned long.
				 */
				operator unsigned long() const
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator ==(const RequestId& p_other)
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator !=(const RequestId& p_other)
					throw ();

				/**
				 * Assignement operator.
				 */
				const RequestId& operator =(const RequestId& p_other)
					throw ();

			private:
				/**
				 * Constructor.
				 */
				RequestId(const unsigned long p_reqId)
					throw ();

				/**
				 * The ID itself.
				 */
				unsigned long m_reqId;
			};

			/**
			 * Base interface for handlers of send result.
			 */
			class IHandlerMessageSended
			{
			public:
				/**
				 * Destructor.
				 */
				virtual ~IHandlerMessageSended()	{}

				/**
				 * Callback invoked when the mail is sended.
				 *
				 * @param p_reqId  Id of the request.
				 */
				virtual void handleMessageSended(const RequestId& p_reqId)
					throw () = 0;

				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleMessageError(const RequestId& p_reqId,
												const std::string& p_error)
					throw () = 0;
			};

			/** 
			 * Send a mail.
			 * 
			 * @param p_reqId	Where to store the ID of the request.
			 * @param p_msg		The message to send
			 * @param p_handler The handler to notify on event (error or success).
			 */
			void sendMail(RequestId& p_reqId,
						  const Message& p_msg,
						  IHandlerMessageSended* const p_handler)
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			ServerMailer(const ServerMailer& p_other);
			const ServerMailer& operator =(const ServerMailer& p_other);
			/// @}

			/**
			 * Thread used to send mail
			 */
			class ThreadMailer
				: public nettone::tools::Thread
			{
			public:
				/**
				 * Constructor
				 */
				ThreadMailer(ServerMailer& p_this,
							 const std::string& p_smtp)
					throw (nettone::tools::Exception);

				/**
				 * Destructor
				 */
				~ThreadMailer()
					throw ();

			private:
				/// @name Methods from Thread
				/// @{
				virtual void run();
				/// @}

				/**
				 * Outer object
				 */
				ServerMailer& m_this;

				/**
				 * Internal mailer
				 */
				std::unique_ptr<Mailer> m_mailer;
			};
			
			/**
			 * Server configuration
			 */
			Config m_config;

			/**
			 * List of mailers
			 */
			std::list<ThreadMailer*> m_mailers;

			/**
			 * Monitor to protect and signal message list
			 */
			std::unique_ptr<nettone::tools::Monitor> m_monitorMessage;

			/**
			 * List of message
			 */
			struct MessageInfo
			{
				/**
				 * The mail
				 */
				mu_message_t message;

				/**
				 * from
				 */
				mu_address_t from;

				/**
				 * to
				 */
				mu_address_t to;

				/**
				 * Id of the request
				 */
				RequestId reqId;

				/**
				 * Hander to send result
				 */
				IHandlerMessageSended* handler;
			};
			typedef std::list<MessageInfo> MessageList;
			MessageList m_messages;
		};
	}
}


#endif // __NETTONE_MAIL_SERVERMAILER_H__
