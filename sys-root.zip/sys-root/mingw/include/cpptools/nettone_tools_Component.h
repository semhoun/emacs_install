#ifndef __NETTONE_TOOLS_COMPONENT_H__
#define __NETTONE_TOOLS_COMPONENT_H__


#include <string>


namespace nettone
{
	namespace tools
	{
		class Component
		{
		public:
			Component(const std::string& p_libName);
			virtual ~Component();

			template <typename T>
			T getCastedSymbol(const std::string& p_name)
			{
				return (T)(getSymbol(p_name));
			}

		private:
			Component(const Component& p_other);
			const Component& operator =(const Component& p_other);
		
			void* getSymbol(const std::string& p_name);
			
			void* m_handle;
			std::string m_libName;
		};
	}
}


#endif // __NETTONE_TOOLS_COMPONENT_H__
