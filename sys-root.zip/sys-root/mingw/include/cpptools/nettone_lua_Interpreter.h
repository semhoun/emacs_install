#pragma once

#include <vector>

extern "C"
{
#include <lua5.1/lua.h>
#include <lua5.1/lauxlib.h>
#include <lua5.1/lualib.h>
}

#include "nettone_tools_Exception.h"
#include "nettone_lua_Environment.h"
#include "nettone_lua_Chunk.h"
#include "nettone_lua_WrapClass.h"


namespace nettone::lua
{
	/**
	 * Interpreter of Chunk.
	 */
	class Interpreter
		: public Environment
	{
	public:
		/**
		 * Constructor.
		 */
		Interpreter()
		throw (nettone::tools::Exception);

		/**
		 * Destructor.
		 */
		~Interpreter()
		throw ();

		/**
		 * Descriptor of a module.
		 */
		struct ModuleDesc
		{
			/**
			 * Module's function descriptor.
			 */
			struct FunctionDesc
			{
				/**
				 * Function name.
				 */
				std::string name;

				/**
				 * Function body.
				 */
				lua_CFunction body;
			};

			/**
			 * Module name.
			 */
			std::string name;

			/**
			 * Set of function descriptors.
			 */
			FunctionDesc* functions;

			/**
			 * Index meta method
			 */
			lua_CFunction index;
		};

		/**
		 * Register a new function in the global environment.
		 *
		 * @param p_name function name
		 * @param p_func function to register
		 */
		void registerFunction(const std::string& p_name,
							  lua_CFunction p_func)

			throw (nettone::tools::Exception);

		/**
		 * Register a new module in the global environment.
		 *
		 * @param p_desc Descriptor of the module.
		 */
		void registerModule(const ModuleDesc& p_desc)
			throw (nettone::tools::Exception);

		/**
		 * Register a new class in the global environment.
		 *
		 * @param p_desc Descriptor of the class.
		 */
		void registerClass(const ClassDesc& p_desc)
			throw (nettone::tools::Exception);

		/**
		 * Execute a LUA precompiled chunk.
		 *
		 * @param p_code The bytecode of the LUA program to execute.
		 */
		void process(const Chunk* p_code)
			throw (nettone::tools::Exception);

		/**
		 * Execute a LUA precompiled chunk.
		 *
		 * @param p_code The bytecode of the LUA program to execute.
		 * @param p_res Integer result of processing, if result is boolean res will be 0 (false) or 1 (true)
		 */
		void process(const Chunk* p_code,
					 double& p_res)
			throw (nettone::tools::Exception);

		/**
		 * Execute a LUA precompiled chunk.
		 *
		 * @param p_code The bytecode of the LUA program to execute.
		 * @param p_res String result of processing
		 */
		void process(const Chunk* p_code,
					 std::string& p_res)
			throw (nettone::tools::Exception);

	private:
		/// @name Forbidden methods
		/// @{
		Interpreter(const Interpreter& p_other);
		const Interpreter& operator =(const Interpreter& p_other);
		/// @}
	};
}
