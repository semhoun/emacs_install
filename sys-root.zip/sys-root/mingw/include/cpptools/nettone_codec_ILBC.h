#ifndef __KERTEL_CONVERTER_ILBC_TO_PCM_FLAG__
#define __KERTEL_CONVERTER_ILBC_TO_PCM_FLAG__



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <string.h>
#include <math.h>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_Generic.h"


namespace nettone {
	namespace codec {

#define FS                      (float)8000.0
#define BLOCKL_20MS             160
#define BLOCKL_30MS             240
#define BLOCKL_MAX              240
#define NSUB_20MS               4
#define NSUB_30MS               6
#define NSUB_MAX				6
#define NASUB_20MS              2
#define NASUB_30MS              4
#define NASUB_MAX               4
#define SUBL					40
#define STATE_LEN               80
#define STATE_SHORT_LEN_30MS    58
#define STATE_SHORT_LEN_20MS    57
#define LPC_FILTERORDER         10
#define LPC_CHIRP_SYNTDENUM     (float)0.9025
#define LPC_CHIRP_WEIGHTDENUM   (float)0.4222
#define LPC_LOOKBACK			60
#define LPC_N_20MS              1
#define LPC_N_30MS              2
#define LPC_N_MAX               2
#define LPC_ASYMDIFF			20
#define LPC_BW                  (float)60.0
#define LPC_WN                  (float)1.0001
#define LSF_NSPLIT              3
#define LSF_NUMBER_OF_STEPS     4
#define LPC_HALFORDER           (LPC_FILTERORDER/2)
#define CB_NSTAGES              3
#define CB_EXPAND               2
#define CB_MEML                 147
#define CB_FILTERLEN			2*4
#define CB_HALFFILTERLEN		4
#define CB_RESRANGE             34
#define CB_MAXGAIN              (float)1.3
#define ENH_BLOCKL              80 
#define ENH_BLOCKL_HALF         (ENH_BLOCKL/2)
#define ENH_HL                  3   
#define ENH_SLOP				2   
#define ENH_PLOCSL              20
#define ENH_OVERHANG			2
#define ENH_UPS0				4   
#define ENH_FL0                 3
#define ENH_VECTL               (ENH_BLOCKL+2*ENH_FL0)
#define ENH_CORRDIM             (2*ENH_SLOP+1)
#define ENH_NBLOCKS             (BLOCKL_MAX/ENH_BLOCKL)
#define ENH_NBLOCKS_EXTRA       5
#define ENH_NBLOCKS_TOT         8   
#define ENH_BUFL				(ENH_NBLOCKS_TOT)*ENH_BLOCKL
#define ENH_ALPHA0              (float)0.05
#define FILTERORDER_DS          7
#define DELAY_DS				3
#define FACTOR_DS               2
#define NO_OF_BYTES_20MS		38
#define NO_OF_BYTES_30MS		50
#define NO_OF_WORDS_20MS		19
#define NO_OF_WORDS_30MS		25
#define STATE_BITS              3
#define BYTE_LEN				8
#define ULP_CLASSES             3
#define FLOAT_MAX               (float)1.0e37
#define EPS                     (float)2.220446049250313e-016
#define PI                      (float)3.14159265358979323846
#define MIN_SAMPLE              -32768
#define MAX_SAMPLE              32767
#define TWO_PI                  (float)6.283185307
#define PI2                     (float)0.159154943

	extern float hpi_zero_coefsTbl[];
	extern float hpi_pole_coefsTbl[];
	extern float hpo_zero_coefsTbl[];
	extern float hpo_pole_coefsTbl[];
	extern float lpFilt_coefsTbl[];
	extern float lpc_winTbl[];
	extern float lpc_asymwinTbl[];
	extern float lpc_lagwinTbl[];
	extern float lsfCbTbl[];
	extern float lsfmeanTbl[];
	extern int   dim_lsfCbTbl[];
	extern int   size_lsfCbTbl[];
	extern float lsf_weightTbl_30ms[];
	extern float lsf_weightTbl_20ms[];
	extern float state_sq3Tbl[];
	extern float state_frgqTbl[];
	extern float gain_sq3Tbl[];
	extern float gain_sq4Tbl[];
	extern float gain_sq5Tbl[];
	extern int	search_rangeTbl[5][CB_NSTAGES];
	extern int	memLfTbl[];
	extern int	stMemLTbl;
	extern float cbfiltersTbl[CB_FILTERLEN];
	extern float polyphaserTbl[];
	extern float enh_plocsTbl[];

	typedef struct iLBC_ULP_Inst_t_ {
		int lsf_bits[6][ULP_CLASSES + 2];
		int start_bits[ULP_CLASSES + 2];
		int startfirst_bits[ULP_CLASSES + 2];
		int scale_bits[ULP_CLASSES + 2];
		int state_bits[ULP_CLASSES + 2];
		int extra_cb_index[CB_NSTAGES][ULP_CLASSES + 2];
		int extra_cb_gain[CB_NSTAGES][ULP_CLASSES + 2];
		int cb_index[NSUB_MAX][CB_NSTAGES][ULP_CLASSES + 2];
		int cb_gain[NSUB_MAX][CB_NSTAGES][ULP_CLASSES + 2];
	} iLBC_ULP_Inst_t;

	typedef struct iLBC_Enc_Inst_t_ {
		int mode;
		int blockl;
		int nsub;
		int nasub;
		int no_of_bytes, no_of_words;
		int lpc_n;
		int state_short_len;
		const iLBC_ULP_Inst_t *ULP_inst;
		float anaMem[LPC_FILTERORDER];
		float lsfold[LPC_FILTERORDER];
		float lsfdeqold[LPC_FILTERORDER];
		float lpc_buffer[LPC_LOOKBACK + BLOCKL_MAX];
		float hpimem[4];
	} iLBC_Enc_Inst_t;

	typedef struct iLBC_Dec_Inst_t_ {
		int mode;
		int blockl;
		int nsub;
		int nasub;
		int no_of_bytes, no_of_words;
		int lpc_n;
		int state_short_len;
		const iLBC_ULP_Inst_t *ULP_inst;
		float syntMem[LPC_FILTERORDER];
		float lsfdeqold[LPC_FILTERORDER];
		int last_lag;
		int prevLag, consPLICount, prevPLI, prev_enh_pl;
		float prevLpc[LPC_FILTERORDER + 1];
		float prevResidual[NSUB_MAX*SUBL];
		float per;
		unsigned long seed;
		float old_syntdenum[(LPC_FILTERORDER + 1)*NSUB_MAX];
		float hpomem[4];
		int use_enhancer;
		float enh_buf[ENH_BUFL];
		float enh_period[ENH_NBLOCKS_TOT];
	} iLBC_Dec_Inst_t;


	const iLBC_ULP_Inst_t ULP_20msTbl = {
		{ { 6,0,0,0,0 },{ 7,0,0,0,0 },{ 7,0,0,0,0 },
		{ 0,0,0,0,0 },{ 0,0,0,0,0 },{ 0,0,0,0,0 } },
		{ 2,0,0,0,0 },
		{ 1,0,0,0,0 },
		{ 6,0,0,0,0 },
		{ 0,1,2,0,0 },
		{ { 6,0,1,0,0 },{ 0,0,7,0,0 },{ 0,0,7,0,0 } },
		{ { 2,0,3,0,0 },{ 1,1,2,0,0 },{ 0,0,3,0,0 } },
		{ { { 7,0,1,0,0 },{ 0,0,7,0,0 },{ 0,0,7,0,0 } },
		{ { 0,0,8,0,0 },{ 0,0,8,0,0 },{ 0,0,8,0,0 } },
		{ { 0,0,0,0,0 },{ 0,0,0,0,0 },{ 0,0,0,0,0 } },
		{ { 0,0,0,0,0 },{ 0,0,0,0,0 },{ 0,0,0,0,0 } } },
		{ { { 1,2,2,0,0 },{ 1,1,2,0,0 },{ 0,0,3,0,0 } },
		{ { 1,1,3,0,0 },{ 0,2,2,0,0 },{ 0,0,3,0,0 } },
		{ { 0,0,0,0,0 },{ 0,0,0,0,0 },{ 0,0,0,0,0 } },
		{ { 0,0,0,0,0 },{ 0,0,0,0,0 },{ 0,0,0,0,0 } } }
	};

	const iLBC_ULP_Inst_t ULP_30msTbl = {
		{ { 6,0,0,0,0 },{ 7,0,0,0,0 },{ 7,0,0,0,0 },
		{ 6,0,0,0,0 },{ 7,0,0,0,0 },{ 7,0,0,0,0 } },
		{ 3,0,0,0,0 },
		{ 1,0,0,0,0 },
		{ 6,0,0,0,0 },
		{ 0,1,2,0,0 },
		{ { 4,2,1,0,0 },{ 0,0,7,0,0 },{ 0,0,7,0,0 } },
		{ { 1,1,3,0,0 },{ 1,1,2,0,0 },{ 0,0,3,0,0 } },
		{ { { 6,1,1,0,0 },{ 0,0,7,0,0 },{ 0,0,7,0,0 } },
		{ { 0,7,1,0,0 },{ 0,0,8,0,0 },{ 0,0,8,0,0 } },
		{ { 0,7,1,0,0 },{ 0,0,8,0,0 },{ 0,0,8,0,0 } },
		{ { 0,7,1,0,0 },{ 0,0,8,0,0 },{ 0,0,8,0,0 } } },
		{ { { 1,2,2,0,0 },{ 1,2,1,0,0 },{ 0,0,3,0,0 } },
		{ { 0,2,3,0,0 },{ 0,2,2,0,0 },{ 0,0,3,0,0 } },
		{ { 0,1,4,0,0 },{ 0,1,3,0,0 },{ 0,0,3,0,0 } },
		{ { 0,1,4,0,0 },{ 0,1,3,0,0 },{ 0,0,3,0,0 } } }
	};
	void a2lsf(float *freq, float *a);
	void lsf2a(float *a_coef, float *freq);
	void autocorr(float *r, const float *x, int N, int order);
	void window(float *z, const float *x, const float *y, int N);
	void levdurb(float *a, float *k, float *r, int order);
	void interpolate(float *out, float *in1, float *in2, float coef, int length);
	void bwexpand(float *out, float *in, float coef, int length);
	void vq(float *Xq, int *index, const float *CB, float *X, int n_cb, int dim);
	void SplitVQ(float *qX, int *index, float *X, const float *CB, int nsplit, const int *dim, const int *cbsize);
	void sort_sq(float *xq, int *index, float x, const float *cb, int cb_size);
	int LSF_check(float *lsf, int dim, int NoAn);
	void packsplit(int *index, int *firstpart, int *rest, int bitno_firstpart, int bitno_total);
	void packcombine(int *index, int rest, int bitno_rest);
	void dopack(unsigned char **bitstream, int index, int bitno, int *pos);
	void unpack(unsigned char **bitstream, int *index, int bitno, int *pos);
	void hpInput(float *In, int len, float *Out, float *mem);
	void hpOutput(float *In, int len, float *Out, float *mem);
	void AllPoleFilter(float *InOut, float *Coef, int lengthInOut, int orderCoef);
	void AllZeroFilter(float *In, float *Coef, int lengthInOut, int orderCoef, float *Out);
	void ZeroPoleFilter(float *In, float *ZeroCoef, float *PoleCoef, int lengthInOut, int orderCoef, float *Out);
	void DownSample (float  *In, float  *Coef, int lengthIn, float  *state, float  *Out);
	float xCorrCoef(float *target, float *regressor, int subl);
	int enhancerInterface(float *out, float *in, iLBC_Dec_Inst_t *iLBCdec_inst);
	void anaFilter(float *In, float *a, int len, float *Out, float *mem);
	void doThePLC(float *PLCresidual, float *PLClpc, int PLI, float *decresidual, float *lpc, int inlag, iLBC_Dec_Inst_t *iLBCdec_inst);
	void filteredCBvecs(float *cbvectors, float *mem, int lMem);
	void searchAugmentedCB(int low, int high, int stage, int startIndex, float *target, float *buffer, float *max_measure, int *best_index, float *gain, float *energy, float *invenergy);
	void createAugmentedVec(int index, float *buffer, float *cbVec);
	int FrameClassify (iLBC_Enc_Inst_t *iLBCenc_inst, float *residual);
	float gainquant(float in, float maxIn, int cblen, int *index);
	float gaindequant(int index, float maxIn, int cblen);
	void getCBvec(float *cbvec, float *mem, int index, int lMem, int cbveclen);
	void index_conv_enc(int *index);
	void index_conv_dec(int *index);
	void iCBConstruct(float *decvector, int *index, int *gain_index, float *mem, int lMem, int veclen, int nStages);
	void iCBSearch(iLBC_Enc_Inst_t *iLBCenc_inst, int *index, int *gain_index, float *intarget, float *mem, int lMem, int nStages, float *weightDenum, float *weightState, int block);
	void LSFinterpolate2a_dec(float *a, float *lsf1, float *lsf2, float coef, int length);
	void SimplelsfDEQ(float *lsfdeq, int *index, int lpc_n);
	void DecoderInterpolateLSF(float *syntdenum, float *weightdenum, float *lsfdeq, int length, iLBC_Dec_Inst_t *iLBCdec_inst);
	void LPCencode(float *syntdenum, float *weightdenum, int *lsf_index, float *data, iLBC_Enc_Inst_t *iLBCenc_inst);
	void StateConstructW(int idxForMax, int *idxVec, float *syntDenum, float *out, int len);
	void AbsQuantW(iLBC_Enc_Inst_t *iLBCenc_inst, float *in, float *syntDenum, float *weightDenum, int *out, int len, int state_first);
	void StateSearchW(iLBC_Enc_Inst_t *iLBCenc_inst, float *residual, float *syntDenum, float *weightDenum, int *idxForMax, int *idxVec, int len, int state_first);
	void syntFilter(float *Out, float *a, int len, float *mem);
	//-------------------------------------------------------------------------
	short initEncode(iLBC_Enc_Inst_t *iLBCenc_inst, int mode);
	void iLBC_encode(unsigned char *bytes, float *block, iLBC_Enc_Inst_t *iLBCenc_inst);
	//-------------------------------------------------------------------------
	short initDecode(iLBC_Dec_Inst_t *iLBCdec_inst, int mode, int use_enhancer);
	void iLBC_decode(float *decblock, unsigned char *bytes, iLBC_Dec_Inst_t *iLBCdec_inst, int mode);

	//======================================================
	// iLBC		: Sampling=20ms|PayloadSize=38 bytes
	// iLBC_13	: Sampling=30ms|PayloadSize=50 bytes
	//======================================================
	int32_t iLBC_decode (iLBC_Dec_Inst_t *iLBCdec_inst, bool p_IsILBC_13, uint8_t * p_IblcInputFrame, uint32_t p_IblcInputFrameSizeInByte, int16_t * p_PcmOutputFrame, uint32_t p_PcmOutputFrameSizeInInt16);
	int32_t iLBC_encode (iLBC_Enc_Inst_t *iLBCenc_inst, bool p_IsILBC_13, int16_t * p_PcmInputFrame, uint32_t p_PcmInputFrameSizeInInt16, uint8_t * p_IblcOutputFrame, uint32_t p_IblcOutputFrameSizeInByte);



	//========================================================================================
	// Constants for codec ILBC
	//========================================================================================
	// Notice:
	// - Block size for ILBC_20_Ms:
	//		- Compressed block size for ILBC_20_Ms		= 38  bytes
	//		- Uncompressed block size for ILBC_20_Ms	= 160 bytes
	// - Block size for ILBC_30_Ms:
	//		- Compressed block size for ILBC_30_Ms		= 50  bytes
	//		- Uncompressed block size for ILBC_30_Ms	= 240 bytes

	const uint32_t ILBC_COMPRESSED_FRAME_SIZE_20_MSEC_IN_BYTE				= 38;
	const uint32_t ILBC_COMPRESSED_FRAME_SIZE_30_MSEC_IN_BYTE				= 50;
	const uint32_t ILBC_COMPRESSED_FRAME_SIZE_60_MSEC_IN_BYTE				= 100;
	const uint32_t ILBC_COMPRESSED_FRAME_MAX_SIZE_IN_INT8					= ILBC_COMPRESSED_FRAME_SIZE_60_MSEC_IN_BYTE * 10;

	const uint32_t PCM_FRAME_SIZE_FOR_ILBC_IN_INT16							= 240; // 30ms at 8000 hz
	const uint32_t ILBC_UNCOMPRESSED_AS_PCM_FRAME_20_MSEC_SIZE_IN_INT16		= 160; // 20 msec at 8000 Hz
	const uint32_t ILBC_UNCOMPRESSED_AS_PCM_FRAME_30_MSEC_SIZE_IN_INT16		= 240; // 30 msec at 8000 Hz
	const uint32_t ILBC_UNCOMPRESSED_AS_PCM_FRAME_60_MSEC_SIZE_IN_INT16		= 480; // 30 msec at 8000 Hz
	const uint32_t ILBC_UNCOMPRESSED_AS_PCM_MAX_FRAME_SIZE					= ILBC_UNCOMPRESSED_AS_PCM_FRAME_60_MSEC_SIZE_IN_INT16 * 10;
	const int FRAME_RATE_IN_MSEC_IBLC										= 20;
	const int FRAME_RATE_IN_MSEC_IBLC_13									= 30;
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Generic functions
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	bool IsValidCompressedPayloadSizeILBC		(uint32_t p_RtpPayloadSizeInByte);
	bool IsValidCompressedPayloadSizeILBC_13	(uint32_t p_RtpPayloadSizeInByte);
	void CheckValidityOfDestBufferSizeInInt16ILBCToPcm	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt16, uint32_t& p_MinimumExpectedSizeInInt16);
	void CheckValidityOfDestBufferSizeInUint8PcmToILBC	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt8, uint32_t& p_MinimumExpectedSizeInInt8);

	class CConverterILBCToPcm : public CConverterXXX
	{
	private:
		CConverterILBCToPcm (const CConverterILBCToPcm&) throw ();				// forbid copy
		CConverterILBCToPcm& operator= (const CConverterILBCToPcm&) throw (); 	// forbid copy

		uint8_t				m_RtpPayloadType;
		int32_t				m_NbPcmBlockProduced;
		iLBC_Dec_Inst_t		m_DecoderContext;

	public:
		CConverterILBCToPcm () throw ();
		~CConverterILBCToPcm () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret, uint8_t p_RtpPayloadType) throw ();

		int32_t ConvertBufferFromILBCToPcm(	uint8_t *	p_EncodedData,
											uint32_t	p_EncodedDataLen,
											int16_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInInt16,
											uint32_t&	p_DecodedDataLenInInt16) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};



	class CConverterPcmToILBC : public CConverterXXX
	{
	private:
		CConverterPcmToILBC (const CConverterPcmToILBC&) throw ();				// forbid copy
		CConverterPcmToILBC& operator= (const CConverterPcmToILBC&) throw ();	// forbid copy

		uint8_t				m_RtpPayloadType;
		iLBC_Enc_Inst_t		m_EncoderContext;
		int32_t				m_NbIblcBlockProduced;
		
	public:
		CConverterPcmToILBC () throw ();
		~CConverterPcmToILBC () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret, uint8_t p_RtpPayloadType) throw ();

		int32_t ConvertBufferFromPcmToILBC(	int16_t *	p_EncodedData,
											uint32_t	p_EncodedDataLenInInt16,
											uint8_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInByte,
											uint32_t&	p_DecodedDataLen) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};

	}// namespace codec
} // namespace nettone

#endif // __KERTEL_CONVERTER_ILBC_TO_PCM_FLAG__