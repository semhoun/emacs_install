#ifndef __NETTONE_TOOLS_FSM_I_H__
#define __NETTONE_TOOLS_FSM_I_H__


namespace nettone
{
	namespace tools
	{
		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::FSM(const STATE& p_initialState,
										const DEFAULTHANDLER& p_defaultHandler)
			: m_defaultHandler(p_defaultHandler),
			  m_currentState(p_initialState)
		{
		}

		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		void FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::handleEvent(const EVENT& p_event,
																	 void* const& p_data)
		{
			TKey key = std::make_pair(m_currentState, p_event);
			typename TransitionMap::iterator iter = m_transitionMap.find(key);
			if (iter != m_transitionMap.end()) {
				TChange action = iter->second;
				
				// -----
				// Note : State is changed BEFORE calling the callback.
				// Doing so allows FSM implementor to call handleEvent from within a handler to
				// cascade events. Warning, event cascading (calling handleEvent from within a 
				// handler) MUST be the LAST statement before leaving the handler.
				// -----
				m_previousState = m_currentState;
				m_currentState = action.second;
				(action.first)(p_data);
			}
			else {
				m_defaultHandler(m_currentState, p_event, p_data);
			}
		}

		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		bool FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::isInFinalState() const
		{
			return isFinalState(m_currentState);
		}

		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		void FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::registerHook(const STATE& p_state,
												const EVENT& p_event,
												const HANDLER& p_handler,
												const STATE& p_nextState,
												const bool p_isFinal)
			throw (Exception)
		{
			if (isFinalState(p_state)) {
				throw Exception("Cannot register a hook for a final state"); // <== 
			}

			TKey key = std::make_pair(p_state, p_event);
			TChange change = std::make_pair(p_handler, p_nextState);
			typename TransitionMap::value_type value = std::make_pair(key, change);
			m_transitionMap.insert(value);
			
			if (p_isFinal) {
				typename FinalStatesMap::value_type val = std::make_pair(p_nextState, true);
				m_finalStatesMap.insert(val);
			}
		}

		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		bool FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::isFinalState(const STATE& p_state) const
		{
			typename FinalStatesMap::const_iterator pos = m_finalStatesMap.find(p_state);
			return pos == m_finalStatesMap.end() ? false : pos->second;
		}
		
		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		STATE FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::getPreviousState() const
		{
			return m_previousState;
		}

		template <typename HANDLER, typename STATE, typename EVENT, typename DEFAULTHANDLER>
		STATE FSM<HANDLER, STATE, EVENT, DEFAULTHANDLER>::getCurrentState() const
		{
			return m_currentState;
		}
	}
}


#endif // __NETTONE_TOOLS_FSM_I_H__

