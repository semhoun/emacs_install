#ifndef __NETTONE_LUA_WRAPMODULE_H__
#define __NETTONE_LUA_WRAPMODULE_H__


extern "C"
{
#include <lua5.1/lua.h>
#include <lua5.1/lauxlib.h>
#include <lua5.1/lualib.h>
}

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace lua
	{
		/**
		 * Base class for wrapping modules in LUA world.
		 */
		template <typename T>
		class WrapModule
		{
		public:
			/**
			 * Activate the module.
			 */
			static void activate()
				throw ();

			/**
			 * Deactivate the module.
			 */
			static void deactivate()
				throw ();

		protected:
			/**
			 * Metamethod "__index"
			 *
			 * @param p_L The LUA stack.
			 */
			static int index(lua_State* p_L);

			/**
			 * Activation flag.
			 */
			static bool c_active;
		};
	}
}


#include "nettone_lua_WrapModule.ih"


#endif // __NETTONE_LUA_WRAPMODULE_H__
