#ifndef __KERTEL_CONVERTER_GSM_TO_PCM_FLAG__
#define __KERTEL_CONVERTER_GSM_TO_PCM_FLAG__



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <vector>
#include <cstring>
#include <stdint.h>
#include <cstdio>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_Generic.h"


namespace nettone {
	namespace codec {


#define	MIN_WORD	(-32767 - 1)
#define	MAX_WORD	  32767

#define	MIN_LONGWORD	(-2147483647 - 1)
#define	MAX_LONGWORD	  2147483647

#define	NeedFunctionPrototypes	1

#ifdef __STDC__
#define	NeedFunctionPrototypes	1
#endif

#ifdef	_NO_PROTO
#undef	NeedFunctionPrototypes
#endif

#undef	P	// gnu stdio.h actually defines this... 	
#undef	P0
#undef	P1
#undef	P2
#undef	P3
#undef	P4
#undef	P5
#undef	P6
#undef	P7
#undef	P8

#if NeedFunctionPrototypes

#	define	P( protos )	protos

#	define	P0()				(void)
#	define	P1(x, a)			(a)
#	define	P2(x, a, b)			(a, b)
#	define	P3(x, a, b, c)			(a, b, c)
#	define	P4(x, a, b, c, d)		(a, b, c, d)	
#	define	P5(x, a, b, c, d, e)		(a, b, c, d, e)
#	define	P6(x, a, b, c, d, e, f)		(a, b, c, d, e, f)
#	define	P7(x, a, b, c, d, e, f, g)	(a, b, c, d, e, f, g)
#	define	P8(x, a, b, c, d, e, f, g, h)	(a, b, c, d, e, f, g, h)

#else // !NeedFunctionPrototypes 

#	define	P( protos )	()

#	define	P0()				()
#	define	P1(x, a)			x a;
#	define	P2(x, a, b)			x a; b;
#	define	P3(x, a, b, c)			x a; b; c;
#	define	P4(x, a, b, c, d)		x a; b; c; d;
#	define	P5(x, a, b, c, d, e)		x a; b; c; d; e;
#	define	P6(x, a, b, c, d, e, f)		x a; b; c; d; e; f;
#	define	P7(x, a, b, c, d, e, f, g)	x a; b; c; d; e; f; g;
#	define	P8(x, a, b, c, d, e, f, g, h)	x a; b; c; d; e; f; g; h;

#endif  // !NeedFunctionPrototypes 


#define	NeedFunctionPrototypes	1

#if __STDC__
#define	NeedFunctionPrototypes	1
#endif

#ifdef _NO_PROTO
#undef	NeedFunctionPrototypes
#endif

#ifdef NeedFunctionPrototypes
#include	<stdio.h>		// for FILE * 	
#endif

#undef GSM_P
#if NeedFunctionPrototypes
#define	GSM_P( protos )	protos
#else
#define  GSM_P( protos )	()
#endif
	//-------------------------------------------------------
#define GSM_MULT_R(a, b) \
	(SASR( ((int32_t)(a) * (int32_t)(b) + 16384), 15 ))

# define GSM_MULT(a,b)	 \
	(SASR( ((int32_t)(a) * (int32_t)(b)), 15 ))

# define GSM_L_MULT(a, b) \
	(((int32_t)(a) * (int32_t)(b)) << 1)

#if defined(__GNUC__) && defined(__i386__)

	__inline__ int GSM_L_ADD(int a, int b) {
		__asm__ __volatile__(

			"addl %2,%0; jno 0f; movl $0x7fffffff,%0; adcl $0,%0; 0:"
			: "=&r" (a)
			: "0" (a), "ir" (b)
			: "cc"
			);
		return(a); // <==
	}

	__inline__ short GSM_ADD(short a, short b)
	{
		__asm__ __volatile__(
			"addw %2,%0; jno 0f; movw $0x7fff,%0; adcw $0,%0; 0:"
			: "=&r" (a)
			: "0" (a), "ir" (b)
			: "cc"
			);
		return(a); // <==
	}

	__inline__ short GSM_SUB(short a, short b)
	{
		__asm__ __volatile__(
			"subw %2,%0; jno 0f; movw $0x7fff,%0; adcw $0,%0; 0:"
			: "=&r" (a)
			: "0" (a), "ir" (b)
			: "cc"
			);
		return(a); // <==
	}

#else

#ifdef WIN32
#define inline __inline
#define __inline__ __inline
#endif 

# define GSM_L_ADD(a, b)	\
	( (a) <  0 ? ( (b) >= 0 ? (a) + (b)	\
		 : (utmp = (uint32_t)-((a) + 1) + (uint32_t)-((b) + 1)) \
		   >= MAX_LONGWORD ? MIN_LONGWORD : -(int32_t)utmp-2 )   \
	: ((b) <= 0 ? (a) + (b)   \
	          : (utmp = (uint32_t)(a) + (uint32_t)(b)) >= MAX_LONGWORD \
		    ? MAX_LONGWORD : utmp))

	inline int16_t GSM_ADD(int32_t a, int32_t b)
	{
		register int32_t ltmp;
		ltmp = a + b;
		return (int16_t)((uint32_t)(ltmp - MIN_WORD) > MAX_WORD - MIN_WORD ? (ltmp > 0 ? MAX_WORD : MIN_WORD) : ltmp); // <==
	};

	inline int16_t GSM_SUB(int32_t a, int32_t b)
	{
		register int32_t ltmp;
		ltmp = a - b;
		return (int16_t)(ltmp >= MAX_WORD ? MAX_WORD : ltmp <= MIN_WORD ? MIN_WORD : ltmp); // <==
	};

#endif

# define GSM_ABS(a)	((a) < 0 ? ((a) == MIN_WORD ? MAX_WORD : -(a)) : (a))


	//  More prototypes from implementations..
	int32_t Gsm_Coder (
	struct gsm_state	* S,
		int16_t	* s,
		int16_t	* LARc,
		int16_t	* Nc,
		int16_t	* bc,
		int16_t	* Mc,
		int16_t	* xmaxc,
		int16_t	* xMc);

	int32_t Gsm_Long_Term_Predictor (
	struct gsm_state * S,
		int16_t	* d,
		int16_t	* dp,
		int16_t	* e,
		int16_t	* dpp,
		int16_t	* Nc,
		int16_t	* bc);

	void Gsm_LPC_Analysis (
	struct gsm_state * S,
		int16_t * s,
		int16_t * LARc);

	int32_t Gsm_Preprocess (
	struct gsm_state * S,
		int16_t * s, int16_t * so);

	void Gsm_Encoding (
	struct gsm_state * S,
		int16_t	* e,
		int16_t	* ep,
		int16_t	* xmaxc,
		int16_t	* Mc,
		int16_t	* xMc);

	void Gsm_Short_Term_Analysis_Filter (
	struct gsm_state * S,
		int16_t	* LARc,
		int16_t	* d);

	void Gsm_Decoder (
	struct gsm_state * S,
		int16_t	* LARcr,
		int16_t	* Ncr,
		int16_t	* bcr,
		int16_t	* Mcr,
		int16_t	* xmaxcr,
		int16_t	* xMcr,
		int16_t	* s);

	void Gsm_Decoding (
	struct gsm_state * S,
		int16_t 	xmaxcr,
		int16_t	Mcr,
		int16_t	* xMcr,
		int16_t	* erp);

	int32_t Gsm_Long_Term_Synthesis_Filtering (
	struct gsm_state* S,
		int16_t	Ncr,
		int16_t	bcr,
		int16_t	* erp,
		int16_t	* drp);

	void Gsm_RPE_Decoding (
	struct gsm_state *S,
		int16_t xmaxcr,
		int16_t Mcr,
		int16_t * xMcr,
		int16_t * erp);

	void Gsm_RPE_Encoding (
	struct gsm_state * S,
		int16_t    * e,
		int16_t    * xmaxc,
		int16_t    * Mc,
		int16_t    * xMc);

	void Gsm_Short_Term_Synthesis_Filter (
	struct gsm_state * S,
		int16_t	* LARcr,
		int16_t	* drp,
		int16_t	* s);

	void Gsm_Update_of_reconstructed_short_time_residual_signal (
		int16_t	* dpp,
		int16_t	* ep,
		int16_t	* dp);

#ifndef	GSM_TABLE_C

	extern int16_t gsm_A[8], gsm_B[8], gsm_MIC[8], gsm_MAC[8];
	extern int16_t gsm_INVA[8];
	extern int16_t gsm_DLB[4], gsm_QLB[4];
	extern int16_t gsm_H[11];
	extern int16_t gsm_NRFAC[8];
	extern int16_t gsm_FAC[8];

#endif	// GSM_TABLE_C 


	//  Debugging
#ifdef NDEBUG

#	define	gsm_debug_words(a, b, c, d)		
#	define	gsm_debug_int32_ts(a, b, c, d)	
#	define	gsm_debug_word(a, b)			
#	define	gsm_debug_int32_t(a, b)		

#else	// !NDEBUG => DEBUG 

	void  gsm_debug_words     (char * name, int, int, int16_t *);
	void  gsm_debug_int32_ts (char * name, int, int, int32_t *);
	void  gsm_debug_int32_t  (char * name, int32_t);
	void  gsm_debug_word     (char * name, int16_t);

#endif // !NDEBUG 

	//-------------------------------------------------------
	struct gsm_state {
		int16_t			dp0[280];
		int16_t			z1;
		int32_t			L_z2;
		int				mp;
		int16_t			u[8];
		int16_t			LARpp[2][8];
		int16_t			j;
		int16_t         ltp_cut;
		int16_t			nrp;
		int16_t			v[9];
		int16_t			msr;
		char			verbose;
		char			fast;
		char			wav_fmt;
		unsigned char	frame_index;
		unsigned char	frame_chain;
	};


#ifdef	SASR		// flag: >> is a signed arithmetic shift right 
#undef	SASR
#define	SASR(x, by)	((x) >> (by))
#else
#define	SASR(x, by)	((x) >= 0 ? (x) >> (by) : (~(-((x) + 1) >> (by))))
#endif	// SASR 

	//======================
	// Prototypes
	//======================
	int16_t	gsm_mult 	(int16_t a, int16_t b);
	int32_t gsm_L_mult 	(int16_t a, int16_t b);
	int16_t	gsm_mult_r	(int16_t a, int16_t b);
	int16_t	gsm_div  	(int16_t num, int16_t denum);
	int16_t	gsm_add 	(int16_t a, int16_t b);
	int32_t gsm_L_add 	(int32_t a, int32_t b);
	int16_t	gsm_sub 	(int16_t a, int16_t b);
	int32_t gsm_L_sub 	(int32_t a, int32_t b);
	int16_t	gsm_abs 	(int16_t a);
	int16_t	gsm_norm 	(int32_t a);
	int32_t gsm_L_asl  	(int32_t a, int n);
	int16_t	gsm_asl 	(int16_t a, int n);
	int32_t gsm_L_asr  	(int32_t a, int n);
	int16_t	gsm_asr  	(int16_t a, int n);


	typedef struct gsm_state * 	gsm;
	typedef uint8_t 			gsm_frame[33];		// 33 * 8 bits	 

#define	GSM_MAGIC		0xD		  	// 13 kbit/s RPE-LTP 

#define	GSM_PATCHLEVEL		10
#define	GSM_MINOR		0
#define	GSM_MAJOR		1

#define	GSM_OPT_VERBOSE		1
#define	GSM_OPT_FAST		2
#define	GSM_OPT_LTP_CUT		3
#define	GSM_OPT_WAV49		4
#define	GSM_OPT_FRAME_INDEX	5
#define	GSM_OPT_FRAME_CHAIN	6

	gsm  gsm_create 	GSM_P((void));
	void gsm_destruct (gsm p_GsmContextPtr);
	void gsm_destroy GSM_P((gsm));

	int  gsm_print   GSM_P((FILE *, gsm, uint8_t  *));
	int  gsm_option  GSM_P((gsm, int, int *));

	void gsm_encode  GSM_P((gsm, int16_t *, uint8_t  *));
	int  gsm_decode  GSM_P((gsm, uint8_t   *, int16_t *));

	int  gsm_explode GSM_P((gsm, uint8_t   *, int16_t *));
	void gsm_implode GSM_P((gsm, int16_t *, uint8_t   *));

#undef	GSM_P




	//============================================================
	const uint32_t GSM_FRAME_SIZE_IN_BYTE					= 33;
	const uint32_t GSM_FRAME_WORST_SIZE_IN_BYTE				= 53;
	const uint32_t GSM_COMPRESSED_FRAME_MAX_SIZE_IN_INT8	= GSM_FRAME_WORST_SIZE_IN_BYTE * 10;

	const uint32_t PCM_FRAME_SIZE_FOR_GSM_IN_INT16			= 160;
	const uint32_t PCM_FRAME_WORST_SIZE_FOR_GSM_IN_INT16	= 256;
	const uint32_t PCM_MAX_FRAME_SIZE_FOR_GSM_IN_INT16		= PCM_FRAME_WORST_SIZE_FOR_GSM_IN_INT16 * 10;
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Generic functions
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	void CheckValidityOfDestBufferSizeInInt16GsmToPcm	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt16, uint32_t& p_MinimumExpectedSizeInInt16);
	void CheckValidityOfDestBufferSizeInUint8PcmToGSM	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt8, uint32_t& p_MinimumExpectedSizeInInt8);

	class CConverterGSMToPcm : public CConverterXXX
	{
	private:
		CConverterGSMToPcm (const CConverterGSMToPcm&) throw ();				// forbid copy
		CConverterGSMToPcm& operator= (const CConverterGSMToPcm&) throw ();	// forbid copy

		gsm	m_GsmContextPtr;

	public:
		CConverterGSMToPcm () throw ();
		~CConverterGSMToPcm () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret) throw ();

		int32_t ConvertBufferFromGSMToPcm	(uint8_t *	p_EncodedData,
			uint32_t	p_EncodedDataLen,
			int16_t *	p_DecodedData,
			uint32_t	p_DecodedBufferSizeInInt16,
			uint32_t&	p_DecodedDataLenInInt16) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};



	class CConverterPcmToGSM : public CConverterXXX
	{
	private:
		CConverterPcmToGSM (const CConverterPcmToGSM&) throw ();				// forbid copy
		CConverterPcmToGSM& operator= (const CConverterPcmToGSM&) throw ();		// forbid copy

		gsm	m_GsmContextPtr;

	public:
		CConverterPcmToGSM () throw ();
		~CConverterPcmToGSM () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret) throw ();

		int32_t ConvertBufferFromPcmToGSM(int16_t *	p_EncodedData,
			uint32_t	p_EncodedDataLenInInt16,
			uint8_t *	p_DecodedData,
			uint32_t	p_DecodedBufferSizeInByte,
			uint32_t&	p_DecodedDataLen) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};

	}// namespace codec
} // namespace nettone


#endif // __KERTEL_CONVERTER_GSM_TO_PCM_FLAG__
