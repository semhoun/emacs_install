#ifndef __NETTONE_SDP_SERIALIAZER__
#define __NETTONE_SDP_SERIALIAZER__

#include <string.h>
#include <vector>

#include "nettone_tools_Exception.h"

namespace nettone
{
    namespace sdp
    {
        class SDP;
        class ProtoVersion;
        class Origin;
        class Session;
        class Information;
        class Connection;
        class Time;
        class Attributes;
        class AttrPTime;
        class AttrCnxMode;
        class AttrCodec;
        class Media;

        /**
         * Class used for erialized a SDP
         * ie: nettone::sdp::SDP -> std::string sdp
         */
        class Serializer
        {
        public:
            /**
             * Constructor.
             */
            Serializer()
                throw();

            /**
             * Destructor.
             */
            ~Serializer()
                throw();

            /**
             * Transform class SDP to string
             */
            virtual std::string serialize(SDP* const p_sdp)
                throw (nettone::tools::Exception);

        protected:
            /**
             * Encode ProtoVersion
             *
             * @param p_version	Protocol version
             * @param p_data	where add encoded data
             *
             */
            virtual void encodeProtoVersion(ProtoVersion* const p_version,
                                            std::string& p_data)
                throw (nettone::tools::Exception);

            /**
             * Encode Origin
             *
             *
             * @param p_origin	origin field
             * @param p_data	where add encoded data
             */
            virtual void encodeOrigin(Origin* const p_origin,
                                      std::string& p_data)
                throw (nettone::tools::Exception);

            /**

             * Encode Session
             *
             * @param p_session	session name
             * @param p_data	where add encoded data
             */
            virtual void encodeSession(Session* const p_session,
                                       std::string& p_data)
                throw (nettone::tools::Exception);

            /**
             * Encode Information
             *
             * @param p_info	Information field
             * @param p_data	where add encoded data
             */
            virtual void encodeInformation(Information* const p_information,
                                           std::string& p_data)
                throw (nettone::tools::Exception);

            /**
             * Encode Connection
             *
             * @param p_connection		connection data
             * @param p_data			where add encoded data
             */
            virtual void encodeConnection(Connection* const p_cnx,
                                          std::string& p_data)
                throw (nettone::tools::Exception);

            /**
             * Encode Time
             *
             * @param p_time	time field
             * @param p_data	where add encoded data
             */
            virtual void encodeTime(Time* const p_time,
                                    std::string& p_data)
                throw (nettone::tools::Exception);

            /**
             * Encode Attributes
             *
             * @param p_attr	attributes to encode
             * @param p_data	where add encoded data
             */
            virtual void encodeAttributes(Attributes* const p_attributes,
                                          std::string& p_data)
                throw (nettone::tools::Exception);

            /**
             * Encode Media
             *
             * @param p_media	media to encode
             * @param p_data	where add encoded data
             */
            virtual void encodeMedia(Media* const p_media,
                                     std::string& p_data)
                throw (nettone::tools::Exception);
        };
    }
}


#endif // __NETTONE_SDP_DESERIALIAZER__
