#ifndef __NETTONE_EVENT_EVENT_H__
#define __NETTONE_EVENT_EVENT_H__


#include <sys/time.h>
#include <time.h>
#include <string>
#include <vector>

#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace event
	{
		class Event
		{
		public:
			typedef unsigned long EventId;

			virtual ~Event();
 
			const EventId& getId() const
				throw ();

			class EventDate
			{
			public:
				EventDate();

				const struct timeval& getTimestamp() const;
				void getDateFields(struct tm& p_result);

			private:
				struct timeval m_timeval;
			};

			const EventDate& getDate() const
				throw ();

		protected:
			Event(const EventId& p_eventId);
		
		private:
			/** Unique event class ID */
			EventId m_eventId;
			
			/** Events timestamp */
			EventDate m_eventDate;
		};
	}
}


#endif // __NETTONE_EVENT_EVENT_H__
