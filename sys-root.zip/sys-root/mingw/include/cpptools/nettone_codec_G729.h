#ifndef __KERTEL_CONVERTER_G729_TO_PCM_FLAG__
#define __KERTEL_CONVERTER_G729_TO_PCM_FLAG__



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <vector>
#include <cstring>

#ifdef __cplusplus
extern "C" {
#endif
#include "bcg729/decoder.h"
#include "bcg729/encoder.h"
#ifdef __cplusplus
}
#endif
#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_Generic.h"


namespace nettone {
	namespace codec {



	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Constants
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	const uint32_t	G729_COMPRESSED_FRAME_SIZE_10_MSEC_IN_BYTE					= 10;
	const uint32_t	G729_COMPRESSED_FRAME_SIZE_20_MSEC_IN_BYTE					= 20;
	const uint32_t	G729_COMPRESSED_FRAME_MAX_SIZE_IN_INT8						= G729_COMPRESSED_FRAME_SIZE_20_MSEC_IN_BYTE * 10;

	const int32_t	KERTEL_G729_SID_FRAME_SIZE									= 2;
	const uint32_t	G729_UNCOMPRESSED_AS_PCM_FRAME_10_MSEC_SIZE_IN_INT16		= 80;
	const uint32_t	G729_UNCOMPRESSED_AS_PCM_FRAME_10_MSEC_SIZE_IN_INT8			= G729_UNCOMPRESSED_AS_PCM_FRAME_10_MSEC_SIZE_IN_INT16 * 2;
	const uint32_t	KERTEL_G729_COMPRESSED_DATALEN_IN_BYTE						= 10;

	const uint32_t	G729_UCOMPRESSED_AS_PCM_FRAME_10_MSEC_SIZE_IN_INT16			= 80;
	const uint32_t	G729_UCOMPRESSED_AS_PCM_FRAME_20_MSEC_SIZE_IN_INT16			= 160;
	const uint32_t	G729_UCOMPRESSED_AS_PCM_FRAME_MAX_SIZE_IN_INT16				= G729_UCOMPRESSED_AS_PCM_FRAME_20_MSEC_SIZE_IN_INT16 * 10;

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Generic functions
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	bool IsValidCompressedPayloadSizeG729 (uint32_t p_RtpPayloadSizeInByte);
	void CheckValidityOfDestBufferSizeInInt16G729ToPcm	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt16, uint32_t& p_MinimumExpectedSizeInInt16);
	void CheckValidityOfDestBufferSizeInUint8PcmToG729	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt8, uint32_t& p_MinimumExpectedSizeInInt8);

	class CConverterG729ToPcm : public CConverterXXX
	{
	private:
		CConverterG729ToPcm (const CConverterG729ToPcm&) throw ();			// forbid copy
		CConverterG729ToPcm& operator= (const CConverterG729ToPcm&) throw (); // forbid copy

		int32_t ConvertBufferFromG729ToPcmUnitary (uint8_t *	p_EncodedData,
			uint32_t	p_EncodedDataLen,
			int16_t *	p_DecodedData,
			uint32_t	p_DecodedBufferSizeInInt16,
			uint32_t&	p_DecodedDataLenInInt16) throw ();

		bcg729DecoderChannelContextStruct *		m_bcg729DecoderChannelContextStructPtr;

	public:
		CConverterG729ToPcm () throw ();
		~CConverterG729ToPcm () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret) throw ();

		int32_t ConvertBufferFromG729ToPcm(	uint8_t *	p_EncodedData,
											uint32_t	p_EncodedDataLen,
											int16_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInInt16,
											uint32_t&	p_DecodedDataLenInInt16) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};



	class CConverterPcmToG729 : public CConverterXXX
	{
	private:
		CConverterPcmToG729 (const CConverterPcmToG729&) throw ();				// forbid copy
		CConverterPcmToG729& operator= (const CConverterPcmToG729&) throw ();		// forbid copy

		bcg729EncoderChannelContextStruct	*	m_bcg729EncoderChannelContextStructPtr;

	public:
		CConverterPcmToG729 () throw ();
		~CConverterPcmToG729 () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret) throw ();

		int32_t ConvertBufferFromPcmToG729(int16_t *	p_EncodedData,
			uint32_t	p_EncodedDataLenInInt16,
			uint8_t *	p_DecodedData,
			uint32_t	p_DecodedBufferSizeInByte,
			uint32_t&	p_TrueDecodedDataLenInByte) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};

	}// namespace codec
} // namespace nettone



#endif // __KERTEL_CONVERTER_G729_TO_PCM_FLAG__
