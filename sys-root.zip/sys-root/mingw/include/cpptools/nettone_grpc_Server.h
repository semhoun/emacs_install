#pragma once

#include <string>
#include <iostream>
#include <functional>
#include <unordered_map>

#include "nettone_tools_Thread.h"
#include "nettone_tools_Exception.h"
#include "nettone_grpc_UnaryRpc.h"

namespace nettone
{
	namespace grpc
	{
		
		class Server
		{
		public: 
			// Endpoint for instance
			//
			struct Endpoint
			{
				// Address
				//
				std::string host;

				// Listen on port
				//
				uint32_t port;
				
				// Type of instance mediastreamer, mcms, or mproxy
				// @brief: equivalent of name
				//
				std::string type; 

				// Name of instance like  mediastreamer2 or mproxy1 etc... like corba  objectpath.name 
				// @brief : equivalent of context
				//
				std::string name;
			};

			
			template <typename InternalObject>
				class ThreadUtility : public nettone::tools::Thread
				{
				public:
					/**
					 * Constructor.
					 */
					inline ThreadUtility(InternalObject& p_lock)
						throw (nettone::tools::Exception);

					/**
					 * Destructor.
					 */
					inline ~ThreadUtility()
						throw (nettone::tools::Exception);

					/**
					 * Pure virtual func used to process thread
					 */
					virtual void run() override = 0;

				private:
					/// @name Forbidden methods
					/// @{
					ThreadUtility(const ThreadUtility<InternalObject>& p_other);
					const ThreadUtility<InternalObject>& operator =(const ThreadUtility<InternalObject>& p_other);
					/// @}

					/// The lock to get/release
					InternalObject* const m_internalObject;
				};

			inline void setEndpoint(const Server::Endpoint& p_endpoint);

			inline Server::Endpoint getEndpoint();

		protected:
			
			/**
			 * Map used to store responder (structure that contains response and context)
			 */
			std::unordered_map<nettone::grpc::UnaryRpc::RpcJob*, std::unique_ptr<nettone::grpc::UnaryRpc::BaseResponder>> m_responderMap;
			
			/**
			 *  Endpoint that contains informations about host, port, name, type of instance
			 */
			nettone::grpc::Server::Endpoint m_endpoint;

			/**
			 * GRPC server engine (from GRPC library)
			 */
			std::unique_ptr<::grpc::Server> m_server;

			/**
			 * Completion queue (from GRPC library)
			 */
			std::unique_ptr<::grpc::ServerCompletionQueue> m_cq;

			/**
			 * Incoming tags
			 */
			nettone::grpc::UnaryRpc::TagList m_incomingTags;

			/**
			 * Mutex used to protect Incoming tags list
			 */
			std::mutex m_incomingTagsMutex;						
		}; // class Server
		
	} // namepsace grpc
	
} // namespace nettone

#include "cpptools/nettone_grpc_Server.ih"
