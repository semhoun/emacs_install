#ifndef __NETTONE_NET_SOCKET_H__
#define __NETTONE_NET_SOCKET_H__


#include "nettone_net_Selector.h"
#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace net
	{
		/**
		 * Portable Socket class.
		 */
		class Socket
			: public virtual Selector::ISelectable 
		{
		public:
			/**
			 * Initialize the Socket API.
			 */
			static void initialize()
				throw (nettone::tools::Exception);

			/**
			 * Close the socket.
			 */
			void close()
				throw ();
			
			/// @name Methods from Selector::ISelectable
			/// @{
			virtual int getDescriptor() const
				throw (nettone::tools::Exception);
			/// @}

		protected:
			/**
			 * Constructor.
			 */
			Socket()
				throw ();

			/**
			 * Destructor.
			 */
			virtual ~Socket()
				throw ();

			/**
			 * Different types of socket.
			 */
			enum Type {
				SOCKET_UDP,
				SOCKET_TCP
			};

			/**
			 * Open the socket.
			 *
			 * @param p_type The type of the socket to open.
			 */
			void open(const Type p_type = SOCKET_UDP)
				throw (nettone::tools::Exception);

		protected:
			/// The socket it-self.
			int m_socket;
			
			/// Tell is the socket is open.
			bool m_isOpen;

		private:
			/// @name Forbidden methods
			/// @{
			Socket(const Socket& p_other);
			const Socket& operator =(const Socket& p_other);
			/// @}
		};
	}
}


#endif // __NETTONE_NET_SOCKET_H__
