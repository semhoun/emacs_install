#ifndef __KERTEL_CONVERTER_G722_TO_PCM_FLAG__
#define __KERTEL_CONVERTER_G722_TO_PCM_FLAG__



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <vector>
#include <cstring>
#include <stdint.h>
#include <climits>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_Generic.h"



namespace nettone {
	namespace codec {


//====================================================
// G722 RTP payload types 
//====================================================
// G722 - 48 : Rtp payload type = 0x72 (114) ou 0xF2	
// G722 - 56 : Rtp payload type = 0x71 (113) ou 0xF1
// G722 - 64 : Rtp payload type = 0x09 (9) ou 0x89
//====================================================

	enum G722OptionsBitfieldEnum {
		G722_OPTION_SAMPLE_RATE_8000	= 0x0001,
		G722_OPTION_PACKED				= 0x0002
	};

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Encoding state
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	typedef struct {
		int itu_test_mode; // TRUE if the operating in the special ITU test mode, with the band split filters disabled. 
		int packed; // TRUE if the G.722 data is packed 
		int eight_k; // TRUE if encode from 8k samples/second 
		int bits_per_sample; // 6 for 48000kbps, 7 for 56000kbps, or 8 for 64000kbps. 
		int x[24]; // Signal history for the QMF 

		struct {
			int s;
			int sp;
			int sz;
			int r[3];
			int a[3];
			int ap[3];
			int p[3];
			int d[7];
			int b[7];
			int bp[7];
			int sg[7];
			int nb;
			int det;
		} band[2];

		unsigned int in_buffer;
		int in_bits;
		unsigned int out_buffer;
		int out_bits;
	} g722_encode_state_t;


	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Decoding state
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	typedef struct {
		int itu_test_mode; // TRUE if the operating in the special ITU test mode, with the band split filters disabled.
		int packed; // TRUE if the G.722 data is packed
		int eight_k; // TRUE if decode to 8k samples/second 
		int bits_per_sample; // 6 for 48000kbps, 7 for 56000kbps, or 8 for 64000kbps. 
		int x[24]; // Signal history for the QMF 

		struct {
			int s;
			int sp;
			int sz;
			int r[3];
			int a[3];
			int ap[3];
			int p[3];
			int d[7];
			int b[7];
			int bp[7];
			int sg[7];
			int nb;
			int det;
		} band[2];

		unsigned int in_buffer;
		int in_bits;
		unsigned int out_buffer;
		int out_bits;
	} g722_decode_state_t;

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Decoding tables & constants
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 const int wl_Decode[8] = { -60, -30, 58, 172, 334, 538, 1198, 3042 };
	 const int rl42_Decode[16] = { 0, 7, 6, 5, 4, 3, 2, 1, 7, 6, 5, 4, 3,  2, 1, 0 };
	 const int ilb_Decode[32] = {
		2048, 2093, 2139, 2186, 2233, 2282, 2332,
		2383, 2435, 2489, 2543, 2599, 2656, 2714,
		2774, 2834, 2896, 2960, 3025, 3091, 3158,
		3228, 3298, 3371, 3444, 3520, 3597, 3676,
		3756, 3838, 3922, 4008
	};
	 const int wh_Decode[3] = { 0, -214, 798 };
	 const int rh2_Decode[4] = { 2, 1, 2, 1 };
	 const int qm2_Decode[4] = { -7408, -1616,  7408,   1616 };
	 const int qm4_Decode[16] = { 0, -20456, -12896,  -8968, -6288, -4240, -2584, -1200, 20456, 12896, 8968, 6288, 4240, 2584, 1200, 0 };
	 const int qm5_Decode[32] = {
		-280,   -280, -23352, -17560,
		-14120, -11664,  -9752,  -8184,
		-6864,  -5712,  -4696,  -3784,
		-2960,  -2208,  -1520,   -880,
		23352,  17560,  14120,  11664,
		9752,   8184,   6864,   5712,
		4696,   3784,   2960,   2208,
		1520,    880,    280,   -280
	};
	 const int qm6_Decode[64] = {
		-136,   -136,   -136,   -136,
		-24808, -21904, -19008, -16704,
		-14984, -13512, -12280, -11192,
		-10232,  -9360,  -8576,  -7856,
		-7192,  -6576,  -6000,  -5456,
		-4944,  -4464,  -4008,  -3576,
		-3168,  -2776,  -2400,  -2032,
		-1688,  -1360,  -1040,   -728,
		24808,  21904,  19008,  16704,
		14984,  13512,  12280,  11192,
		10232,   9360,   8576,   7856,
		7192,   6576,   6000,   5456,
		4944,   4464,   4008,   3576,
		3168,   2776,   2400,   2032,
		1688,   1360,   1040,    728,
		432,    136,   -432,   -136
	};
	 const int qmf_coeffs_Decode[12] = { 3,  -11,   12,   32, -210,  951, 3876, -805,  362, -156,   53,  -11, };

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Encoding tables & constants
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 const int q6_Encode[32] = {
		0,   35,   72,  110,  150,  190,  233,  276,
		323,  370,  422,  473,  530,  587,  650,  714,
		786,  858,  940, 1023, 1121, 1219, 1339, 1458,
		1612, 1765, 1980, 2195, 2557, 2919,    0,    0
	};
	 const int iln_Encode[32] = {
		0, 63, 62, 31, 30, 29, 28, 27,
		26, 25, 24, 23, 22, 21, 20, 19,
		18, 17, 16, 15, 14, 13, 12, 11,
		10,  9,  8,  7,  6,  5,  4,  0
	};
	 const int ilp_Encode[32] = {
		0, 61, 60, 59, 58, 57, 56, 55,
		54, 53, 52, 51, 50, 49, 48, 47,
		46, 45, 44, 43, 42, 41, 40, 39,
		38, 37, 36, 35, 34, 33, 32,  0
	};
	 const int wl_Encode[8] = { -60, -30, 58, 172, 334, 538, 1198, 3042 };
	 const int rl42_Encode[16] = { 0, 7, 6, 5, 4, 3, 2, 1, 7, 6, 5, 4, 3, 2, 1, 0 };
	 const int ilb_Encode[32] = {
		2048, 2093, 2139, 2186, 2233, 2282, 2332,
		2383, 2435, 2489, 2543, 2599, 2656, 2714,
		2774, 2834, 2896, 2960, 3025, 3091, 3158,
		3228, 3298, 3371, 3444, 3520, 3597, 3676,
		3756, 3838, 3922, 4008
	};
	 const int qm4_Encode[16] = {
		0, -20456, -12896, -8968,
		-6288,  -4240,  -2584, -1200,
		20456,  12896,   8968,  6288,
		4240,   2584,   1200,     0
	};
	 const int qm2_Encode[4] = { -7408,  -1616,   7408,   1616 };
	 const int qmf_coeffs_Encode[12] = { 3,  -11,   12,   32, -210,  951, 3876, -805,  362, -156,   53,  -11, };
	 const int ihn_Encode[3] = { 0, 1, 0 };
	 const int ihp_Encode[3] = { 0, 3, 2 };
	 const int wh_Encode[3] = { 0, -214, 798 };
	 const int rh2_Encode[4] = { 2, 1, 2, 1 };

	int16_t G722Saturate(int32_t amp);


	//====================================================================
	// Frame size constants
	//====================================================================
	const uint32_t G722_48_COMPRESSED_FRAME_SIZE_10_MSEC_IN_BYTE			= 120;
	const uint32_t G722_56_COMPRESSED_FRAME_SIZE_10_MSEC_IN_BYTE			= 140;
	const uint32_t G722_64_COMPRESSED_FRAME_SIZE_10_MSEC_IN_BYTE			= 80; // some payloads have this size, or (n * 80)
	const uint32_t G722_64_COMPRESSED_FRAME_MAX_SIZE_IN_INT8				= G722_64_COMPRESSED_FRAME_SIZE_10_MSEC_IN_BYTE * 10;

	const uint32_t	G722_64_UCOMPRESSED_AS_PCM_FRAME_10_MSEC_SIZE_IN_INT16 = 80;
	const uint32_t	G722_64_UCOMPRESSED_AS_PCM_FRAME_20_MSEC_SIZE_IN_INT16 = 160;
	const uint32_t	G722_64_UCOMPRESSED_AS_PCM_FRAME_40_MSEC_SIZE_IN_INT16 = 320;
	const uint32_t	G722_64_UCOMPRESSED_AS_PCM_MAX_FRAME_SIZE				= G722_64_UCOMPRESSED_AS_PCM_FRAME_40_MSEC_SIZE_IN_INT16 * 10;

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Generic functions
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	bool IsValidCompressedPayloadSizeG722_48			(uint32_t p_RtpPayloadType);
	bool IsValidCompressedPayloadSizeG722_56			(uint32_t p_RtpPayloadType);
	bool IsValidCompressedPayloadSizeG722_64			(uint32_t p_RtpPayloadType);
	void CheckValidityOfDestBufferSizeInInt16G722ToPcm	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt16, uint32_t& p_MinimumExpectedSizeInInt16);
	void CheckValidityOfDestBufferSizeInUint8PcmToG722	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt8, uint32_t& p_MinimumExpectedSizeInInt8);

	class CConverterG722ToPcm : public CConverterXXX
	{
	private:
		CConverterG722ToPcm (const CConverterG722ToPcm&) throw ();			// forbid copy
		CConverterG722ToPcm& operator= (const CConverterG722ToPcm&) throw (); // forbid copy
		void Block4Decode (int band, int d) throw ();

		g722_decode_state_t		m_G722DecodeState;

	public:
		CConverterG722ToPcm () throw ();
		~CConverterG722ToPcm () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret, uint8_t p_RtpPayloadType, int32_t p_Options) throw ();

		int32_t ConvertBufferFromG722ToPcm (uint8_t * p_EncodedData,
			uint32_t	p_EncodedDataLen,
			int16_t *	p_DecodedData,
			uint32_t	p_DecodedBufferSizeInInt16,
			uint32_t&	p_DecodedDataLenInInt16) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};


	class CConverterPcmToG722 : public CConverterXXX
	{
	private:
		CConverterPcmToG722 (const CConverterPcmToG722&) throw ();				// forbid copy
		CConverterPcmToG722& operator= (const CConverterPcmToG722&) throw ();	// forbid copy
		void Block4Encode (int band, int d) throw ();

		g722_encode_state_t		m_G722EncodeState;

	public:
		CConverterPcmToG722 () throw ();
		~CConverterPcmToG722 () throw ();
		void	Reset () throw ();
		void BeginConversion (int32_t& p_Iret, uint8_t p_RtpPayloadType, int32_t p_Options) throw ();

		int32_t ConvertBufferFromPcmToG722	(	int16_t *	p_EncodedData,
												uint32_t	p_EncodedDataLenInInt16,
												uint8_t *	p_DecodedData,
												uint32_t	p_DecodedBufferSizeInByte,
												uint32_t&	p_TrueDecodedDataLenInByte) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};

	}// namespace codec
} // namespace nettone


#endif // __KERTEL_CONVERTER_G722_TO_PCM_FLAG__
