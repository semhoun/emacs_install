#ifndef __nettone_net_ServerTcpClient_h__
#define __nettone_net_ServerTcpClient_h__

#include "nettone_net_Buffer.h"
#include "nettone_tools_List.h"



namespace nettone
{
	namespace tools
	{
		class Exception;
		class Thread;
		class RecurMutex;
		class Cond;
		class Mutex;
	}

	namespace net
	{
		class SocketTcp;
		class ThreadTcpClientReader;
		class ThreadTcpClientWriter;

		/**
		 * @todo Comment.
		 */
		class ServerTcpClient
		{
		public:
			/**
			 * Interface to handle connectoin events
			 */
			class IConnectionHandler
			{
			public:
				/**
				 * Called when client was disconnected
				 */
				virtual void handleDisconnect()
					throw() = 0;

				/**
				 * Called when client was connected
				 */
				virtual void handleConnect()
					throw() = 0;
			};

			/**
			 * Interface to handle all READ events.
			 */
			class IReadOpHandler
			{
			public:
				/**
				 * Called when an error occur durung the low-level read
				 *
				 * @note User should not try to stop the ServerTcpClient from 
				 *       inside this method.
				 *
				 * @todo May be can we pass an text describing the error.
				 */
				virtual void handleReadError() 
					throw() = 0;

				/**
				 * Called when a buffer has been built and added to the 
				 * reception queue.
				 *
				 * @note User should not try to stop the ServerTcpClient from 
				 *       inside this method.
				 *
				 * @todo Maybe can we first notify the handler with the buffer
				 *       and if it quit this method with false (providing we have
				 *       changed the method signature), the buffer is added to the 
				 *       reception queue ...
				 */
				virtual void handleIncomingMessage()
					throw() = 0;
			};

			/**
			 * Interface to handle write events.
			 */
			class IWriteOpHandler
			{
			public:
				/**
				 * Called when an error occurs during a write operation.
				 * The server sent back the buffer and the key given when
				 * the request was posted with writeBuffer().
				 * The implementor is responsible for the deletion of the Buffer
				 * object.
				 *
				 * @param p_buffer The buffer that was not sent.
				 * @param p_key    The key identifying the write request.
				 *
				 * @note User should not try to stop the ServerTcpClient from 
				 *       inside this method.
				 */
				virtual void handleWriteError(const Buffer* const p_buffer,
											  void* p_key)
					throw() = 0;

				/**
				 * Called when a buffer has successfully been sent to the 
				 * networking API, with no error returned.
				 * The server sent back the key given when the request was
				 * posted with writeBuffer().
				 *
				 * @param p_key    The key identifying the write request.
				 *
				 * @note User should not try to stop the ServerTcpClient from 
				 *       inside this method.
				 */
				virtual void handleOutgoingMessage(void* p_key)
					throw() = 0;
			};

			/**
			 * Configuration parameters.
			 */
			class Config
			{
			public:
				/// Ip addr the server will connect to 
				std::string addr;

				/// Port number to listen to.
				unsigned short port;

				/// Handler of completion of read operations.
				IReadOpHandler* p_readOpHandler;

				/// Handler of completion of write operations.
				IWriteOpHandler* p_writeOpHandler;

				// Handler of connection 
				IConnectionHandler* p_connectionHandler;
			};

			/**
			 * Constructor.
			 */
			ServerTcpClient() 
				throw ();

			/**
			 * Destructor.
			 */
			virtual ~ServerTcpClient() 
				throw ();

			/**
			 * Start the server.
			 */
			void start(const Config& p_config) 
				throw (nettone::tools::Exception);

			/**
			 * Stop the server.
			 */
			void stop() 
				throw ();

			/**
			 * Get the next pending buffer. If no buffer is available, wait until the 
			 * timeout expires.
			 *
			 * @param p_timeout Wait delay in ms.
			 * @param p_wait	Should wait if no data
			 *
			 * @return The next pending buffer. If the timeout expires before any
			 *         buffer arrives, return NULL.
			 *         The implementor is responsible for the deletion of the Buffer
			 *         object.
			 */
			Buffer* readBuffer(const unsigned long p_timeout, 
							   const bool p_wait = true) 
				throw (nettone::tools::Exception);

			/**
			 * Request the server to send a Buffer.
			 *
			 * @param p_buffer         The buffer to send.
			 * @param p_writeOpHandler The handler of completion of write operaterations.
			 * @param p_key            The request identifier.
			 */
			void writeBuffer(const Buffer* const p_buffer,
							 void* p_key,
							 IWriteOpHandler* const p_writeOpHandler) 
				throw (nettone::tools::Exception);

			/**
			 * Is connected to server
			 */ 
			bool isConnected()
				throw();

			/**
			 * Disconnect the client
			 * Be carreful, client will autoreconnect later
			 */
			void disconnect()
				throw();

		private:
			/// @name Forbidden methods
			/// @{
			ServerTcpClient(const ServerTcpClient& p_other);
			const ServerTcpClient& operator =(const ServerTcpClient& p_other);
			/// @}

			/// Configuration of the server.
			Config m_config;
			
			/// Tell is the server is started
			bool m_isStarted;

			/// The socket to receive request.
			SocketTcp* m_socket;

			/// Reader thread.
			nettone::tools::Thread* m_reader;

			/// Synchro point
			nettone::tools::Mutex* m_readMutex;

			/// Condition variable on the size of the read queue.
			nettone::tools::Cond* m_readCond;
	
			/// Read queue.
			nettone::tools::List<Buffer*>* m_readQueue;

			/// Write thread.
			nettone::tools::Thread* m_writer;

			/// Condition variable on the size of the write queue.
			nettone::tools::Cond* m_writeCond;
	
			/// Synchro point
			nettone::tools::Mutex* m_writeMutex;

			/// Write request descriptor
			struct WriteRequest
			{
				const Buffer* buffer;
				IWriteOpHandler* writeOpHandler;
				void* key;
			};

			/// Write queue.
			nettone::tools::List<WriteRequest>* m_writeQueue;

			friend class ThreadTcpClientReader;
			friend class ThreadTcpClientWriter;
		};
	}
}


#endif // __nettone_net_ServerTcpClient_h__
