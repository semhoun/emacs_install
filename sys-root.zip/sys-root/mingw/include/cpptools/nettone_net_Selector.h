#ifndef __NETTONE_NET_SELECTOR_H__
#define __NETTONE_NET_SELECTOR_H__


#include <sys/types.h>
#include <vector>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace net
	{
		class InetAddr;
		class SocketUdp;


		/**
		 * A selector observes a set of Selectable object, and notify observers when events
		 * occur on those selectables.
		 */
		class Selector
		{
		public:
			/**
			 * Interface for selectable object.
			 */
			class ISelectable
			{
			public:
				virtual ~ISelectable() {}
				virtual int getDescriptor() const = 0;
			};

			/**
			 * Set of events.
			 */
			enum Events	{
				EVT_READ = 0x0001,
				EVT_WRITE = 0x0002,
				EVT_ERROR = 0X0004
			};

			/**
			 * Interface to implement to get Selector events.
			 */
			class IEventHandler
			{
			public:
				virtual ~IEventHandler() {}
			
				/**
				 * Called when a selectable has data to ready for reading.
				 *
				 * @param p_selectable The selectable.
				 * @param p_data       Private data associated to the selectable.
				 */
				virtual void handleReadyToRead(ISelectable* const p_selectable,
											   void* const p_data)
					throw () = 0;
			
				/**
				 * Called when a selectable is ready to write data.
				 *
				 * @param p_selectable The selectable.
				 * @param p_data       Private data associated to the selectable.
				 */
				virtual void handleReadyToWrite(ISelectable* const p_selectable,
												void* const p_data)
					throw () = 0;
			
				/**
				 * Called when a selectable is in error.
				 *
				 * @param p_selectable The selectable.
				 * @param p_data       Private data associated to the selectable.
				 */
				virtual void handleOnError(ISelectable* const p_selectable,
										   void* const p_data)
					throw () = 0;
			};

			/**
			 * Constructor.
			 */
			Selector() 
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			virtual ~Selector()
				throw ();

			/**
			 * Add a selectable in the selector.
			 *
			 * @param p_selectable  The selectable to add.
			 * @param p_events      Set of events the handler is interrested in.
			 * @param p_handler     Event observer.
			 * @param p_data        Private data to give to the handler when calling hooks.
			 */
			void addSelectable(ISelectable* const p_selectable,
							   const unsigned long p_events,
							   IEventHandler* const p_handler,
							   void* const p_data = NULL)
				throw (nettone::tools::Exception);
		
			/**
			 * Wait for some event to happend on the observed selectables, ot the delay to expire.
			 *
			 * @param p_delay Timeout delay in milliseconds.
			 */
			void waitForEvents(const unsigned long p_delay)
				throw (nettone::tools::Exception);
		
		private:
			/// @name Forbidden methods
			/// @{
			Selector(const Selector& p_other);
			const Selector& operator =(const Selector& p_other);
			/// @}

			/**
			 * Clean internal to set the ready for next request.
			 */
			void clean()
				throw ();

			/**
			 * Describe a selectable waiting for some events
			 */
			struct Descriptor
			{
				ISelectable* selectable;
				IEventHandler* handler;
				void* data;
				unsigned long events;
			};

			/**
			 * @var DescMap m_descriptors
			 * Set of waiting selectables, handlers and private data.
			 */
			typedef std::vector<Descriptor> DescMap;
			DescMap m_descriptors;

			/// @name Selectable descriptor sets
			/// @{
			::fd_set m_rfds;
			::fd_set m_wfds;
			::fd_set m_efds;
			int m_maxFds;
			/// @}
		};
	}
}


#endif // __NETTONE_NET_SELECTOR_H__

