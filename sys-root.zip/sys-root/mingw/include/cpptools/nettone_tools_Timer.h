#pragma once

#include "cpptools/nettone_tools_Exception.h"
#include <sys/time.h>
#include <time.h>

namespace nettone
{
	namespace tools
	{
		/**
		 * Abstraction of timers (replace use of ost::Timerport)
		 *
		 * NOTE :
		 *
		 * Ideally we should implement it with cpp11 clock feature BUT actually 
		 * all progams are compiled with C++0x flag 
		 */
		class Timer
		{

		public :
			
			/**
			 * Type of method to get clock
			 */
			enum ClockType {
				
				REALTIME = CLOCK_REALTIME,
				MONOTONIC = CLOCK_MONOTONIC
			};
			
			/**
			 * Constructor
			 */
			Timer()
				throw(nettone::tools::Exception);
			/**
			 * Destructor
			 */
			virtual ~Timer()
				throw();

			/**
			 * Activate the timer for a specified number of millisecords
			 * This can be used to set the starting time of a realtime session
			 */
			void setTimer(unsigned long p_timeout = 0)
				throw (nettone::tools::Exception);

			/**
			   Set a timeout based on the current time reference value either
			   * from object creation or the last setTimer().  This reference
			   * can be used to time synchronize realtime data over specified
			   * intervals and force expiration when a new frame should be
			   * released in a synchronized manner.
			   *
			   * @param timeout delay in milliseconds from reference.
			   */
			void incrementTimer(unsigned long p_timeout)
				throw ();

			/**
			 * Adjust a timeout based on the current time reference value either
			 * from object creation or the last setTimer().  This reference
			 * can be used to time synchronize realtime data over specified
			 * intervals and force expiration when a new frame should be
			 * released in a synchronized manner.
			 *
			 * @param timeout delay in milliseconds from reference.
			 */
			void decrementTimer(unsigned long p_timeout)
				throw ();

			/**
			 * This is used by service threads to determine how much time
			 * remains before the timer expires based on a timeout specified
			 * in setTimer() or incrementTimer().  It can also be called after
			 * setting a timeout with incrementTimer() to see if the current timeout
			 * has already expired and hence that the application is already
			 * delayed and should skip frame(s).
			 *
			 * return time remaining in milliseconds, or TIMEOUT_INF if
			 * inactive.
			 */
			unsigned long getTimer(void) const
				throw (nettone::tools::Exception);

			/**
			 * This is used to determine how much time has elapsed since a
			 * timer port setTimer benchmark time was initially set.  This
			 * allows one to use setTimer() to set the timer to the current
			 * time and then measure elapsed time from that point forward.
			 *
			 * return time elapsed in milliseconds, or TIMEOUT_INF if
			 * inactive.
			 */
			unsigned long getElapsed(void) const
				throw (nettone::tools::Exception);

			/**
			 * This is used to "disable" the service thread from expiring
			 * the timer object.  It does not effect the reference time from
			 * either creation or a setTimer().
			 */
			void endTimer(void)
				throw();
		
		private:
			
			/** @name Forbidden methods */

			//@{
			Timer(const Timer& p_other);
			const Timer& operator = (const Timer& p_other);
			//@}

			/**
			 * Start internal timer, but doesn't activate it
			 * Activation is done with increment or decrement timer
			 */
		      void  init()
				throw (nettone::tools::Exception);
			
			/**
			 *  Internal timer
			 */
			struct timeval	m_timer;

			/**
			 * Flag for current activity
			 */ 
			bool		m_isActive;
		};
	}
}
