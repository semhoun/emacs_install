#ifndef __NETTONE_TOOLS_SCAVENGER_H__
#define	__NETTONE_TOOLS_SCAVENGER_H__


#include <string>

#include <cpptools/nettone_tools_FSMClass.h>
#include <cpptools/nettone_tools_ServerDeferred.h>
#include <cpptools/nettone_tools_ServerTimer.h>
#include <cpptools/nettone_tools_Service.h>


namespace nettone
{
    namespace tools
    {
        class ICollector
        {
        public:
            virtual ~ICollector() {}
            virtual void collect() = 0;
        };

        struct ScavengerServiceTypes
        {
            struct TStartParam
            {
                ICollector* collector;
                ServerDeferred* processor;
                ServerTimer* timeServer;
                unsigned long collectDelayInSec;
            };

            struct TStartAnswerParam
            {
                bool status;
            };

            struct TStopAnswerParam
            {
            };
        };

		struct TScavengerEventState
		{
			enum TEvent
			{
				EVENT_START,
                EVENT_STOP,
                EVENT_TO,
                EVENT_DORUN,
                EVENT_ERROR,
				MAX_EVENT
			};

			static const std::string& eventToString(const TEvent& p_event);

			enum TState
			{
				STATE_IDLE,
				STATE_WAITING,
                STATE_RUNNING,
                STATE_STOPPING,
                STATE_STOPPED,
				MAX_STATE
			};

			static const std::string& stateToString(const TState& p_state);
		};

        /*
         * Note : base classes order IS important : Scavenger must inherit first FSMClass
         * otherwise, the code compile, seems to be correct, but does not work.
         */
        class Scavenger
            : public TScavengerEventState,
              public nettone::tools::FSMClass<Scavenger, TScavengerEventState::TState, TScavengerEventState::TEvent>,
              public ScavengerServiceTypes,
              public nettone::tools::IService<ScavengerServiceTypes>
        {
        public:
            /// @name Construction/destruction
            /// @{
            Scavenger();
            virtual ~Scavenger();
            /// @}

            /// @name Method(s) from nettone::tools::IService<ScavengerServiceTypes>
            /// @{
            virtual bool requestStart(TStartParam const& p_param,
                                      IStart* const& p_handler);
            virtual bool requestStop(IStop* const& p_handler);
            /// @}

            void handleTimeout();

            /// @name
            /// @{
            void doStart(TStartParam const& p_param,
                         IStart* const& p_handler);
            void doStop(IStop* const& p_handler);
            void doTimeout();
            void doRun();
            /// @}
            
        private:
            /// @name Transition methods
            /// @{
 			virtual void defaultTransitionHandler(const TState& p_state,
												  const TEvent& p_event,
												  void* const& p_data);

			virtual void handleStateIdleEventStart(void* const& p_data);
            virtual void handleStateWaitingEventStop(void* const& p_data);
            virtual void handleStateWaitingEventTo(void* const& p_data);
            virtual void handleStateWaitingEventError(void* const& p_data);
            virtual void handleStateRunningEventStop(void* const& p_data);
            virtual void handleStateRunningEventDorun(void* const& p_data);
            virtual void handleStateRunningEventError(void* const& p_data);
            virtual void handleStateStoppingEventTo(void* const& p_data);
            virtual void handleStateStoppingEventDorun(void* const& p_data);
            /// @}

            /// @name Misc. method(s)
            /// @{
            void collect();
            /// @}

            /// @name Forbidden method(s)
            /// @{
            Scavenger(const Scavenger&);
            const Scavenger& operator =(const Scavenger&);
            /// @}

            /// @name Attributes
            /// @{
            Scavenger::TStartParam m_config;
            nettone::tools::ServerDeferred* m_processor;
            nettone::tools::ServerTimer* m_timeServer;
            nettone::tools::ServerTimer::RequestId m_timerReqId;
            IStop* m_stopHandler;
            /// @}
        };
    }
}


#endif // __NETTONE_TOOLS_SCAVENGER_H__

