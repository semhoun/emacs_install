#ifndef __NETTONE_TOOLS_IMODULEFACTORY_H__
#define __NETTONE_TOOLS_IMODULEFACTORY_H__


#include "cpptools/nettone_tools_IModule.h"


namespace nettone
{
	namespace tools
	{
		class IModuleFactory
		{
		public:
			struct ModuleDesc
			{
				std::string name;
				std::string component;
				std::string func;
			};

			virtual IModule* buildModule(const ModuleDesc& p_desc) = 0;
		};
	}
}


#endif // __NETTONE_TOOLS_IMODULEFACTORY_H__
