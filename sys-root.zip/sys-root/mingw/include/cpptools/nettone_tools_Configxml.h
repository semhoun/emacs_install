#ifndef __NETTONE_TOOLS_CONFIGXML_H__
#define __NETTONE_TOOLS_CONFIGXML_H__

#include <vector>
#include <libxml/parser.h>
#include <libxml/xpath.h>


#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		class RSA;
	}

	namespace tools
	{
		class ITransformer;
		class CompoundTransformer;
		class XmlTree;
		
		/**
		 * Base class for xml doc builder.
		 */
		class IXmlDocBuilder
		{
		public:
			virtual ~IXmlDocBuilder() {}
			virtual xmlDocPtr getDoc() const = 0;
		};
		
		/**
		 * Retrieving information from XML configuration files
		 */
		class Configxml
		{
		public:
			/**
			 * Constructor
			 */
			Configxml();
			
			/**
			 * Constructor
			 *
			 * @param p_filename Name of XML file
			 *
			 * @exception nettone::tools::Exception thrown when file is not well-formed
			 */
			Configxml(const std::string& p_filename)
				throw (Exception);

			/**
			 * Constructor
			 *
			 * @param p_filename Name of XML file
			 * @param p_rsa RSA key use for decoding 
			 *
			 * @exception nettone::tools::Exception thrown when file is not well-formed
			 */
			Configxml(const std::string& p_filename,
					  const nettone::crypto::RSA* p_rsa)
				throw (Exception);

			/**
			 * Destructor
			 */
			~Configxml()
				throw ();

			/**
			 * Set the xml doc builder.
			 * 
			 * @param p_xmlDocBuilder	The xml doc builder.
			 */
			void setDocBuilder(IXmlDocBuilder* const p_xmlDocBuilder)
				throw (Exception);
			
			/**
			 * Retrieve an integer entry using xpath
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 * @param p_resId ID of the result element to retrieve
			 *
			 * @return Integer result of given Xpath
			 *
			 * @exception nettone::tools::Exception thrown when no result found
			 */
			unsigned long getULong(const std::string& p_xpath,
								   const unsigned short p_resId = 0) const
				throw (Exception);

			/**
			 * Retrieve an text entry using xpath
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 * @param p_resId ID of the result element to retrieve
			 *
			 * @return All text found at XML element given by Xpath
			 *
			 * @exception Exception thrown when no result found
			 */
			std::string getText(const std::string& p_xpath,
								const unsigned short p_resId = 0) const
				throw (Exception);
				
		private:
			/// @name Forbidden methods
			/// @{
			Configxml(const Configxml& p_other);
			const Configxml& operator =(const Configxml& p_other);
			/// @}
			
			/**
			 * Search for special markup and transform tree if needed..
			 *
			 * @exception Exception thrown when file is not well-formed.
			 */
			void transformDoc()
				throw (Exception);
			
			/**
			 * Evaluate the xpath and return the set of result
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 *
			 * @return Set of nodes correspond to the Xpath.
			 *
			 * @exception Exception thrown when no result found			 
			 */
			xmlXPathObjectPtr getXPathResult(const std::string& p_xpath) const
				throw (Exception);
      
			/**
			 * Get the first node from the set of results evaluated.
			 *
			 * @param p_result Set of results returned by getXpathResult
			 * 
			 * @return The first node that correspond to the Xpath
			 *
			 * @deprecated
			 */
			xmlNodePtr getFirstResult(const xmlXPathObjectPtr p_result) const
				throw ();

			/**
			 * Get the first node from the set of results evaluated.
			 *
			 * @param p_result Set of results returned by getXpathResult
			 * @param p_nodeId Id of the result node to retrieve
			 * 
			 * @return A pointer to a xmlNode object.
			 */
			xmlNodePtr getResultAtIndex(const xmlXPathObjectPtr p_result,
										const unsigned short p_nodeId) const
				throw (Exception);

			/**
			 * Get all text contained in a node
			 *
			 * @param p_node  Pointer to the node
			 *
			 * @return Set of nodes correspond to the Xpath.
			 *
			 * @exception nettone::tools::Exception thrown when node is empty or contained no unignorable text		 
			 */
			std::string getTextContent(const xmlNodePtr p_node) const
				throw (Exception);
			
			/** 
			 * Iterative methods used to decode encrypted nodes
			 * 
			 * @param p_node Node to parse
			 * @param p_rsa  Key to use for decoding
			 */
			void decryptNodes(xmlNode const* p_node,
							  const nettone::crypto::RSA* p_rsa)
				throw (Exception);

			/**
			 * Pointer to the parsed document
			 */
			xmlDocPtr m_doc;
			
			/**
			 * Xml Doc builder.
			 */
			IXmlDocBuilder* m_xmlDocBuilder;
			
			/** 
			 * Current XPath request 
			 */
			mutable std::string m_xpath;

			/** 
			 * Current XPath-selected node set 
			 */
			mutable xmlXPathObjectPtr m_nodeSet;
		};
	}
}


#endif // __NETTONE_TOOLS_CONFIGXML_H__
