#ifndef __NETTONE_TOOLS_SCANDIR_H__
#define __NETTONE_TOOLS_SCANDIR_H__

#include <list>

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"


namespace nettone
{
    namespace tools
    {
        class ScanDir
        {
        public:
            typedef std::list<std::string> StringList;

            /**
             * Parse the directory p_dirpath, and create file list
             *
             * @param p_files	List of founded files
             * @param p_dirname Directory full path
             * @param p_handler The handler to notify on event (error or success).
             * @param p_regex	Regular expression for file search
             */
            static void walkDir(StringList& p_files,
                                const std::string& p_dirpath,
                                const std::string& p_regex = ".*")
                throw (nettone::tools::Exception);
        };
    }
}


#endif //  __NETTONE_TOOLS_SCANDIR_H__
