#pragma once

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_codec_identifiers.h"
#include "nettone_rtp_Packet.h"

#include <random>
#include <typeinfo>
#include <cstring>

namespace nettone
{
	namespace tools
	{
		class Exception;
		class Mutex;
	}
       
	namespace rtp
	{
		class Packet;
		class PacketBuilder;
		
		class Session
		{
			public :
			
			class  CodecInfo
			{
				friend class Session;
				
				public: 
				/**
				 * Constructor with codecName
				 */
				CodecInfo(const std::string& p_codecName)
					throw(nettone::tools::Exception);
					
				/**
				 * Constructor with codecId
				 */
				CodecInfo(const nettone::codec::CodecId &p_codecId)
					throw(nettone::tools::Exception);
				
			
				/**
				 * Forbidden constructor
				 */				
				CodecInfo() = delete;
				
				/**
				 * Forbidden copy constructor
				 */
				CodecInfo(const CodecInfo& p_codecInfo) = delete;
				
				/**
				 * Destructor
				 */
				~CodecInfo();
				
				private :
				
					void initCodecId(const std::string& p_codecName)
						throw(nettone::tools::Exception);
						
					void setPacketSize()
					 throw(nettone::tools::Exception);
					 
					void setNbPacketBySecond()
						throw();
						
					void setClockRate()
						throw();
						
					void setCodecName()
						throw(nettone::tools::Exception);
					
					nettone::codec::CodecId  m_codecId;
					
					uint8_t m_nbPacketBySecond;
					
					uint32_t m_clockRate;
					
					uint32_t m_packetSize;
					
					std::string m_codecName;
				
			}; // struct CodecInfo 	
		public :
		
			/**
			 * Forbidden constructor 
			 */
			Session() = delete;
			
			/**
			 * Constructor
			 */
			Session(nettone::codec::CodecId p_codecId)
				throw(nettone::tools::Exception);
				
			/**
			 * Destructor
			 */
			~Session();

			/**
			 * return lenght of payload
			 */
			uint32_t getPacketSize()
			throw();
			
			/**
			 * Set clock rate of specific codec (default : 8000 Hz CF RFC 3551)
			 */
			void	setClockRate(uint32_t p_clock = 8000)
				throw();
			/**
			 *  Generate random local SSRC
			 */
			void	setRandomSsrc()
				throw(nettone::tools::Exception);

			/**
			 * Set value for timestamp increment
			 */
			void	setTimestampInterval(uint32_t p_value)
				throw();
			
			/**
			 *  Generate random timestamp
			 */
			void	setRandomTimestamp()
				throw(nettone::tools::Exception);

			/**
			 * Generate random sequence number
			 */
			void	setRandomSequenceNumber()
				throw(nettone::tools::Exception);

			/**
			 * Set marker
			 */
			void	setMarker(bool p_value)
				throw();
			
			/**
			 * Set csrc : number of participant
			 */
			void	setCsrc(uint32_t p_csrc = 0)
				throw(nettone::tools::Exception);
			
			/**
	 		 * Return codecId used during Session
			*/			 
			nettone::codec::CodecId getCodecId()
				throw();
			
			/**
			 * Accessors for ssrc
			 */
			uint32_t	getSsrc()
				throw();

			/**
			 * Accessors for sequence number
			 */
			uint16_t	getSequenceNumber()
				throw();

			/**
			 * Accessor for csrc
			 */
			uint32_t	getCsrc()
				throw();

			/**
			 * Accessor for Marker
			 */
			bool getMarker()
				throw();
				
			/**
			 * Increment timestamp with m_interval
			 */
			void incrementTimestamp()
				throw();
			
			/**
			 * Increment sequence number of 1
			 */
			void incrementSequenceNumber()
				throw();
			/**
			 * Increment timestamp and sequence number
			 */			 
			 void incrementBoth()
				throw();

			/**
			 * Build packet to send with mediasteamder no marker
			 */
			nettone::rtp::Packet* buildRtpPacket(nettone::net::InetAddr* const p_address,
							     const nettone::net::Buffer* const p_payload,
							     const unsigned long p_size,
							     bool p_marker)
				throw(nettone::tools::Exception);
				
			/**
			 * Build nettone::net::Packet (used to be retrocompatible)
			 */ 
			nettone::net::Packet* buildBasePacket(nettone::net::InetAddr* const p_address,
							      const nettone::net::Buffer* const p_payload,
							      const unsigned long p_size,
							      bool p_marker)
				throw(nettone::tools::Exception);
				
			/**
			 * Forbidden copy constructor
			 */
			Session(const Session& p_other) = delete;
			
			/** 
			 * Forbidden equals assignement
			 */
			const Session& operator =(const Session& p_other) = delete; 
							  			  
		private :
		
			/**
			 * Set interval according to codec already set
			 */
			void setInterval()
				throw();
			
			/**
			 * Generate random int32
			 */
			uint32_t privateRandom32()
				throw(nettone::tools::Exception);

			/**
			 * Generate random int16
			 */
			uint16_t privateRandom16()
				throw(nettone::tools::Exception);
			
			/**
			 * Template method used to generate random number
			 */
			template<typename T>
				T  privateRandomNumber()
				throw(nettone::tools::Exception)
				{
					T value;

					std::random_device rd; 
					std::mt19937 gen(rd());
					
					if (typeid(T) == typeid(uint16_t)){
						std::uniform_int_distribution<unsigned short> dis;
						value = dis(gen);
					}
					else if (typeid(T) == typeid(uint32_t))  {
						std::uniform_int_distribution<unsigned long> dis;
						value =  dis(gen);
					}
					 else
						 throw (nettone::tools::Exception("(Session::privateRandomNumber)unsupported type"));
					return value;

				}
	
			/**
			 * Ssrc of the session
			 */
			uint32_t m_ssrc;

			/**
			 * Timestamp of packet to send
			 */
			uint32_t m_timestamp;

			/**
			 * Sequence number of packet to send
			 */
			uint16_t m_sequenceNumber;
			
			/**
			 * Csrc of packet to send
			 */
			uint32_t m_csrc;
			
			/**
			 * Marker of paquet to send
			 * Generally the first paquet of a session
			 */
			bool m_marker;
			
			/**
			 * Duration for timestamp interval
			 */
			uint32_t m_interval;
			
			/**
			 * Codec info, packets per seconds, clock rate
			 */
			std::unique_ptr<Session::CodecInfo> m_codecInfo;

		}; // class Session
		
	} // namespace RTP
	
} // namespace NETTONE
