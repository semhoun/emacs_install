#ifndef __nettone_tools_RecurMutex_h__
#define __nettone_tools_RecurMutex_h__


#include "nettone_tools_Mutex.h"
#include "nettone_tools_Cond.h"
#include "nettone_tools_Exception.h"
#include "nettone_tools_AutoLock.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Recursive mutex allow a thread to pass in a gate it
		 * has previously passed. Other thread cannot pass in the same
		 * gate as long as the first thread has not leaved the gate the same
		 * times it has passed in.
		 */
		class RecurMutex
		{
		public:
			/**
			 * Constructor.
			 */
			RecurMutex() throw (Exception);

			/**
			 * Destructor.
			 */
			~RecurMutex() throw (Exception);

			/**
			 * Lock the mutex, except for the thread that currently own it.
			 * Other threads are blocked until the mutex is completly released.
			 */
			void lock() throw (Exception);

			/**
			 * Release the mutex one time.
			 * If the lock count for the owning thread drop to 0, then waiting
			 * threads are signaled and can then try to take the mutex.
			 */
			void unlock() throw (Exception);
			
		private:
			// @name Forbidden methods
			/// @{
			RecurMutex(const RecurMutex& p_other);
			const RecurMutex& operator =( const RecurMutex& p_other);
			/// @}

			/// The underlying mutex.
			Mutex m_mutex;

			/// The condition signaling threads waiting to pass the gate.
			Cond m_cond;

			/// Thread currently owning the mutex.
			pthread_t m_owner;
			
			/// Number of times the mutex has been taken by the owning thread.
			int m_count;
		};

		/// Automatic tool for recursive mutex get/release.
		typedef AutoLock<RecurMutex> AutoRecurMutex;
	}
}


#endif // __nettone_tools_RecurMutex_h__

