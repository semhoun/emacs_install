#ifndef __NETTONE_LUA_ENVIRONMENT_H__
#define __NETTONE_LUA_ENVIRONMENT_H__


extern "C"
{
#include <lua5.1/lua.h>
#include <lua5.1/lauxlib.h>
#include <lua5.1/lualib.h>
}

#include <vector>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace lua
	{
		/**
		 * Wrapper around the Lua environment.
		 */
		class Environment
		{
		public:
			/**
			 * Constructor.
			 */
			Environment()
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			virtual ~Environment()
				throw ();

			/**
			 * Prepare the environment.
			 */
			void start()
				throw (nettone::tools::Exception);

			/**
			 * Stop the environment.
			 */
			void stop()
				throw ();

			/**
			 * Get the wrapped LUA stack.
			 */
			lua_State* getState()
				throw ();

		protected:
			/**
			 * Unstack the last received error text, and throw an exception
			 * with this message inside.
			 */
			void throwError()
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			Environment(const Environment& p_other);
			const Environment& operator =(const Environment& p_other);
			/// @}

			/**
			 * Wrapped lua_State object.
			 */
			lua_State* m_L;
		};
	}
}


#endif // __NETTONE_LUA_ENVIRONMENT_H__
