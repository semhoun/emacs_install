#ifndef __nettone_net_InetAddr_h__
#define __nettone_net_InetAddr_h__


#include <ostream>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace net
	{
		/**
		 * Inet Address
		 */
		class InetAddr
		{
		public:
			/**
			 * Constructor
			 */
			InetAddr()
				throw ();

			/**
			 * Constructor
			 */
			InetAddr(const InetAddr& p_inetAddr)
				throw ();

			/**
			 * Destructor
			 */
			virtual ~InetAddr()
				throw ();

			/** 
			 * Set inetAddr from hostname and port
			 * 
			 * @param p_hostname hostname ip or name
			 * @param p_port     hostname port
			 */
			void setAddress(const std::string& p_hostname,
							const unsigned short p_port)
				throw(nettone::tools::Exception);

			/**
			 * Get host address
			 */
			std::string getHostAddress() const
				throw ();

			/**
			 * Get host port
			 */
			unsigned short getHostPort() const
				throw ();

			/**
			 * Set to null ip/port (0.0.0.0:0)
			 */
			void reset()
				throw();

			/**
			 * Set inetaddr family to AF_UNSPEC
			 */
			void setToUNSPEC()
				throw();

			/**
			 * Get  internal struct sockaddr_in
			 */
			const struct sockaddr_in& getSockAddr() const
				throw();

			/// @name Operators
			/// @{
			bool operator <(const InetAddr& p_inetAddr) const
				throw();
			bool operator ==(const InetAddr& p_inetAddr) const
				throw();
			bool operator !=(const InetAddr& p_inetAddr) const
				throw();
			const InetAddr& operator =(const InetAddr &InetAddr);
			/// @}

			friend std::ostream& operator << (std::ostream& p_stream, const InetAddr& p_inetAddr);
			
		private:
			struct sockaddr_in m_inetAddr;
		};
	}
}


#endif // __nettone_net_InetAddr_h__
