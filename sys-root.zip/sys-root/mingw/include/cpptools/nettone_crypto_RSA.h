#ifndef __NETTONE_CRYPTO_RSA_H__
#define __NETTONE_CRYPTO_RSA_H__


#include <openssl/rsa.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		/**
		 * Class for encrypt and decrypt with RSA
		 */
		class RSA
		{
		public:
			/**
			 * Constructor.
			 */
			RSA()
				throw();

			/**
			 * Destructor.
			 */
			~RSA()
				throw();

			/** 
			 * Load a private RSA key
			 * Could be created by: "openssl genrsa -out key.pem"
			 * 
			 * @param p_data	RSA key
			 * @param p_length	size of data to load
			 */
			void loadPrivateKey(const char* p_data,
								const unsigned long p_length)
				throw (nettone::tools::Exception);

			/** 
			 * Load a public RSA key, encoded as a SubjectPublicKeyInfo structure
			 * Could be created by: "openssl rsa -in key.pem -pubout -out pubkey.pem"
			 * 
			 * @param p_data	RSA key
			 * @param p_length	size of data to load
			 */
			void loadPublicKey(const char* p_data,
							   const unsigned long p_length)
				throw (nettone::tools::Exception);

			/** 
			 * How many bytes was needed to encrypt p_size byte with previous loaded
			 * private key
			 * 
			 * @param p_size	size of data to encode
			 * 
			 * @return needed buffer
			 */
			unsigned long neededSizeToEncryptPrivate(const unsigned long p_size) const
				throw (nettone::tools::Exception);
			
			/** 
			 * How many bytes was needed to encrypt p_size byte with previous loaded
			 * public key
			 * 
			 * @param p_size	size of data to encode
			 * 
			 * @return needed buffer
			 */
			unsigned long neededSizeToEncryptPublic(const unsigned long p_size) const
				throw (nettone::tools::Exception);
			
			/** 
			 * How many bytes was needed to decrypt p_size byte with previous loaded
			 * private key
			 * 
			 * @param p_size	size of data to encode
			 * 
			 * @return needed buffer
			 */
			unsigned long neededSizeToDecryptPrivate(const unsigned long p_size) const
				throw (nettone::tools::Exception);

			/** 
			 * How many bytes was needed to decrypt p_size byte with previous loaded
			 * public key
			 * 
			 * @param p_size	size of data to encode
			 * 
			 * @return needed buffer
			 */
			unsigned long neededSizeToDecryptPublic(const unsigned long p_size) const
				throw (nettone::tools::Exception);

			/** 
			 * Encrypt data with previous loaded public key
			 * 
			 * @param p_data			data to encrypt
			 * @param p_dataLength		size of data to encrypt
			 * @param p_out				buffer where put encrypted data
			 * @param p_outLength		buffer allocated size
			 * 
			 * @return nb write bytes
			 */
			unsigned long publicEncrypt(const char* p_data, 
										const unsigned long p_dataLength,
										char const* p_out,
										const unsigned long p_outLength) const
				throw (nettone::tools::Exception);

			/** 
			 * Decrypt data with previous loaded private key
			 * 
			 * @param p_data			data to decrypt
			 * @param p_dataLength		size of data to decrypt
			 * @param p_out				buffer where put decrypted data
			 * @param p_outLength		buffer allocated size
			 * 
			 * @return nb write bytes
			 */
			unsigned long privateDecrypt(const char* p_data, 
										 const unsigned long p_dataLength,
										 char const* p_out,
										 const unsigned long p_outLength) const
				throw (nettone::tools::Exception);

			/** 
			 * Encrypt data with previous loaded public key
			 * 
			 * @param p_data			data to encrypt
			 * @param p_dataLength		size of data to encrypt
			 * @param p_out				buffer where put encrypted data
			 * @param p_outLength		buffer allocated size
			 * 
			 * @return nb write bytes
			 */
			unsigned long privateEncrypt(const char* p_data, 
										 const unsigned long p_dataLength,
										 char const* p_out,
										 const unsigned long p_outLength) const
				throw (nettone::tools::Exception);

			/** 
			 * Decrypt data with previous loaded private key
			 * 
			 * @param p_data			data to decrypt
			 * @param p_dataLength		size of data to decrypt
			 * @param p_out				buffer where put decrypted data
			 * @param p_outLength		buffer allocated size
			 * 
			 * @return nb write bytes
			 */
			unsigned long publicDecrypt(const char* p_data, 
										const unsigned long p_dataLength,
										char const* p_out,
										const unsigned long p_outLength) const
				throw (nettone::tools::Exception);

		private:
			/** 
			 * How many bytes was needed to encrypt p_size byte with p_key key
			 * 
			 * @param p_key		key used for operation
			 * @param p_size	size of data to encode
			 * 
			 * @return needed buffer
			 */
			unsigned long neededSizeToEncrypt(::RSA const* p_key,
											  const unsigned long p_size) const
				throw ();
			
			/** 
			 * How many bytes was needed to decrypt p_size byte with p_key key
			 * 
			 * @param p_key		key used for operation
			 * @param p_size	size of data to encode
			 * 
			 * @return needed buffer
			 */
			unsigned long neededSizeToDecrypt(::RSA const* p_key,
											  const unsigned long p_size) const
				throw ();

			/// @name Forbidden methods
			/// @{
			RSA(const RSA& p_other);
			const RSA& operator =(const RSA& p_other);
			/// @}

			/**
			 * Private RSA key
			 */
			::RSA* m_privateKey;

			/**
			 * Public RSA Key
			 */
			::RSA* m_publicKey;
		};
	}
}


#endif // __NETTONE_CRYPTO_RSA_H__
