#ifndef __NETTONE_TOOLS_SERVICE_H__
#define	__NETTONE_TOOLS_SERVICE_H__


#include "nettone_tools_IService.h"


namespace nettone
{
    namespace tools
    {
        template <typename S>
        class Service
            : public IService<S>
        {
        public:
            class TimeoutException
            {
            };

            virtual ~Service() {}
            
            virtual void start(typename S::TStartParam const& p_param,
                               typename S::TStartAnswerParam& p_answerParam);
            virtual void stop(typename S::TStopAnswerParam& p_param);
        };
    }
}


#include "cpptools/nettone_tools_Service_i.h"


#endif	// __NETTONE_TOOLS_SERVICE_H__

