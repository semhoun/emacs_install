#ifndef __NETTONE_TOOLS_SERVICE_I_H__
#define	__NETTONE_TOOLS_SERVICE_I_H__


#include <memory>

#include "nettone_tools_Synchro.h"


namespace nettone
{
    namespace tools
    {
        template <typename S>
        void Service<S>::start(typename S::TStartParam const& p_param,
                               typename S::TStartAnswerParam& p_answerParam)
        {
            class Handler
                : public IService<S>::IStart,
                  public nettone::tools::Synchro
            {
                friend class Service<S>;

                Handler(Service<S>* const& p_service,
                        typename S::TStartParam const& p_param)
                    : m_param(p_param),
                      m_service(p_service)
                {}
                virtual ~Handler() {}

                virtual void answerStart(typename S::TStartAnswerParam const& p_param)
                {
                    std::unique_ptr<typename IService<S>::IStart> thisAD(this);

                    m_answerParam = p_param;
                    release();
                }

                virtual bool doAsynCall()
                    throw (nettone::tools::Exception)
                {
                    // IService::start() and IService::stop() follow the same conventions
                    // as Synchro::start() about the returned value.
                    //
                    // see IService::start() for details.

                    return m_service->requestStart(m_param, this);
                }

                typename S::TStartParam m_param;
                typename S::TStartAnswerParam m_answerParam;
                Service<S>* const& m_service;
            };

            Handler* const handler = new Handler(this, p_param);
            std::unique_ptr<typename IService<S>::IStart> handlerAD(handler);
            try {
                handler->start();
                handlerAD.release();
                p_answerParam = handler->m_answerParam;
            }
            catch (Synchro::TimeoutException& p_e) {
                throw TimeoutException(); // <==
            }
            catch (...) {
                throw; // <==
            }
        }

        template <typename S>
        void Service<S>::stop(typename S::TStopAnswerParam& p_param)
        {
            class Handler
                : public IService<S>::IStop,
                  public nettone::tools::Synchro
            {
                friend class Service<S>;

                Handler(Service<S>* const& p_service)
                    : m_service(p_service)
                {}
                virtual ~Handler() {}

                virtual void answerStop(typename S::TStopAnswerParam const& p_param)
                {
                    std::unique_ptr<typename IService<S>::IStop> thisAD(this);

                    m_param = p_param;
                    release();
                }

                virtual bool doAsynCall()
                    throw (nettone::tools::Exception)
                {
                    // IService::start() and IService::stop() follow the same conventions
                    // as Synchro::start() about the returned value.
                    //
                    // see IService::start() for details.

                    return m_service->requestStop(this);
                }

                typename S::TStopAnswerParam m_param;
                Service* const& m_service;
            };

            Handler* const handler = new Handler(this);
            std::unique_ptr<typename IService<S>::IStop> handlerAD(handler);
            try {
                handler->start();
                handlerAD.release();
                p_param = handler->m_param;
            }
            catch (Synchro::TimeoutException& p_e) {
                throw TimeoutException(); // <==
            }
            catch (...) {
                throw; // <==
            }
        }
    }
}


#endif // __NETTONE_TOOLS_SERVICE_I_H__

