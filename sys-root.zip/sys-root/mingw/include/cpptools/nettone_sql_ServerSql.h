#ifndef __NETTONE_SQL_SERVERSQL_H__
#define __NETTONE_SQL_SERVERSQL_H__


#include <list>

#include "nettone_tools_Thread.h"
#include "nettone_tools_Monitor.h"
#include "nettone_sql_SqlRequestor.h"

namespace nettone
{
	namespace sql
	{
		/**
		 * Server of SQL requests.
		 */
		class ServerSql
		{
		public:
			/**
			 * Creation configuration.
			 */
			struct Config
			{
				/**
				 * Ideal number of request processors.
				 */
				unsigned short nbProcessors;

				/**
				 * Minimal number of request processors.
				 */
				unsigned short nbProcessorsRequired;

				/**
				 * Max number of pending requests.
				 */
				unsigned short nbMaxPendingRequests;

				/**
				 * SqlRequestor configuration.
				 */
				SqlRequestor::Config requestorConf;
			};

			/**
			 * Constructor.
			 */
			ServerSql()
				throw (tools::Exception);

			/**
			 * Destructor.
			 */
			~ServerSql()
				throw ();

			/**
			 * Start the server.
			 *
			 * @param p_config The runtime configuration.
			 */
			void start(const Config& p_config)
				throw (tools::Exception);
			
			/**
			 * Stop the server.
			 */
			void stop()
				throw ();

			/**
			 * Type of the request ID.
			 */
			class RequestId
			{
			public:
				/**
				 * The null object.
				 */
				static const RequestId null;

				/**
				 * Return a new unique RequestId object.
				 * Value loops on 32 bits unsigned.
				 */
				static RequestId getNewId()
					throw ();

				/**
				 * Constructor.
				 */
				RequestId()
					throw ();

				/**
				 * Casting to a unsigned long.
				 */
				operator unsigned long() const
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator ==(const RequestId& p_other)
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator !=(const RequestId& p_other)
					throw ();

				/**
				 * Assignement operator.
				 */
				const RequestId& operator =(const RequestId& p_other)
					throw ();

			private:
				/**
				 * Constructor.
				 */
				RequestId(const unsigned long p_reqId)
					throw ();

				/**
				 * The ID itself.
				 */
				unsigned long m_reqId;
			};

			/**
			 * Base interface for handlers of request result.
			 */
			class IHandlerQuery
			{
			public:
				/**
				 * Destructor.
				 */
				virtual ~IHandlerQuery() {}

				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleError(const RequestId& p_reqId,
										 const std::string& p_error)
					throw ();
			};

			/**
			 * Handle the result of a query returning some rows.
			 */
			class IHandlerQueryWithResult
				: public IHandlerQuery
			{
			public:
				/**
				 * Callback method called when the request has been successfully processed.
				 * 
				 * @param p_result The extracted data.
				 */
				virtual void handleResult(const RequestId& p_reqId,
										  const SqlRequestor::Result& p_result)
					throw () = 0;
			};

			/**
			 * Request a SQL operation that will return a result.
			 *
			 * @param p_reqId   Where to store the request ID.
			 * @param p_sqlQuery The query to execute.
			 * @param p_handler The handler of request.
			 */
			void queryWithResult(RequestId& p_reqId,
								 const std::string& p_sqlQuery,
								 IHandlerQueryWithResult* const p_handler)
				throw (tools::Exception);

			/**
			 * Handle the result of a query returning some rows.
			 */
			class IHandlerQueryWithoutResult
				: public IHandlerQuery
			{
			public:
				/**
				 * Callback method called when the request has been successfully processed.
				 */
				virtual void handleResult(const RequestId& p_reqId)
					throw () = 0;
			};

			/**
			 * Request a SQL operation that will not return a result.
			 *
			 * @param p_reqId     Where to store the request ID.
			 * @param p_sqlQuery  The query to execute.
			 * @param p_handler   The handler of request.
			 */
			void queryWithoutResult(RequestId& p_reqId,
									const std::string& p_sqlQuery,
									IHandlerQueryWithoutResult* const p_handler)
				throw (tools::Exception);

			template <typename C>
			class LateRunner0
				: public IHandlerQueryWithResult
			{
			public:
				typedef void (C::* Func)(const RequestId&,
										 const SqlRequestor::Result&);
				LateRunner0(C* const p_target,
							Func p_func)
					: m_target(p_target),
					  m_func(p_func)
				{}

			private:
				virtual void handleResult(const RequestId& p_reqId,
										  const SqlRequestor::Result& p_result)
					throw ()
				{
					std::unique_ptr<IHandlerQueryWithResult> thisAD(this);
					(m_target->*m_func)(p_reqId, p_result);
				}

				C* m_target;
				Func m_func;
			};

			template <typename C>
			IHandlerQueryWithResult* buildRunner(C* const p_target,
												 void (C::* p_func)())
			{
				return new LateRunner0<C>(p_target, p_func);
			}

			template <typename C>
			inline void queryWithResult(RequestId& p_reqId,
										const std::string& p_sqlQuery,
										C* const p_target,
										void (C::* p_func)(const RequestId&,
														   const SqlRequestor::Result&))
			{
				std::unique_ptr<IHandlerQueryWithResult> laterRunnerAD(buildRunner(p_target, p_func));
				queryWithResult(p_reqId, p_sqlQuery, laterRunnerAD.get());
				laterRunnerAD.release();
			}
			
		private:
			/// @name Forbidden methods
			/// @{
			ServerSql(const ServerSql& p_other);
			const ServerSql& operator =(const ServerSql& p_other);
			/// @}

			/**
			 * Task managing the timers.
			 */
			class RequestProcessor
				: public tools::Thread
			{
			public:
				/**
				 * Constructor.
				 *
				 * @param p_this The outer object.
				 */
				RequestProcessor(ServerSql* const p_this)
					throw (tools::Exception);

				/**
				 * Destructor.
				 */
				virtual ~RequestProcessor()
					throw ();

			private:
				/// @name Methods from Thread
				/// @{
				virtual void run()
					throw ();
				/// @}

				/**
				 * Outer object.
				 */
				ServerSql* m_this;
			};
			friend class RequestProcessor;

			/**
			 * Processors of request.
			 */
			std::list<RequestProcessor*> m_procs;

			/**
			 * Common base of all descriptors of a pending requests.
			 */
			class RequestBase
			{
			public:
				/**
				 * Constructor.
				 *
				 * @param p_query The SQL query.
				 * @param p_key   The key identifying the request.
				 */
				RequestBase(const std::string& p_query,
							void* const p_key)
					throw ();

				/**
				 * Destructor.
				 */
				virtual ~RequestBase()
					throw () {};

				/**
				 * The SQL query.
				 */
				std::string m_query;

				/**
				 * The key identifying the request.
				 */
				void* key;

				/**
				 * Request ID.
				 */
				RequestId reqId;

				/**
				 * Error handler.
				 */
				IHandlerQuery* m_errorHandler;

				/**
				 * Process the request.
				 */
				virtual void process(ServerSql* const p_server)
					throw (tools::Exception) = 0;

			};

			/**
			 * Post a request.
			 *
			 * @param p_reqId   Where to store the request ID.
			 * @param p_request The request to process.
			 *
			 * @return The ID of the request.
			 */
			void postRequest(RequestId& p_reqId,
							 RequestBase* const p_request)
				throw (tools::Exception);

			/**
			 * Describe a query that will return some rows.
			 */
			class RequestQueryWithResult
				: public RequestBase
			{
			public:
				/**
				 * Constructor.
				 *
				 * @param p_query   The SQL query.
				 * @param p_key     The key identifying the request.
				 * @param p_handler The handler of result.
				 */
				RequestQueryWithResult(const std::string& p_query,
									   void* const p_key,
									   IHandlerQueryWithResult* const p_handler)
					throw ();

			private:
				/// @name Methods from RequestBase
				/// @{
				virtual void process(ServerSql* const p_server)
					throw (tools::Exception);
				/// @}

				/**
				 * Callback handler.
				 */
				IHandlerQueryWithResult* const m_handler;
			};
			friend class RequestQueryWithResult;

			/**
			 * Describe a query that will not return anything.
			 */
			class RequestQueryWithoutResult
				: public RequestBase
			{
			public:
				/**
				 * Constructor.
				 *
				 * @param p_query   The SQL query.
				 * @param p_key     The key identifying the request.
				 * @param p_handler The handler of result.
				 */
				RequestQueryWithoutResult(const std::string& p_query,
										  void* const p_key,
										  IHandlerQueryWithoutResult* const p_handler)
					throw ();

			private:
				/// @name Methods from RequestBase
				/// @{
				virtual void process(ServerSql* const p_server)
					throw (tools::Exception);
				/// @}

				/**
				 * Callback handler.
				 */
				IHandlerQueryWithoutResult* const m_handler;
			};
			friend class RequestQueryWithoutResult;

			/**
			 * Server configuration
			 */
			Config m_config;

			/**
			 * The MYSQL connection manager.
			 */
			SqlRequestor m_mySql;

			/**
			 * Monitor the request queue.
			 */
			tools::Monitor* m_monitor;
		
			/**
			 * Request queue.
			 */
			std::list<RequestBase*> m_requests;
		};
	}
}


#endif // __NETTONE_SQL_SERVERSQL_H__
