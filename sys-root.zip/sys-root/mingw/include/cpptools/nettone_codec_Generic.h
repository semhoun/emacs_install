#ifndef __KERTEL_CONVERTER_GENERIC_FLAG__
#define __KERTEL_CONVERTER_GENERIC_FLAG__



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <vector>
#include <cstring>
#include <stdint.h>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"


namespace nettone {
	namespace codec {

	class CConverterXXX
	{
	private:
		CConverterXXX (const CConverterXXX&) throw ();				// forbid copy
		CConverterXXX& operator= (const CConverterXXX&) throw ();	// forbid copy

	protected:
		bool									m_ConversionInProgress;
		uint64_t								m_ConversionDurationInSecondLast;
		uint64_t								m_ConversionDurationInSecondMax;

		void	EndConversionXXX	(const char * p_Origin, const char * p_From) throw ();

	public:
		CConverterXXX () throw ();
		void	Reset () throw ();
		void	GetStats		(uint64_t& p_ConversionDurationInSecondLast, uint64_t& p_ConversionDurationInSecondMax) throw ();
	};

	}// namespace codec
} // namespace nettone

#endif // __KERTEL_CONVERTER_GENERIC_FLAG__
