#ifndef __NETTONE_LOG_LOGGING_H__
#define __NETTONE_LOG_LOGGING_H__


#include <log4cxx/logger.h>

#ifndef MODULE_LOG_DEBUG
#define MODULE_LOG_DEBUG 1
#endif

#ifndef MODULE_LOG_INFO
#define MODULE_LOG_INFO 1
#endif

#ifndef MODULE_LOG_WARN
#define MODULE_LOG_WARN 1
#endif

#ifndef MODULE_LOG_ERROR
#define MODULE_LOG_ERROR 1
#endif

#ifndef MODULE_LOG_FATAL
#define MODULE_LOG_FATAL 1
#endif

#define LOG_BEGIN(logger, static_level, dyn_level) \
{ \
	if (static_level) {\
		try { \
			::log4cxx::LoggerPtr& myLog = logger; \
			const ::log4cxx::LevelPtr& myLevel = dyn_level; \
			std::ostringstream _ostr;

#define LOG_DEBUG_BEGIN(logger) \
   LOG_BEGIN(logger, MODULE_LOG_DEBUG, ::log4cxx::Level::getDebug())

#define LOG_INFO_BEGIN(logger) \
   LOG_BEGIN(logger, MODULE_LOG_INFO, ::log4cxx::Level::getInfo())

#define LOG_WARN_BEGIN(logger) \
   LOG_BEGIN(logger, MODULE_LOG_WARN, ::log4cxx::Level::getWarn())

#define LOG_ERROR_BEGIN(logger) \
   LOG_BEGIN(logger, MODULE_LOG_ERROR, ::log4cxx::Level::getError())

#define LOG_FATAL_BEGIN(logger) \
   LOG_BEGIN(logger, MODULE_LOG_FATAL, ::log4cxx::Level::getFatal())

#define LOG_STREAM _ostr

#define LOG_END \
			myLog->forcedLog(myLevel, LOG_STREAM.str(), LOG4CXX_LOCATION); \
		} \
		catch (...) {} \
	} \
}

#endif // __MCMS_LOGGING_H__
