/* 
 * File:   nettone_tools_IService.h
 * Author: nicolas
 *
 * Created on 12 octobre 2010, 12:20
 */

#ifndef __NETTONE_TOOLS_ISERVICE_H__
#define	__NETTONE_TOOLS_ISERVICE_H__


namespace nettone
{
    namespace tools
    {
        template <typename S>
        class IService
        {
        public:
            virtual ~IService() {}

            class IStart
            {
            public:
                virtual ~IStart() {}

                virtual void answerStart(typename S::TStartAnswerParam const& p_param) = 0;
            };

            virtual bool requestStart(typename S::TStartParam const& p_param,
                                      IStart* const& p_handler) = 0;

            class IStop
            {
            public:
                virtual ~IStop() {}

                virtual void answerStop(typename S::TStopAnswerParam const& p_param) = 0;
            };

            virtual bool requestStop(IStop* const& p_handler) = 0;
        };
    }
}


#endif	// __NETTONE_TOOLS_ISERVICE_H__

