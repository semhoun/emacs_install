#ifndef __NETTONE_TOOLS_XMLTREETRANSFORMER_H__
#define __NETTONE_TOOLS_XMLTREETRANSFORMER_H__


#include <map>

#include "nettone_tools_XmlTree.h"


namespace nettone
{
	namespace tools
	{
		class Transformer
			: public ITransformer
		{
		public:
			virtual xmlNodePtr applyIn(const xmlNodePtr p_node) { return p_node; }
			virtual xmlNodePtr applyOut(const xmlNodePtr p_node) { return p_node; }
		};

		class Printer
			: public Transformer
		{
		public:
			virtual xmlNodePtr applyIn(const xmlNodePtr p_node);
		};

		class Replacer
			: public Transformer
		{
		public:
			virtual xmlNodePtr applyIn(const xmlNodePtr p_node);
		};

		template <typename CB>
		class Builder
			: public Transformer
		{
		public:
			typedef std::map<std::string, CB> CallbackSet;
			
			Builder(const CallbackSet& p_cbSet)
				: m_cbSet(p_cbSet)
			{}
			
			virtual xmlNodePtr applyIn(const xmlNodePtr p_node)
			{
				typename CallbackSet::iterator pos = m_cbSet.find((char*)(p_node->name));
				if (pos == m_cbSet.end()) {
					return p_node; // <== 
				}
				
				return (pos->second)(p_node);
			}
			
			CallbackSet m_cbSet;
		};
		
		class CompoundTransformer
			: public ITransformer
		{
		public:
			void addTransformer(ITransformer* const p_transformer);

			virtual xmlNodePtr applyIn(const xmlNodePtr p_node);
			virtual xmlNodePtr applyOut(const xmlNodePtr p_node);

		private:
			typedef std::vector<ITransformer*> TransformerSet;
			TransformerSet m_transformers;
		};
	}
}


#endif // __NETTONE_TOOLS_XMLTREETRANSFORMER_H__
