#ifndef __NETTONE_LUA_COMPILER_H__
#define __NETTONE_LUA_COMPILER_H__


extern "C"
{
#include <lua5.1/lua.h>
#include <lua5.1/lauxlib.h>
#include <lua5.1/lualib.h>
}

#include <vector>

#include "nettone_tools_Exception.h"
#include "nettone_lua_Environment.h"
#include "nettone_lua_Chunk.h"


namespace nettone
{
    namespace lua
    {
        /**
         * Compile text buffers in LUA chunks.
         */
        class Compiler
            : public Environment
        {
        public:
            /**
             * Constructor.
             */
            Compiler()
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~Compiler()
                throw ();

            /**
             * Compile a LUA chunk.
             *
             * @param p_code The text of the LUA program to execute.
             */
            Chunk* compile(const std::string& p_code)
                throw (nettone::tools::Exception);

        private:
            /// @name Forbidden methods
            /// @{
            Compiler(const Compiler& p_other);
            const Compiler& operator =(const Compiler& p_other);
            /// @}
        };
    }
}


#endif // __NETTONE_LUA_COMPILER_H__
