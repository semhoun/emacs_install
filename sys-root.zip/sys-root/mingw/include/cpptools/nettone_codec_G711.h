#ifndef __KERTEL_CONVERTER_G711_TO_PCM_FLAG__
#define __KERTEL_CONVERTER_G711_TO_PCM_FLAG__



// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <vector>
#include <cstring>
#include <stdint.h>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_Generic.h"


namespace nettone {
	namespace codec {


	//=============================================================================
	// Constants for G711 codec
	//=============================================================================
	const uint32_t	G711_COMPRESSED_FRAME_SIZE_10_MSEC_IN_BYTE			= 80;
	const uint32_t	G711_COMPRESSED_FRAME_SIZE_20_MSEC_IN_BYTE			= 160;
	const uint32_t	G711_COMPRESSED_FRAME_SIZE_30_MSEC_IN_BYTE			= 240; // (160 bytes for 20 msec, 240 bytes for 30 msec)
	const uint32_t	G711_COMPRESSED_FRAME_MAX_SIZE_IN_INT8				= G711_COMPRESSED_FRAME_SIZE_30_MSEC_IN_BYTE * 10;

	const uint32_t	G711_UCOMPRESSED_AS_PCM_FRAME_10_MSEC_SIZE_IN_INT16 = 80;
	const uint32_t	G711_UCOMPRESSED_AS_PCM_FRAME_20_MSEC_SIZE_IN_INT16 = 160;
	const uint32_t	G711_UCOMPRESSED_AS_PCM_FRAME_30_MSEC_SIZE_IN_INT16 = 240;
	const uint32_t	G711_UCOMPRESSED_AS_PCM_FRAME_MAX_SIZE_IN_INT16		= G711_UCOMPRESSED_AS_PCM_FRAME_30_MSEC_SIZE_IN_INT16 * 10;

	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	// @@ Generic functions
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	bool IsValidCompressedPayloadSizeG711				(uint32_t p_RtpPayloadSizeInByte);
	void CheckValidityOfDestBufferSizeInInt16G711ToPcm	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt16, uint32_t& p_MinimumExpectedSizeInInt16);
	void CheckValidityOfDestBufferSizeInUint8PcmToG711	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt8, uint32_t& p_MinimumExpectedSizeInInt8);

	class CConverterG711ToPcm : public CConverterXXX
	{
	private:
		CConverterG711ToPcm (const CConverterG711ToPcm&) throw ();
		CConverterG711ToPcm& operator= (const CConverterG711ToPcm&) throw ();

		int32_t ConvertByteG711UlawToLinearPcm (uint8_t p_G711UlawByte, int16_t& p_PcmConversionResult) throw ();
		int32_t ConvertByteG711AlawToLinearPcm (uint8_t p_G711AlawByte, int16_t& p_PcmConversionResult) throw ();

		std::vector<int16_t>	m_VectorExponent; // just a hardcoded table necessary for conversion
		int32_t					m_VectorExponentSize;
	public:
		CConverterG711ToPcm () throw ();
		void BeginConversion (int32_t& p_Iret) throw ();

		int32_t ConvertBufferFromG711UlawToLinearPcm	(uint8_t *	p_EncodedData,
											uint32_t	p_EncodedDataLen,
											int16_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInInt16,
											uint32_t&	p_DecodedDataLenInInt16) throw ();

		int32_t ConvertBufferFromG711AlawToLinearPcm	(uint8_t *	p_EncodedData,
											uint32_t	p_EncodedDataLen,
											int16_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInInt16,
											uint32_t&	p_DecodedDataLenInInt16) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};



	//--http://dystopiancode.blogspot.fr/2012/02/pcm-law-and-u-law-companding-algorithms.html
	class CConverterPcmToG711 : public CConverterXXX
	{
	private:
		CConverterPcmToG711 (const CConverterPcmToG711&) throw ();	// forbid copy
		CConverterPcmToG711& operator= (const CConverterPcmToG711&);	// forbid copy

		int32_t ConvertLinearPcmToByteG711Ulaw (int16_t p_PcmWord, uint8_t& p_G711UlawByteConversionResult) throw ();
		int32_t ConvertLinearPcmToByteG711Alaw (int16_t p_PcmWord, uint8_t& p_G711AlawByteConversionResult) throw ();

	public:
		CConverterPcmToG711 () throw ();
		void BeginConversion (int32_t& p_Iret) throw ();

		int32_t ConvertBufferFromLinearPcmToG711Ulaw( int16_t *	p_EncodedData,
											uint32_t	p_EncodedDataLenInInt16,
											uint8_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInByte,
											uint32_t&	p_DecodedDataLen) throw ();


		int32_t ConvertBufferFromLinearPcmToG711Alaw( int16_t *	p_EncodedData,
											uint32_t	p_EncodedDataLenInInt16,
											uint8_t *	p_DecodedData,
											uint32_t	p_DecodedBufferSizeInByte,
											uint32_t&	p_DecodedDataLen) throw ();

		void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
	};


	}// namespace codec
} // namespace nettone



#endif // __KERTEL_CONVERTER_G711_TO_PCM_FLAG__


