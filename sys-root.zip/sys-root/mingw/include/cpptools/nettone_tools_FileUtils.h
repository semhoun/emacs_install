#pragma once

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"
#include "nettone_tools_Buffer.h"


namespace nettone::tools
{
	class FileUtils
	{
	public:
		/**
		 * Buffer
		 */ 
		typedef Buffer<unsigned char> FileBuf;

		/**
		 * Copy a file
		 *
		 * @param p_origfile		Original file to copy
		 * @param p_newfile			Where copy the file
		 */
		static void copy(const std::string& p_origfile,
						 const std::string& p_newfile)
			throw (nettone::tools::Exception);

		/**
		 * Move the file, copy it, and remove original file
		 *
		 * @param p_origfile		Original file to move
		 * @param p_newfile			Where move the file
		 */
		static void move(const std::string& p_origfile,
						 const std::string& p_newfile)
			throw (nettone::tools::Exception);

		/**
		 * Remove a file
		 *
		 * @param p_filepath full path of file to remove
		 */
		static void remove(const std::string& p_filepath)
			throw (nettone::tools::Exception);

		/**
		 * Rename a file
		 *
		 * @param p_oldpath Old file name
		 * @param p_newpath New file name
		 */
		static void rename(const std::string& p_oldpath,
						   const std::string& p_newpath)
			throw (nettone::tools::Exception);

		/**
		 * Get size of a file
		 *
		 * @param p_filepath full path of file
		 *
		 * @return size of the file
		 */
		static unsigned long getSize(const std::string& p_filepath)
			throw (nettone::tools::Exception);

		/**
		 * Create a sub-directory in adding "/" each p_with.
		 * Make this transformation starting cur
		 *
		 * @param p_dir		directory to transform
		 * @param p_width	width of subdir
		 * @param p_cur		transformation starting
		 * @param p_nbMax	Max of "/" added
		 *
		 * @return
		 */
		static std::string dir2multiDir(const std::string& p_dir,
										const unsigned long p_width,
										const unsigned long p_cur = 0,
										const unsigned long p_nbMax = 256)
			throw();

		/**
		 * Get kind of file p_filepath is
		 *
		 * @param p_filepath File to identify
		 *
		 * @return kind of file
		 */
		enum FileType {
					   e_FILE,
					   e_DIRECTORY,
					   e_CHARACTER_DEVICE,
					   e_BLOCK_DEVICE,
					   e_FIFO,
					   e_LINK,
					   e_SOCKET,
					   e_UNKNOW
		};
		static FileType fileType(const std::string& p_filepath)
			throw (nettone::tools::Exception);

		/**
		 *  Create a directory
		 *
		 * @param p_dir path of directory to create
		 */
		static void mkdir(const std::string& p_dir)
			throw (nettone::tools::Exception);

		/**
		 *  Create a directory, recursivly
		 *
		 * @param p_dir path of directory to create
		 */
		static void mkdirRecur(const std::string& p_dir)
			throw (nettone::tools::Exception);

		/**
		 *  Delete a directory
		 *
		 * @param p_dir path of directory to delete
		 */
		static void rmdir(const std::string& p_dir)
			throw (nettone::tools::Exception);

		/**
		 *  Delete a directory recursivly, ie all subdirectory and file
		 *
		 * @param p_dir path of directory to delete
		 */
		static void rmdirRecur(const std::string& p_dir)
			throw (nettone::tools::Exception);

		/**
		 * Load a file.
		 *
		 * @param p_filename The name of the file to load.
		 *
		 * return File's data, caller is responsible for deletion
		 */
		static FileBuf* loadFile(const std::string& p_filename)
			throw (nettone::tools::Exception);
	};
}
