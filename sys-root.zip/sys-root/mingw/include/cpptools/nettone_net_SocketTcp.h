#ifndef __NETTONE_NET_SOCKETTCP_H__
#define __NETTONE_NET_SOCKETTCP_H__


#include "nettone_net_Socket.h"


namespace nettone
{
	namespace net
	{
		class InetAddr;


		/**
		 * TCP Socket.
		 */
		class SocketTcp
			: public Socket
		{
		public:
			/**
			 * Constructor.
			 */
			SocketTcp()
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			virtual ~SocketTcp()
				throw ();

			/**
			 * Set the socket to be nonblocking.
			 */
			void setNonBlocking()
				throw (nettone::tools::Exception);

			/**
			 * Connect the socket to a remote host/port.
			 *
			 * @param p_remote Host/port to be connected to.
			 */
			bool connect(const InetAddr& p_remote)
				throw (nettone::tools::Exception);

			/**
			 * Disconnect the socket
			 */
			void disconnect()
				throw (nettone::tools::Exception);

			/**
			 * Tell if the socket is connected.
			 */
			bool isConnected() const
				throw ();

			/**
			 * Read the next message.
			 * If the socket is in blocking mode, it will wait for data to arrive. 
			 * Otherwise it simply returns.
			 * 
			 * @param p_buffer     Where to store the data.
			 * @param p_realSize   Real amount of data received (packet size).
			 * @param p_bufferSize Max amount of data to receive.
			 *
			 * @retval true  Some data have been read.
			 * @retval false No data available (buffer pointed at by p_buffer
			 *               and p_realsize not modified). Only when socket is
			 *               nonblocking.
			 */
			bool receive(char* const p_buffer,
						 unsigned long& p_realSize,
						 const unsigned long p_bufferSize) 
				throw (nettone::tools::Exception);

			/**
			 * Send data to the default destination.
			 * Meaningful only on connected socket.
			 * 
			 * @param p_buffer     Data to send.
			 * @param p_bufferSize Amout of data to send.
			 *
			 * @retval true  Data have been sent.
			 * @retval false Return if the socket is nonblocking and the write
			 *               operation would block.
			 */
			bool send(const char* const p_buffer,
					  const unsigned long p_bufferSize) 
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			SocketTcp(const SocketTcp& p_other);
			const SocketTcp& operator =(const SocketTcp& p_other);
			/// @}

			/**
			 * Set to true when the socket has been successfully connected.
			 */
			bool m_connected;
		};
	}
}


#endif // __NETTONE_NET_SOCKETTCP_H__
