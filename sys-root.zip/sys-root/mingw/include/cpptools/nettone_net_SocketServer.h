#ifndef __nettone_net_SocketServer_h__
#define __nettone_net_SocketServer_h__


#include <string>

#include "nettone_tools_Exception.h"
#include "nettone_net_Socket.h"


namespace nettone
{
	namespace net
	{
		class InetAddr;


		/**
		 * Portable SocketServer class.
		 */
		class SocketServer
			: public Socket
		{
		public:
			/**
			 * Constructor.
			 *
			 * @param p_addr	Ip addr the server will bind to 
			 * @param p_port	Port the server will listen to.
			 */
			SocketServer(const std::string& p_addr,
						 const int p_port) 
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			virtual ~SocketServer() throw ();

			/**
			 * Read the next message. If no message available, wait until
			 * one arrives, or a 500 delay has expired.
			 * 
			 * @param p_origin     Address of the packet originator.
			 * @param p_buffer     Where to store the data.
			 * @param p_realSize   Real amount of data received (packet size).
			 * @param p_bufferSize Max amount of data to receive.
			 */
			bool receiveFrom(InetAddr& p_origin,
							 char* const p_buffer,
							 unsigned long& p_realSize,
							 const unsigned long p_bufferSize) 
				throw (nettone::tools::Exception);

			/**
			 * Send data to the destination.
			 *
			 * @param p_dest       Where to send the data.
			 * @param p_buffer     Data to send.
			 * @param p_bufferSize Amout of data to send.
			 *
			 * @bug Currently, an exception is thrown if the buffer to send is 
			 *      too big to fit in a packet.
			 */
			void send(InetAddr& p_dest,
					  const char* const p_buffer,
					  const unsigned long p_bufferSize) 
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			SocketServer(const SocketServer& p_other);
			const SocketServer& operator =(const SocketServer& p_other);
			/// @}
		};
	}
}


#endif // __nettone_net_SocketServer_h__
