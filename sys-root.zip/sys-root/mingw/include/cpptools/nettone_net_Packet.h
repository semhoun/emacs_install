#ifndef __nettone_net_Packet_h__
#define __nettone_net_Packet_h__


#include "nettone_net_Buffer.h"


namespace nettone
{
	namespace net
	{
		class InetAddr;

		/**
		 * UDP packet.
		 */
		class Packet
		{
		public:
			/**
			 * Constructor.
			 *
			 * @param p_address Inet address of the host.
			 * @param p_buffer  Data.
			 * @param p_size	Real amount of data in buffer
			 *
			 * @note Objects passed as parameters are own by the new Packet.
			 */
			Packet(InetAddr* const p_address,
				   const Buffer* const p_data,
				   const unsigned long p_size) throw ();

			/**
			 * Destructor.
			 */
			virtual ~Packet();

			/**
			 * Get the host address.
			 */
			InetAddr* getHostAddress() const throw ();

			/**
			 * Get the data.
			 */
			const Buffer* getData() const throw ();

			/**
			 * Get the amount of data in packet.
			 */
			unsigned long getSize() const throw ();

		private:
			/// @name Forbidden methods
			/// @{
			Packet(const Packet& p_other);
			const Packet& operator =(const Packet& p_other);
			/// @}

			/// Address of the host.
			InetAddr* const m_address;

			/// Data buffer.
			const Buffer* const m_data;

			/// Amount of data in buffer.
			unsigned long m_size;
		};
	}
}


#endif // __nettone_net_Packet_h__
