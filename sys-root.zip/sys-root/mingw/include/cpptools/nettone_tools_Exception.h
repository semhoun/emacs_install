#ifndef __NETTONE_TOOLS_EXCEPTION_H__
#define __NETTONE_TOOLS_EXCEPTION_H__


#include <errno.h>
#include <string>
#include <exception>


namespace nettone
{
	namespace tools
	{
		class Exception
			: public std::exception
		{
		public:
			/**
			* Constructor.
			*
			* @param p_errorText Description of the exception cause.
			*/
			Exception(const std::string& p_errorText) throw ();

			/**
			* Destructor.
			*/
			virtual ~Exception() throw ();

			/**
			* Get the error text.
			*
			* @see std::exception::what()
			*/
			virtual const char* what() const throw ();

		private:
			/** Text of the error. */
			const std::string m_errorText;
		};

		class ExceptionWithCode : public Exception
		{
		public:
			ExceptionWithCode(int32_t p_ErrorCode, const std::string& p_errorText) throw ();
			/**
			* Destructor.
			*/
			virtual ~ExceptionWithCode() throw ();

			virtual int32_t getErrorCode() const throw ();

		private:
			int32_t     m_errorCode;
		};
	}
}


#endif // __NETTONE_TOOLS_EXCEPTION_H__
