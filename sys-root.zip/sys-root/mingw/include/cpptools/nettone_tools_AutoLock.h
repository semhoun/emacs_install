#ifndef __NETTONE_TOOLS_AUTOLOCK_H__
#define __NETTONE_TOOLS_AUTOLOCK_H__


#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Helper class to automatically lock a mutex when creating a AutoLock, 
		 * and unlock when destroying it.
		 */
		template <typename T>
		class AutoLock
		{
		public:
			/** 
			 * Constructor.
			 */
			inline AutoLock(T& p_lock)
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			inline ~AutoLock()
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			AutoLock(const AutoLock<T>& p_other);
			const AutoLock<T>& operator =(const AutoLock<T>& p_other);
			/// @}

			/// The lock to get/release
			T* const m_lock;
		};
	}
}


#include "nettone_tools_AutoLock.ih"


#endif // __NETTONE_TOOLS_AUTOLOCK_H__
