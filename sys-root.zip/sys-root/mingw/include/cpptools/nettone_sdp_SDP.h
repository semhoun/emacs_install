#pragma once

#include <vector>
#include <map>
#include <memory>
#include <list>
#include <stdint.h>

#include "nettone_tools_Exception.h"
#include "nettone_error_codes.h"
#include "nettone_codec_identifiers.h"

namespace nettone
{
    namespace sdp
    {
        class Deserializer;
        class ProtoVersion;
        class Origin;
        class Session;
        class Information;
        class Connection;
        class Time;
        class Attributes;
        class AttrPTime;
        class AttrCnxMode;
        class AttrCodec;
        class Media;


        /**
         * Full sdp class
         */
        class SDP
        {
            friend class Deserializer;

        public:
            /**
             * Les infos de codecs ne fonctionnent actuellement que pour les codec audio
             * Les codecs inconnu ne sont pas ajoutés dans cette liste
             */
            struct CodecInfo
            {
                // Codec type
                nettone::codec::CodecId id;

                // Codec name
                std::string name;

                // Paylaod
                unsigned short payload;

                // clockRate
                unsigned long clockRate;
            };
            typedef std::list<CodecInfo> CodecsInfo;

            /**
             * Constructor
             */
            SDP()
                throw (nettone::tools::Exception);

            /**
             * Destructor
             */
            ~SDP()
                throw();

            /**
             * Duplicate the sdp, caller is reponsible for destruction of duplicated object
             */
            SDP* clone()
                throw();

            /**
             * Get protocol version
             *
             * @exception nettone::tools::Exceptions Thrown if not present because is mandatory
             */
            ProtoVersion* getProtoVersion()
                throw(nettone::tools::Exception);

            /**
             * Set protocol version
             * If exist replace it
             */
            void setProtoVersion(ProtoVersion* p_version)
                throw();

            /**
             * Get origin field
             *
             * @exception nettone::tools::Exception Thrown if not present because is mandatory
             */
            Origin* getOrigin()
                throw(nettone::tools::Exception);

            /**
             * Set origin field
             * If exist replace it
             */
            void setOrigin(Origin* p_orig)
                throw();

            /**
             * Get session
             *
             * @exception nettone::tools::Exception Thrown if not present because is mandatory
             */
            Session* getSession()
                throw(nettone::tools::Exception);

            /**
             * Set session
             * If exist replace it
             */
            void setSession(Session* p_session)
                throw();

            /**
             * Get information
             */
            Information* getInformation()
                throw();

            /**
             * Get connection
             */
            Connection* getConnection()
                throw();

            /**
             * Get Time
             *
             * @exception nettone::tools::Exception Thrown if not present because is mandatory
             */
            Time* getTime()
                throw(nettone::tools::Exception);

            /**
             * Set Time
             * If exist replace it
             */
            void setTime(Time* p_time)
                throw();

            /**
             * Get attributes
             */
            Attributes* getAttributes()
                throw();

            /**
             * get count of media
             */
            unsigned short mediaCount() const
                throw(nettone::tools::Exception);

            /**
             * Remove a media, codecs can be re-ordorer
             * @see std::vector::erase
             *
             * @param p_pos pos of media
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            void removeMedia(unsigned short p_pos)
                throw(nettone::tools::Exception);

            /**
             * Get a media
             *
             * @param p_pos pos of media
             *
             * @exception nettone::tools::Exception thrown if p_pos out of bound
             */
            Media* getMedia(unsigned short p_pos)
                throw(nettone::tools::Exception);

            /**
             * Add a codec to all medias, currently mostly used for adding DTMFs
             */
            void addCodecToAllMedia(const CodecInfo& p_codec)
                throw(nettone::tools::Exception);

            /**
             * Retreive the list of codec 'decoded' and managed by this SDP
             * Order is the same as in media(s)
             */
            const CodecsInfo& getCodecsInfo() const
                throw();

            /**
             * Create or update codecs info
             * Must always call after removing or adding codec
             */
            void updateCodecsInfo()
                throw(nettone::tools::Exception);

            /**
             * Retreive the list of audio codecs from CodecsInfo
             */
            nettone::codec::CodecsId getAudioCodecs() const
                throw();

            /// @name Compare operator
            /// @{
            bool operator==(const SDP& p_other) const;
            bool operator!=(const SDP& p_other) const;
            /// @}
            /**
             * Compare to an other SDP
             * Current SDP could have less codecs, but must have the same number of media
             * Attributes are not checked
             */
            bool like(const SDP& p_other) const
                throw();

        private:
            /// @name Forbidden methods
            /// @{
            SDP(const SDP& p_other);
            const SDP& operator =(const SDP& p_other);
            /// @}

            /**
             * Protocol Version
             */
            std::unique_ptr<ProtoVersion> m_protoVersion;

            /**
             * Origin field
             */
            std::unique_ptr<Origin> m_origin;

            /**
             * Session field
             */
            std::unique_ptr<Session> m_session;

            /**
             * Information field
             */
            std::unique_ptr<Information> m_information;

            /**
             * Connection field
             */
            std::unique_ptr<Connection> m_connection;

            /**
             * Time field
             */
            std::unique_ptr<Time> m_time;

            /**
             * Attributes
             */
            std::unique_ptr<Attributes> m_attributes;

            /**
             * Medias
             */
            std::vector<Media*> m_medias;

            /**
             * Codecs info for easyear management
             */
            CodecsInfo m_codecsInfo;
        };

        // Protocol version (v)
        //
        class ProtoVersion
        {
            friend class Deserializer;

        public:
            /**
             * Constructor.
             */
            ProtoVersion()
                throw();

            /**
             * Destructor.
             */
            ~ProtoVersion()
                throw();

            /**
             * Duplicate the proto version, caller is reponsible for destruction of duplicated object
             */
            ProtoVersion* clone()
                throw();

            /**
             * Get protocol version
             */
            unsigned short getVersion() const
                throw();

            /**
             * Set protocol version
             */
            void setVersion(const unsigned short p_ver)
                throw();

        private:
            /**
             * Protocol version
             */
            unsigned short m_version;
        };

        /**
         * Origin field (o)
         */
        class Origin
        {
            friend class Deserializer;

        public:
            /**
             * Constructor.
             */
            Origin()
                throw();

            /**
             * Destructor().
             */
            ~Origin()
                throw();

            /**
             * Duplicate the origin, caller is reponsible for destruction of duplicated object
             */
            Origin* clone()
                throw();

            /**
             * get Username
             */
            std::string getUsername() const
                throw();

            /**
             * set username
             */
            void setUsername(const std::string& p_username)
                throw();

            /**
             * get session id
             */
            std::string getSessionId() const
                throw();

            /**
             * set session id
             */
            void setSessionId(const std::string& p_id)
                throw();

            /**
             * get session version
             */
            std::string getSessionVersion() const
                throw();

            /**
             * set session version
             */
            void setSessionVersion(const std::string& p_ver)
                throw();

            /**
             * get network addr
             */
            std::string getAddr() const
                throw();

            /**
             * set network addr
             */
            void setAddr(const std::string& p_addr)
                throw();

        private:
            /**
             * Username
             */
            std::string m_username;

            /**
             * Session id
             */
            std::string m_sessionId;

            /**
             * Session Version
             */
            std::string m_sessionVersion;

            /*
             * Network Addr
             */
            std::string m_addr;
        };

        /**
         * Session name field (s)
         */
        class Session
        {
            friend class Deserializer;

        public:
            /**
             * Constructor.
             */
            Session()
                throw();

            /**
             * Destructor.
             */
            ~Session()
                throw();

            /**
             * Duplicate the session, caller is reponsible for destruction of duplicated object
             */
            Session* clone()
                throw();

            /**
             * Get the session name
             */
            std::string getName() const
                throw();

            /**
             * Set the session name
             */
            void setName(const std::string& p_name)
                throw();

        private:
            /**
             * Session name
             */
            std::string m_name;
        };

        /**
         * Information field (i)
         */
        class Information
        {
            friend class Deserializer;

        public:
            /**
             * Constructor.
             */
            Information()
                throw();

            /**
             * Destructor.
             */
            ~Information()
                throw();

            /**
             * Duplicate the information, caller is reponsible for destruction of duplicated object
             */
            Information* clone()
                throw();

            /**
             * Get the information
             */
            std::string getInfo() const
                throw();

        private:
            /**
             * Information
             */
            std::string m_info;
        };

        /**
         * Connection field (c)
         */
        class Connection
        {
            friend class Deserializer;

        public:
            /**
             * Constructor.
             */
            Connection()
                throw();

            /**
             * Destructor.
             */
            ~Connection()
                throw();

            /**
             * Duplicate the connection, caller is reponsible for destruction of duplicated object
             */
            Connection* clone()
                throw();

            /**
             * get connection addr
             */
            std::string getAddr() const
                throw();

            /**
             * set connection addr
             */
            void setAddr(const std::string& p_addr)
                throw();

            /// @name Compare operator
            /// @{
            bool operator==(const Connection& p_other) const;
            bool operator!=(const Connection& p_other) const;
            /// @}

        private:
            /**
             * Connection addr
             */
            std::string m_addr;
        };

        /**
         * Time field (t)
         */
        class Time
        {
            friend class Deserializer;

        public:
            /**
             * Constructor.
             */
            Time()
                throw();

            /**
             * Destructor.
             */
            ~Time()
                throw();

            /**
             * Duplicate the time, caller is reponsible for destruction of duplicated object
             */
            Time* clone()
                throw();

            /**
             * get start time
             */
            unsigned long getStart() const
                throw();

            /**
             * Set start time
             */
            void setStart(const unsigned long p_date)
                throw();

            /**
             * get stop time
             */
            unsigned long getStop() const
                throw();

            /**
             * Set stop time
             */
            void setStop(const unsigned long p_date)
                throw();

        private:
            /**
             * Start time
             */
            unsigned long m_start;

            /**
             * Stop time
             */
            unsigned long m_stop;
        };

        /**
         * List of attributes
         */
        class Attributes
        {
            friend class Deserializer;

        public:
            /**
             * Constructor
             */
            Attributes()
                throw ();

            /**
             * Destructor
             */
            ~Attributes()
                throw();

            /**
             * Duplicate the attributes, caller is reponsible for destruction of duplicated object
             */
            Attributes* clone()
                throw();

            /**
             * Get Ptime
             */
            AttrPTime* getPTime()
                throw();

            /**
             * Set Ptime
             */
            void setPTime(AttrPTime* p_ptime)
                throw();

            /**
             * get count of codec
             */
            unsigned short codecCount() const
                throw();

            /**
             * Remove a codec, all codec are re-ordorer
             *
             * @param p_pos pos of codec
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            void removeCodec(unsigned short p_pos)
                throw(nettone::tools::Exception);

            /**
             * Get a codec
             *
             * @param p_pos pos of codec
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            AttrCodec* getCodec(unsigned short p_pos)
                throw(nettone::tools::Exception);

            /**
             * Add a codec
             *
             * @param p_codec codec to add
             */
            void addCodec(AttrCodec& p_codec)
                throw();

            /**
             * Get CnxMode
             */
            AttrCnxMode* getCnxMode()
                throw();

            /**
             * Set CnxMode
             */
            void setCnxMode(AttrCnxMode* p_cnxMode)
                throw();

            /**
             * get count of otherAttributes
             */
            unsigned short otherAttributesCount() const
                throw();

            /**
             * Remove a otherAttributes, all otherAttributes are re-ordorer
             *
             * @param p_pos pos of otherAttributes
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            void removeOtherAttributes(unsigned short p_pos)
                throw(nettone::tools::Exception);

            void removeOtherAttributesNotStartingBy(const std::string p_prefix);

            /**
             * Get a otherAttributes
             *
             * @param p_pos pos of otherAttributes
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            std::pair<std::string, std::string> getOtherAttributes(unsigned short p_pos) const
                throw(nettone::tools::Exception);

            /**
             * Add an new attributes, all otherAttributes are re-ordorer
             */
            void addOtherAttributes(const std::string& p_attr,
                                    const std::string& p_value)
                throw(nettone::tools::Exception);

            /// @name Compare operator
            /// @{
            bool operator==(const Attributes& p_other) const;
            bool operator!=(const Attributes& p_other) const;
            /// @}

        private:
            /// @name Forbidden methods
            /// @{
            Attributes(const Attributes& p_other);
            const Attributes& operator =(const Attributes& p_other);
            /// @}

            /**
             * Packet time
             */
            std::unique_ptr<AttrPTime> m_ptime;

            /**
             * Codecs
             */
            std::vector<AttrCodec*> m_codecs;

            /**
             * Connection Mode
             */
            std::unique_ptr<AttrCnxMode> m_cnxMode;

            /**
             * @var Unkowns m_unknows
             * Unknow attributes
             */
            typedef std::vector<std::pair<std::string, std::string> > Unknows;
            Unknows m_unknows;
        };

        /**
         * Ptime attribute
         */
        class AttrPTime
        {
            friend class Deserializer;
        public:
            /**
             * Constructor.
             */
            AttrPTime()
                throw();

            /**
             * Construct and set ptime.
             */
            AttrPTime(const unsigned short p_packetTime)
                throw();

            /**
             * Destructor.
             */
            ~AttrPTime()
                throw();

            /**
             * Duplicate the ptime, caller is reponsible for destruction of duplicated object
             */
            AttrPTime* clone()
                throw();

            /**
             * Get length of packet in milliseconds
             */
            unsigned short getPacketTime() const
                throw();

            /// @name Compare operator
            /// @{
            bool operator==(const AttrPTime& p_other) const;
            bool operator!=(const AttrPTime& p_other) const;
            /// @}

        private:
            /**
             * Length of packet in milliseconds
             */
            unsigned short m_packetTime;
        };

        /**
         * Connecxion mode
         */
        class AttrCnxMode
        {
            friend class Deserializer;
        public:
            enum ModeType {
                e_mtRecvOnly,
                e_mtSendRecv,
                e_mtSendOnly,
                e_mtInactive
            };

            /**
             * Constructor.
             */
            AttrCnxMode()
                throw();

            /**
             * Destructor.
             */
            ~AttrCnxMode()
                throw();

            /**
             * Duplicate the CnxMode, caller is reponsible for destruction of duplicated object
             */
            AttrCnxMode* clone()
                throw();

            /**
             * Get connection mode
             */
            ModeType getMode() const
                throw();

            /**
             * Set connection mode
             */
            void setMode(ModeType p_mode)
                throw();

            /// @name Compare operator
            /// @{
            bool operator==(const AttrCnxMode& p_other) const;
            bool operator!=(const AttrCnxMode& p_other) const;
            /// @}

        private:
            /**
             * Connection mode
             */
            ModeType m_mode;
        };

        /**
         * Codec representation
         */
        class AttrCodec
        {
            friend class Deserializer;
        public:
            /**
             * Constructor.
             */
            AttrCodec()
                throw();

            /**
             * Destructor.
             */
            ~AttrCodec()
                throw();

            /**
             * Duplicate the codec, caller is reponsible for destruction of duplicated object
             */
            AttrCodec* clone()
                throw();

            /**
             * Get the codec, if fully decoded
             */
            nettone::codec::CodecId getCodec()
                throw();

            /**
             * Set the codec
             */
            void setCodec(const nettone::codec::CodecId p_codec) // (see enum in nettone_codec_identifiers.h)
                throw();

            /**
             * Get the payload value
             */
            unsigned short getPayload() const
                throw();

            /**
             * Set the payload value
             */
            void setPayload(const unsigned short p_payload)
                throw();

            /**
             * Get codec name
             */
            std::string getName() const
                throw();

            /**
             * Set codec name
             */
            void setName(const std::string& p_name)
                throw();

            /**
             * Get clock rate
             */
            unsigned long getClockRate() const
                throw();

            /**
             * Set clock rate
             */
            void setClockRate(const unsigned long p_rate)
                throw();

            void setEncodingParameters(const std::string& p_encodingParameters);

            /**
             * Get codec encodingParameters
             */
            std::string getEncodingParameters() const
                throw();

            /// @name Compare operator
            /// @{
            bool operator==(const AttrCodec& p_other) const;
            bool operator!=(const AttrCodec& p_other) const;
            /// @}

        private:
            /**
             * The codec
             */
            nettone::codec::CodecId m_codec; // (see enum in nettone_codec_identifiers.h)

            /**
             * Payload value for codec
             */
            unsigned short m_payload;

            /**
             * Codec name
             */
            std::string m_name;

            /**
             * Clock rate
             */
            unsigned long m_clockRate;

            /**
             * Encoding parameters
             */
            std::string m_encodingParameters;
        };

        /**
         * Media description
         */
        class Media
        {
            friend class Deserializer;
        public:
            /**
             * Kind of media
             */
            enum MediaType {
                e_mtAudio,
                e_mtVideo,
                e_mtText,
                e_mtApplication,
                e_mtMessage,
                e_mtImage
            };

            /**
             * Transport Protocol
             */
            enum TransportProtocol {
                e_tpRtpAvp,
                e_tpRtpSavp,
                e_tpUdp,
                e_tpUdpTL
            };

            /**
             * Codec who was not a number
             */
            enum NotNumericCodec {
                e_nncT38 = -1
            };

            /**
             * Constructor
             */
            Media()
                throw ();

            /**
             * Destructor
             */
            ~Media()
                throw();

            /**
             * Duplicate the media, caller is reponsible for destruction of duplicated object
             */
            Media* clone()
                throw();

            /**
             * Get media type
             */
            MediaType getMediaType() const
                throw();

            /**
             * Get port value
             */
            unsigned long getPort() const
                throw();

            /**
             * Set port value
             */
            void setPort(const unsigned long p_port)
                throw();

            /**
             * Get number of ports
             */
            unsigned short getNbPorts() const
                throw();

            /**
             * Set number of ports
             */
            void setNbPorts(const unsigned short p_nbPorts)
                throw();

            /**
             * Get the transport protocol used
             */
            TransportProtocol getTransportProtocol() const
                throw();

            /**
             * Get Information
             */
            Information* getInformation()
                throw();

            /**
             * Get Connection
             */
            Connection* getConnection()
                throw();

            /**
             * Get Attributes
             */
            Attributes* getAttributes(bool p_initIfNotPresent = false)
                throw();

            /**
             * get count of codecs
             */
            unsigned short codecCount() const
                throw(nettone::tools::Exception);

            /**
             * Reorder codec
             */
            void reorderCodec(const std::vector<long>& p_codecs,
                              const bool p_removeMissing = true)
                throw(nettone::tools::Exception);

            /**
             * Remove a codecs, codecs can be re-ordorer
             * @see std::vector::erase
             *
             * @param p_pos pos of codecs
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            void removeCodec(unsigned short p_pos)
                throw(nettone::tools::Exception);

            /**
             * Add a codec at the end of the list
             */
            void addCodec(long p_id)
                throw();

            /**
             * Get a codecs
             *
             * @param p_pos pos of codecs
             *
             * @exception nettone::tools::Exception Thrown if p_pos out of bound
             */
            long getCodec(unsigned short p_pos) const
                throw(nettone::tools::Exception);

            /// @name Compare operator
            /// @{
            bool operator==(const Media& p_other) const;
            bool operator!=(const Media& p_other) const;
            /// @}
            /**
             * Compare to an other media
             * Current SDP could have less codecs
             * attributes are not checked
             */
            bool like(const Media& p_other) const
                throw();

        private:
            /// @name Forbidden methods
            /// @{
            Media(const Media& p_other);
            const Media& operator =(const Media& p_other);
            /// @}

            /**
             * Information field
             */
            std::unique_ptr<Information> m_information;

            /**
             * Connection field
             */
            std::unique_ptr<Connection> m_connection;

            /**
             * Attributes
             */
            std::unique_ptr<Attributes> m_attributes;

            /**
             * Media type
             */
            MediaType m_mediaType;

            /**
             * Port number
             */
            unsigned long m_port;

            /**
             * Number of ports
             */
            unsigned short m_nbPorts;

            /**
             * Used transport protocol
             */
            TransportProtocol m_tranportProtocol;

            /**
             * List of codecs
             */
            std::vector<long> m_codecs;
        };
    }
}

