#ifndef __NETTONE_CRYPTO_X509_H__
#define __NETTONE_CRYPTO_X509_H__


#include <openssl/x509.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		class PKCS7Verify;

		/**
		 * Toolkit class to handle X509 certificate
		 * See http://www.openbsd.org/cgi-bin/man.cgi?query=ssl&sektion=8&arch=i386&apropos=0&manpath=OpenBSD+Current
		 */
		class X509
		{
			friend class PKCS7Verify;
		public:
			/**
			 * Constructor.
			 */
			X509(const char* p_data,
				 const unsigned long p_length)
				throw(nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			~X509()
				throw();
			
		private:
			/// @name Forbidden methods
			/// @{
			X509(const X509& p_other);
			const X509& operator =(const X509& p_other);
			/// @}

			::X509* m_x509;

		};
	}
}


#endif // __NETTONE_CRYPTO_X509_H__
