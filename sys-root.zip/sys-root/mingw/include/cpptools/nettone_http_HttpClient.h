#ifndef __NETTONE_HTTP_HTTPCLIENT_H__
#define __NETTONE_HTTP_HTTPCLIENT_H__


#include <map>
#include <memory>
#include <string.h>

#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
    namespace http
    {
        class HttpClient
        {
        public:
            typedef std::map<std::string, std::string> StringMap;

            /**
             * Init Curl, must done only one time
             */
            static void globalInit()
                throw();

             /**
             * Cleanup Curl, must done only one time
             */
            static void globalCleanup()
                throw();

            /**
             * Open url
             *
             * @param p_headers			Headers of the get answer
             * @param p_data                    Data for post message, empty for get request
             * @param p_body			Body of the get answer
             * @param p_url			Url to retreive
             * @param p_timeOut_ms		Timeout for request
             * @param p_ignoreCertificate       In case of http ignore certificate
             * @param p_login                   Login
             * @param p_password                Password
             */
            static void openUrl(const std::string& p_url,
                                const std::string& p_data,
                                const unsigned long p_timeOut_ms,
                                const bool p_ignoreCertificate,
                                const StringMap& p_headers,
                                const std::string& p_login,
                                const std::string& p_password,
                                std::string& p_body)
                throw (nettone::tools::Exception);

            /**
             * Open url
             *
             * @param p_headers			Headers of the get answer
             * @param p_body			Body of the get answer
             * @param p_url			Url to retreive
             * @param p_timeOut_ms		Timeout for request
             */
            static void openUrl(const std::string& p_url,
                                const unsigned long p_timeOut_ms,
                                const StringMap& p_headers,
                                std::string& p_body)
                throw (nettone::tools::Exception);
        };
    }
}


#endif // __NETTONE_HTTP_HTTPCLIENT_H__
