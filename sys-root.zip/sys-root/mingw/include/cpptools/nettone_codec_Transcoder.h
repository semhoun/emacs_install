#ifndef __KERTEL_RECORDING_TRANSCODER_FLAG__
#define __KERTEL_RECORDING_TRANSCODER_FLAG__


// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <arpa/inet.h>
#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_G711.h"
#include "nettone_codec_G722.h"
#include "nettone_codec_G729.h"
#include "nettone_codec_GSM.h"
#include "nettone_codec_ILBC.h"
#include "nettone_codec_Mp3.h"
#include "nettone_codec_OPUS.h"

// RTP.header = 12 bytes
// ----------------------
//   |
//	 |--RTP.CompressedBody.G729		
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: 10 bytes  ; 10 to 230 in multiples of 10	
//	 |		|		|-- uncompressed frame	: 80 * sizeof(int16_t)
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 20 bytes  ; 10 to 230 in multiples of 10	
//	 |				|-- uncompressed frame	: 80 * 2 * sizeof(int16_t)  
//	 |	
//	 |--RTP.CompressedBody.G711_A / G711_U
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: 80 bytes
//	 |		|		|-- uncompressed frame	: 80 * sizeof(int16_t)
//	 |		|	
//	 |		|--- 20 Msec :	
//	 |				|-- compressed frame	: 160 bytes
//	 |				|-- uncompressed frame	: 160 * sizeof(int16_t)
//   |
//	 |--RTP.CompressedBody.G722_64	
//	 |		|--- 10 Msec : 
//	 |		|		|-- compressed frame	: 80 bytes
//	 |		|		|-- uncompressed frame	: 80 * sizeof(int16_t) 
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 160 bytes 
//	 |				|-- uncompressed frame	: 160 * sizeof(int16_t) 
//   |
//   |--RTP.CompressedBody.ILBC		
//	 |		|--- 10 Msec : 
//	 |		|		|-- compressed frame	: <NONE> ; does not exist
//	 |		|		|-- uncompressed frame	: <NONE> ; does not exist
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 38 bytes 
//	 |				|-- uncompressed frame	: 160 * sizeof(int16_t)
//	 |			
//	 |--RTP.CompressedBody.ILBC_13	
//	 |		|--- 10 Msec : 
//	 |		|		|-- compressed frame	: <NONE> ; does not exist
//	 |		|		|-- uncompressed frame	: <NONE> ; does not exist
//	 |		|
//	 |		|--- 20 Msec : 
//	 |		|		|-- compressed frame	: <NONE> ; does not exist
//	 |		|		|-- uncompressed frame	: <NONE> ; does not exist
//	 |		|
//	 |		|--- 30 Msec :
//	 |				|-- compressed frame	: 50 bytes 
//	 |				|-- uncompressed frame	: 240 * sizeof(int16_t)
//
//=================================================================================================================

//=================================================================================================================
// Max PCM destination frame size per codec (in int16, and in PCM)
//=================================================================================================================
// G711		: 2400 int16						=> 4800 bytes max for PCM decoded buffer
// G722_64	: 3200 int16						=> 6400 bytes max for PCM decoded buffer
// G729		: 1600 int16						=> 3200 bytes max for PCM decoded buffer
// ILBC 	: 4800 int16 						=> 9600 bytes max for PCM decoded buffer
// GSM		: 2560 int16 						=> 5120 bytes max for PCM decoded buffer
// OPUS		: (5760 * 2)  int16 => 11520 int16 	=> 23040 bytes for PCM decoded buffer
//=================================================================================================================

//==========================================================
// Conversion from PCM to XXX - max destination buffer size 
//==========================================================
// PCM to G711 		: 2400 max bytes necessary
// PCM to G722_64	: 800  max bytes necessary 
// PCM to G729 		: 200  max bytes necessary
// PCM to ILBC		: 1000 max bytes necessary
// PCM to GSM		: 530  max bytes necessary
// PCM to OPUS		: 3000 max bytes necessary
//==========================================================

namespace nettone {
	namespace codec {

		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// @@ Constants
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		const uint32_t	RECORDING_TRANSCODER_SEQUENCE_NUMBER_OFFSET_IN_RTP_PACKET			= 2;
		const uint32_t	RECORDING_TRANSCODER_TIMESTAMP_OFFSET_IN_RTP_PACKET = 4;
		const int32_t RECORDING_TRANSCODER_PCM_BUFFER_MAX_SIZE_IN_INT16		= 16000; // OPUS requires 11520
		const int32_t RECORDING_TRANSCODER_CODEC_BUFFER_MAX_SIZE_IN_INT8	= 4096;  // OPUS requires 3000

		bool IsHandledRtpPayloadType			(uint8_t p_RtpPayloadType) throw ();

		// the following codecs are not compatible with a real time transcoding:
		// - e_cG722_48: Reason: algorithm does not work in this mode (only work in e_cG722_64 mode)
		// - e_cG722_56: Reason: algorithm does not work in this mode (only work in e_cG722_64 mode) 
		// - e_ciLBC_13: Reason: sampling frequency is 30 Msec, incompatible with all others that are sampled every 20 Msec
		bool IsCompatibleRtpRealTimePayloadType		(uint8_t p_RtpPayloadType) throw ();
		bool UpgradePcmBufferFromOneToTwoChannels	(int16_t * p_OneChannelsBuffer, uint32_t p_OneChannelsBufferSizeInInt16, int16_t * p_TwoChannelsBuffer, uint32_t p_TwoChannelsBufferSizeInInt16, uint32_t& p_TrueSizeInInt16);
		bool DowngradePcmBufferFromTwoToOneChannels (int16_t * p_TwoChannelsBuffer, uint32_t p_TwoChannelsBufferSizeInInt16, int16_t * p_OneChannelsBuffer, uint32_t p_OneChannelsBufferSizeInInt16, uint32_t& p_TrueSizeInInt16);


		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// @@ Objects
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

		class CRecordingTranscoder
		{
		private:
			CRecordingTranscoder				(const CRecordingTranscoder&) throw ();		// forbid copy
			CRecordingTranscoder& operator=		(const CRecordingTranscoder&) throw ();		// forbid copy
			int32_t ConvertBufferFromPCMToYYY	(int32_t p_DestCodec, int16_t * p_EncodedData, uint32_t p_EncodedDataLenInInt16, uint8_t * p_DecodedData, uint32_t p_DecodedBufferSizeInByte, uint32_t& p_TrueDecodedDataLenInByte, bool p_StopAfterPcmConversion) throw ();
			int32_t ConvertBufferFromXXXToPCM	(int32_t p_SourceCodec, uint8_t * p_EncodedData, uint32_t p_EncodedDataLenInByte, int16_t * p_DecodedData, uint32_t	p_DecodedBufferSizeInInt16, uint32_t& p_DecodedDataLenInInt16) throw ();

			bool				m_TranscodingInProgress;
			int16_t				m_PcmBuffer[RECORDING_TRANSCODER_PCM_BUFFER_MAX_SIZE_IN_INT16];
			CConverterG729ToPcm	m_ConverterG729ToPcm;
			CConverterPcmToG729	m_ConverterPcmToG729;

			CConverterG711ToPcm	m_ConverterG711ToPcm;
			CConverterPcmToG711	m_ConverterPcmToG711;

			CConverterG722ToPcm	m_ConverterG722ToPcm;
			CConverterPcmToG722	m_ConverterPcmToG722;

			CConverterGSMToPcm	m_ConverterGSMToPcm;
			CConverterPcmToGSM	m_ConverterPcmToGSM;

			CConverterILBCToPcm	m_ConverterILBCToPcm;
			CConverterPcmToILBC	m_ConverterPcmToILBC;

			CConverterILBCToPcm	m_ConverterILBC13ToPcm;
			CConverterPcmToILBC	m_ConverterPcmToILBC13;

			// *** Warning: Since Opus is a stateful codec, the encoding process starts with creating an encoder
			// state. An encoder state must not be used for more than one stream at the same time. 
			// Similarly, the encoder state must not be re-initialized for each frame.
			// ( the function 'opus_encoder_create' allocates memory for the state)
			//
			// Opus is a stateful codec with overlapping blocks and as a result Opus
			// packets are not coded independently of each other. Packets must be
			// passed into the decoder serially and in the correct order for a correct
			// decode. Lost packets can be replaced with loss concealment by calling
			// the decoder with a null pointer and zero length for the missing packet.

			CConverterOPUSToPcm	m_ConverterOPUSToPcm;
			CConverterPcmToOPUS m_ConverterPcmToOPUS;
			uint8_t				m_OpusNormalizedRtpPayloadType; // because Opus RTP payload type changes everytime (dynamic allocation)

		public:
			CRecordingTranscoder () throw ();
			void	Reset () throw ();
			void	BeginTranscoding						(int32_t& p_Iret, uint8_t p_SrcRtpPayloadType, uint8_t p_DestRtpPayloadType) throw ();
			void	FullTranscodingBegin					(int32_t& p_Iret); // Full mode: all possible transcoders will be initialized

			// p_From: just a string permitting to know the caller
			// p_SourceCodec: chosen out of {e_cPCMU, e_cGSM, e_cPCMA, etc...}, see nettone_codec_identifiers.h
			// p_DestCodec	: chosen out of {e_cPCMU, e_cGSM, e_cPCMA, etc...}, see nettone_codec_identifiers.h
			int32_t TranscodeBufferFromXXXToYYY				(const char * p_From, int32_t p_SourceCodec, int32_t p_DestCodec, uint8_t * p_EncodedData, uint32_t p_EncodedDataLenInByte, uint8_t * p_DecodedData, uint32_t p_DecodedBufferSizeInByte, uint32_t& p_TrueDecodedDataLenInByte, bool p_StopAfterPcmConversion = false) throw ();

			void	EndTranscoding							(int32_t& p_Iret, const char * p_From) throw ();
			void	UpdateOpusRtpPayloadType				(uint8_t i_OpusRtpPayloadType); // needed because Opus RTP payload type is dynamic.
			uint8_t GetOpusRtpPayloadType					();
		};


		// Patch both the RTP header & RTP payload to reflect the new content
		class CRtpTranscoder
		{
		private:
			CRtpTranscoder					(const CRtpTranscoder&) throw ();		// forbid copy
			CRtpTranscoder& operator=		(const CRtpTranscoder&) throw ();		// forbid copy
			int32_t GetRtpPayloadType		(uint8_t * p_RtpPacket, uint32_t p_RtpSize, uint8_t& p_ExtractedRtpPayloadType) throw ();
			bool	IsRtpPacketCodecTypeXXX (uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize, uint8_t p_ExpectedRtpPayloadType) throw ();

			bool					m_TranscodingInProgress;
			CRecordingTranscoder	m_RecordingTranscoder;
			uint8_t					m_OpusNormalizedRtpPayloadType; // because Opus RTP payload type changes everytime (dynamic allocation)
			uint32_t				m_NbOpusToXXXDone; // needed to convert timestampt from +960 to +160

		public:
			CRtpTranscoder							() throw ();
			void	BeginTranscoding				(int32_t& p_Iret, uint8_t p_SrcRtpPayloadType, uint8_t p_DestRtpPayloadType) throw ();
			void	FullTranscodingBegin			(int32_t& p_Iret); // Full mode: all possible transcoders will be initialized

			bool	IsRtpPacketG711Alaw				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketG711Ulaw				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketG722_XXX				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketG722_48				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketG722_56				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketG722_64				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketG729					(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketGSM					(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketIlbc					(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketIlbc_13				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketIlbc_XXX				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketOPUS					(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();
			bool	IsRtpPacketOpus					(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize) throw ();

			// p_SrcRtpPacket: the RTP packet composed of Header + Payload
			// p_SrcRtpSize	 : the size of the full RTP packet (header + payload)
			// p_DestPayloadType: chosen out of {e_cPCMU, e_cGSM, e_cPCMA, etc...}, see nettone_codec_identifiers.h
			// 
			// p_NeedTranscodingResult: becomes true if the packet 'p_SrcRtpPacket' need to be transcoded to become a 'p_DestPayloadType' RTP packet
			int32_t NeedTranscoding					(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize, uint8_t p_DestPayloadType, bool& p_NeedTranscodingResult) throw ();
			int32_t NeedTranscoding					(uint8_t p_SourcePayloadType, uint8_t p_DestPayloadType, bool& p_NeedTranscodingResult) throw ();

			// p_SrcRtpPacket	: the RTP packet to transcode to type 'p_DestPayloadType' (composed of Header + Payload)
			// p_SrcRtpSize		: the size of the full RTP packet to transcode (header + payload)
			// p_DestPayloadType: chosen out of {e_cPCMU, e_cGSM, e_cPCMA, etc...}, see nettone_codec_identifiers.h
			// p_DstRtpPacket	: the RTP packet that result from the conversion
			// p_DstRtpMaxSize	: the maximum size of the fully converted RTP packet (in byte)
			// p_DstRtpTrueSize	: filled with the actual size of the converted RTP packet
			int32_t TranscodeRtpPacket				(uint8_t * p_SrcRtpPacket, uint32_t p_SrcRtpSize, uint8_t p_DestPayloadType, uint8_t * p_DstRtpPacket, uint32_t p_DstRtpMaxSizeInByte, uint32_t& p_DstRtpTrueSizeInByte, bool p_StopAfterPcmConversion=false) throw();

			void	EndTranscoding					(int32_t& p_Iret, const char * p_From) throw ();
			bool	IsTranscoderStarted				() throw ();
			void	UpdateOpusRtpPayloadType		(uint8_t i_OpusRtpPayloadType); // needed because Opus RTP payload type is dynamic.
			uint8_t GetOpusRtpPayloadType			();
		};

	}// namespace codec
} // namespace nettone

#endif // __KERTEL_RECORDING_TRANSCODER_FLAG__