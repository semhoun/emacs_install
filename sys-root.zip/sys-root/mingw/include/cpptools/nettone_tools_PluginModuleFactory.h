#ifndef __NETTONE_TOOLS_PLUGINMODULEFACTORY_H__
#define __NETTONE_TOOLS_PLUGINMODULEFACTORY_H__


#include "cpptools/nettone_tools_IModuleFactory.h"


namespace nettone
{
	namespace tools
	{
		class PluginModuleFactory
			: public IModuleFactory
		{
		public:
			PluginModuleFactory();
			
			virtual IModule* buildModule(const ModuleDesc& p_desc);
			
		private:
			PluginModuleFactory(const PluginModuleFactory& p_other);
			const PluginModuleFactory& operator =(const PluginModuleFactory& p_other);
		};
	}
}


#endif // __NETTONE_TOOLS_PLUGINMODULEFACTORY_H__
