#ifndef __NETTONE_DEBUG_TOOLS_H__
#define	__NETTONE_DEBUG_TOOLS_H__


#include <log4cxx/logger.h>


namespace nettone
{
    namespace debug
    {
        class Tools
        {
        public:
            static void crash(log4cxx::LoggerPtr& p_log,
            				  const char* p_why);

            static void crash(log4cxx::LoggerPtr& p_log,
                              const std::string& p_why);

        private:
            /// @name Forbidden method(s)
            /// @{
            Tools(Tools const&);
            Tools const& operator =(Tools const&);
            /// @}
        };
    }
}


#endif	// __NETTONE_DEBUG_TOOLS_H__

