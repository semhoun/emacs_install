#ifndef __NETTONE_TOOLS_FSMCLASS_I_H__
#define __NETTONE_TOOLS_FSMCLASS_I_H__


namespace nettone
{
	namespace tools
	{
		template <typename T, typename STATE, typename EVENT>
		FSMClass<T, STATE, EVENT>::FSMClass(const STATE& p_state)
			: nettone::tools::FSM<SHandler<T>, STATE, EVENT, SDefaultHandler<FSMClass<T, STATE, EVENT>, STATE, EVENT> >(p_state, makeFSMDefaultHandler(this, &FSMClass<T, STATE, EVENT>::defaultTransitionHandler))
		{
		}

		template <typename T, typename STATE, typename EVENT>
		void FSMClass<T, STATE, EVENT>::defaultTransitionHandler(const STATE& p_state,
																 const EVENT& p_event,
																 void* const& p_data)
		{
		}

		template <typename T, typename STATE, typename EVENT>
		void FSMClass<T, STATE, EVENT>::registerMyFSMHook(const STATE& p_state,
														  const EVENT& p_event,
														  void (T::* p_handler)(void* const& p_data),
														  const STATE& p_nextState,
														  const bool p_final)
		{
			this->registerHook(p_state, p_event, makeFSMHandler(reinterpret_cast<T*>(this), p_handler), p_nextState, p_final);
		}
	}
}


#endif // __NETTONE_TOOLS_FSMCLASS_I_H__
