#ifndef __NETTONE_CRYPTO_PKCS7VERIFY_H__
#define __NETTONE_CRYPTO_PKCS7VERIFY_H__


#include <openssl/ssl.h>
#include <openssl/pkcs7.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		class X509;
		class PKCS7;

		/**
		 * Toolkit class to verify PKCS7
		 * Actually bugged NOT USED
		 */
		class PKCS7Verify
		{
		public:
			/**
			 * Constructor.
			 */
			PKCS7Verify()
				throw(nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			~PKCS7Verify()
				throw();
			
			void addCertificate(const X509* p_cert)
				throw(nettone::tools::Exception);

			void addTrustedCertificate(const X509* p_cert)
				throw(nettone::tools::Exception);

			bool verifyPKCS7(const PKCS7* p_pkcs7)
				throw(nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			PKCS7Verify(const PKCS7Verify& p_other);
			const PKCS7Verify& operator =(const PKCS7Verify& p_other);
			/// @}

			SSL_CTX* m_context;
			STACK_OF(X509) *m_certs;
			X509_STORE *m_store;
		};
	}
}


#endif // __NETTONE_CRYPTO_X509_H__
