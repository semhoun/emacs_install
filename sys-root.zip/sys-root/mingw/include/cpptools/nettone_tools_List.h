#ifndef __nettone_tools_List_h__
#define __nettone_tools_List_h__


#include <vector>


namespace nettone
{
	namespace tools
	{
		class Exception;

		/**
		 * 
		 */
		template <typename T>
		class List
		{
		public:
			/**
			 * Constructor.
			 */
			List(const unsigned long p_nbSlots) throw (Exception);

			/**
			 * Destructor.
			 */
			~List();

			/**
			 * Add an element at the end of the list.
			 * 
			 * @param p_element The element to copy in the list.
			 */
			void addTail(const T p_element) throw (Exception);

			/**
			 * Remove the leading element of the list.
			 */
			void delHead() throw (Exception);

			/**
			 * Get the size of the list.
			 */
			unsigned long size() const throw ();

			/**
			 * Get the head of the list.
			 *
			 * @return A copy of the first element of the list.
			 */
			T getHead() throw (Exception);

		private:
			/// @name Forbidden methods.
			/// @{
			List(const List<T>& p_other);
			const List<T>& operator =(const List<T>& p_other);
			/// @}

			T* m_slots;

			long* m_usedList;
			long m_usedListHead;
			long m_usedListTail;

			long* m_freeList;
			long m_freeListHead;

			unsigned long m_elementsCount;
		};
	}
}


#include "nettone_tools_List.ih"


#endif // __nettone_tools_List_h__
