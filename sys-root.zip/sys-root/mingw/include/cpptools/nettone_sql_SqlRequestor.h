#ifndef __NETTONE_SQL_SQLREQUESTOR_H__
#define __NETTONE_SQL_SQLREQUESTOR_H__


#include <vector>
#include <map>
#include <list>
#include <mysql/mysql.h>
#include <memory>

#include "nettone_tools_Mutex.h"


namespace nettone
{
	namespace sql
	{
		/**
		 * Access to the databse and execute SQL queries.
		 */
		class SqlRequestor
		{
		public:
			class ResultCell;
			class ResultRow;
			class Result;

			/**
			 * A set of structures Result used to store results of multi-queries.
			 */
			typedef std::vector<Result*> ResultSet;

			/**
			 * Stock the result of 1 SQL query.
			 */
			class Result
			{
			public:
				// ResultCell can access to retrieveCellContent
				friend class ResultCell;
				
				/**
				 * Const_Iterator to a row in the result table.
				 */
				class const_iterator
				{
				public:
					/** 
					 * Constructor.
					 */
					const_iterator(const Result* const p_result,
								   const unsigned long p_offset)
						throw ();

					/** 
					 * Constructor.
					 */
					const_iterator (const const_iterator& p_other)
						throw ();

					/** 
					 * Destructor.
					 */
					~const_iterator()
						throw ();
					
					/**
					 * Operator =.
					 */
					const const_iterator& operator =(const const_iterator& p_other)
						throw ();

					/** 
					 * Prefix ++ operator.
					 */
					const_iterator& operator ++()
						throw (nettone::tools::Exception);

					/**
					 * Postfix ++ operator.
					 */
					const_iterator operator ++(int)
						throw (nettone::tools::Exception);

					/**
					 * Operator *.
					 */
					const ResultRow& operator *() const
						throw ();

					/**
					 * Operator ->.
					 */
					const ResultRow* operator ->() const
						throw ();

					/**
					 * Operator ==.
					 */
					bool operator ==(const_iterator p_other) const
						throw ();

					/**
					 * Operator !=.
					 */
					bool operator !=(const_iterator p_other) const
						throw ();

				private:
					/**
					 * Pointer to the result table on which this const_iterator iterates
					 */
					const Result* const m_result;

					/**
					 * Temporarily row used in operators * and ->.
					 */
					mutable ResultRow* m_row;
					
					/**
					 * Offset of this current row in the result table.
					 */
					unsigned long m_offset;
				}; // End of class Result::const_iterator.

				/** 
				 * Constructor.
				 */
				Result()
					throw ();

				/** 
				 * Destructor.
				 */
				~Result()
					throw ();

				/** 
				 * Set the content of the Result struct.
				 * 
				 * @param m_sock Pointer to the MYSQL object which contains the result of SQL queries.
				 */
				void setContent(MYSQL* const p_sock)
					throw (nettone::tools::Exception);

				/** 
				 * Move to the first rows in result table.
				 * 
				 * @return const_iterator to the first row.
				 */
				const_iterator begin() const
					throw ();
				
				/** 
				 * Move to the last rows in result table.
				 * 
				 * @return const_iterator to the last row.
				 */
				const_iterator end() const
					throw ();

				/** 
				 * Size of the result table, in number of rows.
				 * 
				 * @return number of rows of result table.
				 */
				unsigned long size() const
					throw ();
 
				/**
				 * Operator [].
				 */
				const_iterator operator [](const unsigned long p_at) const
					throw (nettone::tools::Exception);

				/** 
				 * Get the number of rows in result table.
				 * 
				 * @return number of rows of result table.
				 */
				unsigned long getRowsCount() const
					throw ();
				
				/** 
				 * Get the number of column in result table.
				 * 
				 * @return number of column of result table.
				 */
				unsigned long getFieldsCount() const
					throw ();

				/** 
				 * Get the number of affected rows after the query.
				 * 
				 * @return number of affected rows, number of row selected if SELECT query.
				 */
				unsigned long getAffectedRowsCount() const
					throw ();

			private:
				/// @name Forbidden methods
				/// @{
				Result (const Result& p_other);
				const Result& operator =(const Result& p_other);
				/// @}	

				/** 
				 * Looking for the content of a cell and store it.
				 * 
				 * @param p_cell The cell to retrieve content.
				 */
 				void retrieveCellContent(const ResultCell* const p_cell) const
 					throw (nettone::tools::Exception);

				/**
				 * MySQL result.
				 */
				MYSQL_RES* m_result;
				
				/**
				 * Number of rows.
				 */
				unsigned long m_numRows;
				
				/**
				 * Number of columns.
				 */
				unsigned long m_numFields;
				
				/**
				 * Number of affected rows.
				 */
				unsigned long m_numAffectedRows;

				/**
				 * Stock the rows recently retrieved
				 */
				mutable std::map<const unsigned long, std::pair<MYSQL_ROW, std::vector<unsigned long> > > m_cache;
			};

			/**
			 * A row in the result table.
			 */
			class ResultRow
			{
			public:
				/**
				 * Const_Iterator to a cell in the row.
				 */
				class const_iterator
				{
				public:
					/**
					 * Constructor.
					 */
					const_iterator(const Result* const p_result,
								   unsigned long p_row,
								   unsigned long p_column)
						throw ();					

					/** 
					 * Constructor.
					 */
					const_iterator (const const_iterator& p_other)
						throw ();

					/** 
					 * Destructor.
					 */
					~const_iterator()
						throw ();

					/**
					 * Operator =.
					 */
					const const_iterator& operator =(const const_iterator& p_other)
						throw ();

					/** 
					 * Prefix ++ operator.
					 */
					const_iterator& operator ++()
						throw (nettone::tools::Exception);

					/** 
					 * Postfix ++ operator.
					 */
					const_iterator operator ++(int)
						throw (nettone::tools::Exception);

					/**
					 * Operator *.
					 */
					const ResultCell& operator *() const
						throw ();

					/**
					 * Operator ->.
					 */
					const ResultCell* operator ->() const
						throw ();

					/**
					 * Operator ==.
					 */
					bool operator ==(const_iterator p_other) const
						throw ();

					/**
					 * Operator !=.
					 */
					bool operator !=(const_iterator p_other) const
						throw ();
					
				private:
					/**
					 * Pointer to the result table on which this const_iterator iterate.
					 */
					const Result* const m_result;

					/**
					 * Row number of the cell pointed by this iterator.
					 */
					unsigned long m_row;

					/**
					 * Column number of the cell pointed by this iterator.
					 */
					unsigned long m_column;

					/**
					 * Temporarily cell used in operators * and ->.
					 */
					mutable ResultCell* m_cell;
				}; // End of ResultRow::const_iterator

				/** 
				 * Constructor.
				 */
				ResultRow(const Result* const p_result,
						  unsigned long p_offset)
					throw ();

				/** 
				 * Constructor.
				 */
				ResultRow (const ResultRow& p_other)
					throw ();

				/**
				 * Assignment operator.
				 */
				const ResultRow& operator =(const ResultRow& p_other)
					throw ();

				/** 
				 * Move to the first cell in current row.
				 * 
				 * @return const_iterator to the first cell
				 */
				const_iterator begin() const
					throw ();
				
				/** 
				 * Move to the last cell in current row.
				 * 
				 * @return const_iterator to the last cell.
				 */
				const_iterator end() const
					throw ();

				/** 
				 * Size of the row, in number of cells.
				 * 
				 * @return number of cells in the row.
				 */
				unsigned long size() const
					throw ();

				/**
				 * Operator [].
				 */
				const_iterator operator [](const unsigned long p_at) const
					throw (nettone::tools::Exception);

				/** 
				 * Get the number of cells in the row.
				 * 
				 * @return number of cells in the row.
				 */
				unsigned long getCellsCount() const
					throw ();

			private:
				/**
				 * Pointer to the result table that contains this row.
				 */
				const Result* const m_result;
				
				/**
				 * Offset of this row in the result table.
				 */
				unsigned long m_offset;
			}; // End of class ResultRow.

			/**
			 * A cell in the result table
			 */
			class ResultCell
			{
			public:				
				// retrievCellContent can access to m_row and m_column
				friend class Result;

				/** 
				 * Constructor.
				 */
				ResultCell(const Result* const p_result,
						   unsigned long p_row,
						   unsigned long p_column)
					throw ();

				/** 
				 * Constructor.
				 */
				ResultCell (const ResultCell& p_other)
					throw ();

				/** 
				 * Destructor.
				 */
				~ResultCell()
					throw ();
				
				/**
				 * Assignment operator.
				 */
				const ResultCell& operator =(const ResultCell& p_other)
					throw ();

				/** 
				 * Retrieve the text content of the cell.
				 * 
				 * @return Text content of the cell.
				 */
				const std::string& getText() const
					throw (nettone::tools::Exception);

				/** 
				 * Retrieve the numeric content of the cell.
				 * 
				 * @return Numeric value of the cell.
				 */
				long getLong() const
					throw (nettone::tools::Exception);

				/** 
				 * Verify whether the cell is null.
				 * 
				 * @return 'true' if the cell is null, 'false' otherwise.
				 */
				bool isNull() const
					throw (nettone::tools::Exception);
				
			private:
				/**
				 * Structure to store the content of cell.
				 */
				struct Content
				{
					std::string text;
					bool isNull;
				};

				/** 
				 * Looking for the content of this cell and store it.
				 */
				void retrieveContent() const
					throw (nettone::tools::Exception);

				/** 
				 * Set the content of this cell.
				 * 
				 * @param p_text 	Content in text format
				 * @param p_isNull 	true if this cell is null, otherwise false
				 */				
				void setContent(const std::string& p_text,
								bool p_isNull) const
					throw ();
				/**
				 * Pointer to the result table that contains this cell.
				 */
				const Result* const m_result;

				/**
				 * Row number of this cell in result table.
				 */
				unsigned long m_row;

				/**
				 * Column number of this cell in result table.
				 */
				unsigned long m_column;

				/**
				 * Content of this cell.
				 */
				mutable Content* m_content;
			}; // End of class ResultCell.

			/**
			 * Connection to the database.
			 */
			class Connexion
			{
			public:
				/**
				 * Connexion configuration struct.
				 */
				struct Config {
					/**
					 * Name of the host where Mysql server is located.
					 */
					std::string hostname;

					/**
					 * Username for access to the database.
					 */
					std::string username;

					/**
					 * Password for access to the database.
					 */
					std::string password;

					/**
					 * Name of the database.
					 */
					std::string database;
				};

				/**
				 * Status of connection.
				 */
				enum CnxStatus {
					CONNECTED,
					NOT_CONNECTED,
					TEMPORARY_ERROR,
					PERMANENT_ERROR
				};
				
				/**
				 * Constructor.
				 */
				Connexion()
					throw ();
				
				/**
				 * Destructor.
				 */
				~Connexion()
					throw ();

				/** 
				 * Configure and initialize the connection.
				 *
				 * @param conf Configuration information.
				 */
				void init(const Config& p_config)
					throw (nettone::tools::Exception);

				/** 
				 * Send a SQL query to mysql client without retrieve the result.
				 * 
				 * @param p_query The query to be executed.
				 */
				void query(const std::string& p_query) const
					throw (nettone::tools::Exception); 

				/** 
				 * Send a SQL query to mysql client and retrieve the result.
				 * 
				 * @param p_query  The query to be executed.
				 * @param p_result A pointer to the result retrieved.
				 */
				void query(const std::string& p_query,
						   Result* const p_result) const
					throw (nettone::tools::Exception);

				/** 
				 * Send a several SQL queries to mysql client and retrieve all the results.
				 * 
				 * @param p_query  	The query to be executed.
				 * @param p_result 	A pointer to the result retrieved, user has to.
				 *					free it with freeMultiResult().
				 */
				void queryMultiple(const std::string& p_query,
								   ResultSet& p_result) const
					throw (nettone::tools::Exception);

				/** 
				 * Free the result of a queryMultiple.
				 * 
				 * @param p_result The set of results to be freed.
				 */
				static void freeMultiResult(ResultSet& p_result)
					throw ();

				/** 
				 * Get status of the connection.
				 * 
				 * @return Status of the connection.
				 */
				CnxStatus getCnxStatus() const
					throw ();

				/** 
				 * Get hostname of the connection.
				 * 
				 * @return Hostname of this connection.
				 */
				const std::string& getHostname() const
					throw ();

			private:				
				/// @name Forbidden methods.
				/// @{
				Connexion(const Connexion& p_other);
				const Connexion& operator =(const Connexion& p_other);
				/// @}
			
				/** 
				 * Set the status for this connexion.
				 * 
				 * @param p_status New connexion status.
				 */
				void setStatus(const CnxStatus& p_status) const
					throw ();

				/** 
				 * Send a SQL query to mysql client.
				 *
				 * @param p_query  	The query to be executed.
				 */
				void sendQuery(const std::string& p_query) const
					throw (nettone::tools::Exception);
				
				/** 
				 * Retrieve the result of the SQL query.
				 *
				 * @param p_query  	The query to be executed.
				 * @param p_result 	A pointer to the result retrieved.
				 */
				void retrieveMultiResults(const std::string& p_query,
										  ResultSet& p_result) const
					throw (nettone::tools::Exception);

				/** 
				 * Connect to the database.
				 */
				void connect()
					throw (nettone::tools::Exception);

				/** 
				 * Disconnect.
				 */
				void disconnect()
					throw ();
				
				/**
				 * Handle of database connection.
				 */
				MYSQL* m_sock;

				/**
				 * Status of the connexion.
				 */
				mutable CnxStatus m_status;

				/**
				 * Connexion configuration.
				 */
				Config m_config;
			}; // End of class Connexion

			struct Config 
			{
				/**
				 * Configuration struct of the connexions.
				 */
				Connexion::Config cnxConf;

				/**
				 * Maximal number of connexions.
				 */
				unsigned maxNbCnx;
				
				/**
				 * Maximal number of stand-by connexions.
				 */
				unsigned maxSbCnx;

				/**
				 * Default maximal numbers of connexions.
				 */
				enum {
					DEFAULT_MAX_CONNEXIONS = 5,
					DEFAULT_MAX_STANDBY_CONNEXIONS = 2
				};
			};
			
			/**
			 * Constructor.
			 */
			SqlRequestor()
				throw ();
			
			/**
			 * Destructor.
			 */
			~SqlRequestor()
				throw ();

			/** 
			 * Configure and initialize the SqlRequestor.
			 * 
			 * @param conf Configuration information.
			 */
			void init(const Config& p_config)
				throw ();

			/** 
			 * Get a connexion from the pool.
			 * 
			 * @return Pointer to a connexion, NULL if no connexion is available.
			 */
			Connexion* getCnx()
				throw (nettone::tools::Exception);
			
			/** 
			 * Release a connexion.
			 * 
			 * @param p_cnx Connexion to be released.
			 */
			void releaseCnx(Connexion* const p_cnx)
				throw (nettone::tools::Exception);

			/**
			 * Number of active connexions.
			 * 
			 * @return Number of active connexions.
			 */			
			unsigned long getActiveConnexionsCount() const
				throw (nettone::tools::Exception);
			
			/**
			 * Number of stand-by connexions.
			 * 
			 * @return Number of stand-by connexions.
			 */			
			unsigned long getStandbyConnexionsCount() const
				throw (nettone::tools::Exception);
			
		private:
			/// @name Forbidden methods.
			/// @{
			SqlRequestor(const SqlRequestor& p_other);
			const SqlRequestor& operator =(const SqlRequestor& p_other);
			/// @}

			/** 
			 * Release all connexions.
			 */
			void releaseAllCnx()
				throw ();
			
			/**
			 * List of active connexions.
			 */
			std::list<Connexion*> m_activeConnexions;

			/**
			 * List of stand-by connexions.
			 */
			std::list<Connexion*> m_standbyConnexions;

			/**
			 * Mutex.
			 */
			std::unique_ptr<nettone::tools::Mutex> m_lock;

			/**
			 * SqlRequestor configuration.
			 */
			Config m_config;

			/**
			 * Indicator, 'true' if SqlRequestor is initialized, 'false' otherwise
			 */
			bool m_initialized;
		};
	}
}


#endif // __NETTONE_SQL_SQLREQUESTOR_H__
