#ifndef __NETTONE_LUA_WRAPCLASS_H__
#define __NETTONE_LUA_WRAPCLASS_H__


extern "C"
{
#include <lua5.1/lua.h>
#include <lua5.1/lauxlib.h>
#include <lua5.1/lualib.h>
}

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace lua
	{
		/**
		 * Class descriptor.
		 */
		struct ClassDesc
		{
			/**
			 * Class name.
			 */
			std::string name;
			
			/**
			 * Descriptor of a method.
			 */
			struct MethodDesc
			{
				/**
				 * Name.
				 */
				std::string name;
				
				/**
				 * Executable body.
				 */
				lua_CFunction body;

				/**
				 * Description.
				 */
				std::string description;
			};
			
			/**
			 * Pointer to a set of method descriptors.
			 */
			const MethodDesc* methods;
			
			/**
			 * Finalizer function.
			 */
			lua_CFunction finalizer;
			
			/**
			 * Factory function.
			 */
			lua_CFunction factory;
		};
		
		/**
		 * Base class for wrapping classes in LUA world.
		 */
		template <typename T>
		class WrapClass
		{
		public:
			/**
			 * Destructor.
			 */
			virtual ~WrapClass()
				throw () {}
			
			/**
			 * Wrapping method.
			 * Create a wrapped T object, and create a mirror LUA-object in the
			 * stack passed as parameter
			 *
			 * @param p_L The LUA stack.
			 * 
			 * @return A pointer the the wrapped object.
			 */
			static T* createAndPush(lua_State* p_L);
		};
	}
}


#include "nettone_lua_WrapClass.ih"


#endif // __NETTONE_LUA_WRAPCLASS_H__
