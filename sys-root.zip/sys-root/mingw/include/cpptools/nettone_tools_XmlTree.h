// -----
// Code copied from ntk toolkit
// -----

#ifndef __NETTONE_TOOLS_XMLTREE_H__
#define __NETTONE_TOOLS_XMLTREE_H__


#include <sstream>
#include <string>
#include <vector>

#include <libxml/parser.h>

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_Configxml.h"


namespace nettone
{
	namespace tools
	{
		class ITransformer
		{
		public:
			virtual ~ITransformer() {}
			virtual xmlNodePtr applyIn(const xmlNodePtr p_node) = 0;
			virtual xmlNodePtr applyOut(const xmlNodePtr p_node) = 0;
		};

		class XmlTree
		{
		public:
			/**
			 * Constructor
			 */
			XmlTree(const xmlDocPtr p_doc);
			
			/**
			 * Constructor
			 * 
			 * Use for compatibily.
			 *
			 * @note This constructor creates the xmldocptr.
			 *		 He has to be destroyed in the destructor.
			 */
			XmlTree(const std::string& p_filename);
			
			/**
			 * Destructor
			 */
			virtual ~XmlTree();

			/**
			 *
			 */
			virtual void transform(ITransformer* const p_transformer);	
			
			/**
			 *
			 */
			static bool isLeaf(const xmlNodePtr p_node);
			
			template <typename T>
			static void getProp(T& p_param,
								const xmlNodePtr p_node,
								const char* p_attName)
			{
				const xmlChar* xmlFilename = xmlGetProp(p_node, (xmlChar*)p_attName);
				if (NULL == xmlFilename) {
					throw Exception("Unkown attribute"); // <==
				}

				std::istringstream ist((const char* )xmlFilename);
				ist >> p_param;
			}

			template <typename T>
			static void getPropOrDefault(T& p_param,
										 const xmlNodePtr p_node,
										 const char* p_attName,
										 const T& p_defaultValue)
			{
				try {
					getProp(p_param, p_node, p_attName);
				}
				catch (...) {
					p_param = p_defaultValue;
				}
			}

		private:
			/**
			 *
			 */
			virtual void transformSet(const xmlNodePtr p_node,
									  ITransformer* const p_transformer);
			
			/**
			 * Apply transformation on a node.
			 *
			 * @p_node 			Node to transform.
			 * @p_transformer 	Transformation to apply.
			 */
			virtual xmlNodePtr transformNode(const xmlNodePtr p_node,
											 ITransformer* const p_transformer);
									
			/**
			 * The xlm document.
			 */
			xmlDocPtr m_doc;
			
			/**
			 * Flag used to know if the xmlDocPtr m_doc has to be destroyed in destructor.
			 */
			const bool m_toDestroy;
		};

		template <>
		inline void XmlTree::getProp<std::string>(std::string& p_param,
												  const xmlNodePtr p_node,
												  const char* p_attName)
		{
			const xmlChar* xmlFilename = xmlGetProp(p_node, (xmlChar*)p_attName);
			if (NULL == xmlFilename) {
				throw Exception("Unkown attribute"); // <==
			}

			p_param = ((const char* )xmlFilename);
		}

		template <>
		inline void XmlTree::getProp<bool>(bool& p_param,
										   const xmlNodePtr p_node,
										   const char* p_attName)
		{
			const xmlChar* xmlFilename = xmlGetProp(p_node, (xmlChar*)p_attName);
			if (NULL == xmlFilename) {
				throw Exception("Unkown attribute"); // <==
			}

			std::istringstream ist((const char* )xmlFilename);
			ist >> std::boolalpha >> p_param;
		}
	}
}


#endif // __NETTONE_TOOLS_XMLTREE_H__
