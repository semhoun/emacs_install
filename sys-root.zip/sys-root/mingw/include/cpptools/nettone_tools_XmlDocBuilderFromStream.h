#ifndef __NETTONE_TOOLS_XMLDOCBUILDERFROMSTREAM_H__
#define __NETTONE_TOOLS_XMLDOCBUILDERFROMSTREAM_H__


#include <sstream>

#include "nettone_tools_Configxml.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Parse a xml stream.
		 */
		class XmlDocBuilderFromStream
			: public IXmlDocBuilder
		{
		public:
			/**
			 * Constructor
			 */
			XmlDocBuilderFromStream(const std::ostringstream& p_filename)
				throw (Exception);
			
			/**
			 * Destructor
			 */
			virtual ~XmlDocBuilderFromStream()
				throw ();

		private:
			/// @name Forbidden methods
			/// @{
			XmlDocBuilderFromStream(const XmlDocBuilderFromStream& p_other);
			const XmlDocBuilderFromStream& operator =(const XmlDocBuilderFromStream& p_other);
			/// @}
			
			/// @name Method from IXmlDocBuilder
			/// @{
			virtual xmlDocPtr getDoc() const;
			/// @}
			
			/**
			 * Pointer to the parsed document
			 */
			xmlDocPtr m_doc;
		};
	}
}


#endif // __NETTONE_TOOLS_XMLDOCBUILDERFROMSTREAM_H__
