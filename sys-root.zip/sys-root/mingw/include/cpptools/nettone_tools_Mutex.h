#ifndef __nettone_tools_Mutex_h__
#define __nettone_tools_Mutex_h__


#include <pthread.h>

#include "nettone_tools_Exception.h"
#include "nettone_tools_AutoLock.h"


namespace nettone
{
	namespace tools
	{
		class Cond;


		/**
		 * Wrapper around pthread mutexes.
		 */
		class Mutex
		{
		public:
			/**
			 * Constructor.
			 */
			Mutex() throw (Exception);

			/**
			 * Destructor.
			 */
			virtual ~Mutex() throw (Exception);

			/**
			 *
			 */
			void lock() throw (Exception);

			/**
			 *
			 */
			void unlock() throw (Exception);

		private:
			/// @name Forbidden methods
			/// @{
			Mutex(const Mutex& p_other);
			const Mutex& operator =(const Mutex& p_other);
			/// @}

			/// id of the underlying pthread.
			pthread_mutex_t m_mutexId;

			/* This friendship allows the Cond::wait() method implementation to gain
			 * access to the pthread_mutex_t object, without exposing
			 * it through a public interface.
			 */
			friend class Cond;
		};

		/// Automatic tool for mutex get/release.
		typedef AutoLock<Mutex> AutoMutex;
	}
}


#endif // __nettone_tools_Mutex_h__
