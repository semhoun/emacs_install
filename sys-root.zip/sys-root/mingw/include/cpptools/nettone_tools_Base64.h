#ifndef __NETTONE_TOOLS_BASE64_H__
#define __NETTONE_TOOLS_BASE64_H__


#include "nettone_tools_Exception.h"


namespace nettone
{
    namespace tools
    {
        /**
         * Class for encrypt and decrypt with Base64
         */
        class Base64
        {
        public:
            /**
             * Size needed to encode in base64
             *
             * @param p_size original
             *
             * @return needed size
             */
            static unsigned long neededSizeToEncode(const unsigned long p_size)
                throw();

            /**
             * Size needed to decode from base64
             *
             * @param p_size original
             *
             * @return needed size
             */
            static unsigned long neededSizeToDecode(const unsigned long p_size)
                throw();

            /**
             * encode data to base 64
             *
             * @param p_data			data to encode
             * @param p_dataLength		size of data to encode
             * @param p_out				buffer where put encoded data
             * @param p_outLength		buffer allocated size
             *
             * @return nb write bytes
             */
            static unsigned long encode(const char* p_data,
                                        const unsigned long p_dataLength,
                                        char const* p_out,
                                        const unsigned long p_outLength)
                throw (nettone::tools::Exception);

            /**
             * encode data from base 64
             *
             * @param p_data			data to decode
             * @param p_dataLength		size of data to decode
             * @param p_out			buffer where put decoded data
             * @param p_outLength		buffer allocated size
             *
             * @return nb write bytes
             */
            static unsigned long decode(const char* p_data,
                                        const unsigned long p_dataLength,
                                        char const* p_out,
                                        const unsigned long p_outLength)
                throw (nettone::tools::Exception);

        private:
            /**
             * Constructor.
             */
            Base64()
                throw();
        };
    }
}


#endif //__NETTONE_TOOLS_BASE64_H__
