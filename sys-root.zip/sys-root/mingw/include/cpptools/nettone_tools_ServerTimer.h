#ifndef __NETTONE_TOOLS_SERVERTIMER_H__
#define __NETTONE_TOOLS_SERVERTIMER_H__


#include <list>
#include <memory>

#include "nettone_tools_Monitor.h"
#include "nettone_tools_Thread.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Timer manager.
		 */
		class ServerTimer
		{
		public:
			/**
			 * Return the time in milisec since EPOC.
			 * (absolute time).
			 */
			static unsigned long now() 
				throw ();
			
			/**
			 * Return the date like "year_month_day".
			 */
			static std::string getDate()
				throw ();

			/**
			 * Type of the request ID.
			 */
			class RequestId
			{
			public:
				/**
				 * The null object.
				 */
				static const RequestId null;

				/**
				 * Return a new unique RequestId object.
				 * Value loops on 32 bits unsigned.
				 */
				static RequestId getNewId()
					throw ();

				/**
				 * Constructor.
				 */
				RequestId()
					throw ();

				/**
				 * Casting to a unsigned long.
				 */
				operator unsigned long() const
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator ==(const RequestId& p_other)
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator !=(const RequestId& p_other)
					throw ();

				/**
				 * Assignement operator.
				 */
				const RequestId& operator =(const RequestId& p_other)
					throw ();

			private:
				/**
				 * Constructor.
				 */
				RequestId(const unsigned long p_reqId)
					throw ();

				/**
				 * The ID itself.
				 */
				unsigned long m_reqId;
			};

			/**
			 * Interface of timer handler.
			 */
			class ITimeout
			{
			public:
				/**
				 * Destructor.
				 */
				virtual ~ITimeout()
				{}

				/**
				 * Method called when a timer has expired.
				 *
				 * @param p_reqId ID of the request.
				 * @param p_key   The key provided at registration time.
				 * @param p_delta Difference in millisec between the requested timer
				 *                and the time this method is called.
				 */
				virtual void handleTimeout(const RequestId p_reqId,
										   void* const p_key, 
										   const unsigned long p_delta)
					throw () = 0;
			};

			/**
			 * Constructor.
			 */
			ServerTimer()
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			virtual ~ServerTimer()
				throw ();

			/**
			 * Start the server.
			 */
			void start()
				throw (nettone::tools::Exception);

			/**
			 * Stop the server.
			 */
			void stop()
				throw ();

			/**
			 * Schedule an event for further processing.
			 *
			 * @param p_reqId   Where to store the request Id.
			 * @param p_delay   The timer delay in milliseconds.
			 * @param p_handler The interface handling the timer.
			 * @param p_key     Request identifier (registration key).
			 *
			 * @return The ID of the request.
			 */
			void postTimer(RequestId& p_reqId,
						   const unsigned long p_delay,
						   ITimeout* const p_handler,
						   void* const p_key)
				throw (nettone::tools::Exception);

			/**
			 * Cancel a timer request.
			 * 
			 * @param p_reqId The request ID.
			 */
			void cancelTimer(const RequestId p_reqId)
				throw (nettone::tools::Exception);

			template <typename C>
			class LateRunner0
				: public ITimeout
			{
			public:
				typedef void (C::* Func)();
				LateRunner0(C* const p_target,
							Func p_func)
					: m_target(p_target),
					  m_func(p_func)
				{}

			private:
				virtual void handleTimeout(const RequestId p_reqId,
										   void* const p_key, 
										   const unsigned long p_delta)
					throw ()
				{
					std::unique_ptr<ITimeout> thisAD(this);
					(m_target->*m_func)();
				}

				C* m_target;
				Func m_func;
			};

			template <typename C, typename P1>
			class LateRunner1
				: public ITimeout
			{
			public:
				typedef void (C::* Func)(const P1&);
				LateRunner1(C* const p_target,
							Func p_func,
							const P1& p_p1)
					: m_target(p_target),
					  m_func(p_func),
					  m_p1(p_p1)
				{}

			private:
				virtual void handleTimeout(const RequestId p_reqId,
										   void* const p_key, 
										   const unsigned long p_delta)
					throw ()
				{
					std::unique_ptr<ITimeout> thisAD(this);
					(m_target->*m_func)(m_p1);
				}

				C* m_target;
				Func m_func;
				const P1 m_p1;
			};

			template <typename C, typename P1, typename P2>
			class LateRunner2
				: public ITimeout
			{
			public:
				typedef void (C::* Func)(const P1&, const P2&);
				LateRunner2(C* const p_target,
							Func p_func,
							const P1& p_p1,
                            const P2& p_p2)
					: m_target(p_target),
					  m_func(p_func),
					  m_p1(p_p1),
                      m_p2(p_p2)
				{}

			private:
				virtual void handleTimeout(const RequestId p_reqId,
										   void* const p_key,
										   const unsigned long p_delta)
					throw ()
				{
					std::unique_ptr<ITimeout> thisAD(this);
					(m_target->*m_func)(m_p1, m_p2);
				}

				C* m_target;
				Func m_func;
				const P1 m_p1;
				const P2 m_p2;
			};

			template <typename C>
			ITimeout* buildRunner(C* const p_target,
								  void (C::* p_func)())
			{
				return new LateRunner0<C>(p_target, p_func);
			}

			template <typename C, typename P1>
			ITimeout* buildRunner(C* const p_target,
								  void (C::* p_func)(const P1&),
								  const P1& p_p1)
			{
				return new LateRunner1<C, P1>(p_target, p_func, p_p1);
			}

			template <typename C, typename P1, typename P2>
			ITimeout* buildRunner(C* const p_target,
								  void (C::* p_func)(const P1&, const P2&),
								  const P1& p_p1,
                                  const P2& p_p2)
			{
				return new LateRunner2<C, P1, P2>(p_target, p_func, p_p1, p_p2);
			}

			template <typename C>
			inline void callLater(RequestId& p_requestId,
								  const unsigned long p_delay,
								  void* const p_key,
								  C* const p_target,
								  void (C::* p_func)())
			{
				std::unique_ptr<ITimeout> laterRunnerAD(buildRunner(p_target, p_func));
				postTimer(p_requestId, p_delay, laterRunnerAD.get(), p_key);
				laterRunnerAD.release();
			}

			template <typename C, typename P1>
			inline void callLater(RequestId& p_requestId,
								  const unsigned long p_delay,
								  void* const p_key,
								  C* const p_target,
								  void (C::* p_func)(const P1&),
								  const P1& p_p1)
			{
				std::unique_ptr<ITimeout> laterRunnerAD(buildRunner(p_target, p_func, p_p1));
				postTimer(p_requestId, p_delay, laterRunnerAD.get(), p_key);
				laterRunnerAD.release();
			}
			
			template <typename C, typename P1, typename P2>
			inline void callLater(RequestId& p_requestId,
								  const unsigned long p_delay,
								  void* const p_key,
								  C* const p_target,
								  void (C::* p_func)(const P1&, const P2&),
								  const P1& p_p1,
                                  const P2& p_p2)
			{
				std::unique_ptr<ITimeout> laterRunnerAD(buildRunner(p_target, p_func, p_p1, p_p2));
				postTimer(p_requestId, p_delay, laterRunnerAD.get(), p_key);
				laterRunnerAD.release();
			}

		private:
			/// @name Forbidden methods
			/// @{
			ServerTimer(const ServerTimer& p_other);
			const ServerTimer& operator =(const ServerTimer& p_other);
			/// @}

			/**
			 * Task managing the timers.
			 */
			class TimerProcessor
				: public nettone::tools::Thread
			{
			public:
				/**
				 * Constructor.
				 *
				 * @param p_visitor The ServerTimer itself.
				 */
				TimerProcessor(ServerTimer* p_outer)
					throw ();

				/**
				 * Destructor.
				 */
				virtual ~TimerProcessor()
					throw ();

			private:
				/// @name Methods from Thread
				/// @{
				virtual void run()
					throw ();
				/// @}

				/**
				 * The outer class (timer server).
				 */
				ServerTimer* m_outer;
			};
			friend class TimerProcessor;

			/**
			 * Descriptor of a processing request.
			 */
			struct Request
			{
			public:
				/**
				 * The timer handler.
				 */
				ITimeout* handler;

				/**
				 * The key identifying the request.
				 */
				void* key;

				/**
				 * Expiration date.
				 */
				unsigned long expirationDate;

				/**
				 * Request ID.
				 */
				RequestId reqId;
			};

			/**
			 * Timer queue.
			 */
			std::list<Request> m_timerQueue;

			/**
			 * The timer processor.
			 */
			TimerProcessor* m_timerProcessor;

			/**
			 * Monitor the access to the timer queue.
			 */
			nettone::tools::Monitor* m_monitor;

			/**
			 * Flag indicating that the timer server must not wait
			 * because some request has been posted, that may need
			 * to recompute wait delay.
			 */
			bool m_mustRecomputeDelay;

			/**
			 * Date of the next wakeup.
			 */
			unsigned long m_nextWakeupDate;

			/**
			 * Current sleep delay.
			 */
			unsigned long m_waitDelay;
		};
	}
}


#endif // __NETTONE_TOOLS_SERVERTIMER_H__
