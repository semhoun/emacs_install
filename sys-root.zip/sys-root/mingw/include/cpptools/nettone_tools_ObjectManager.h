#ifndef __NETTONE_TOOLS_OBJECTMANAGER_H__
#define __NETTONE_TOOLS_OBJECTMANAGER_H__


#include <map>

#include "nettone_tools_Handle.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * Manager of resources indexed by ID.
		 */
		template <typename T, typename K>
		class ObjectManager
		{
		public:
			typedef T Object;
			typedef K Key;
			typedef Handle<T, K> Handler;
			
			/**
			 * Constructor.
			 */
			inline ObjectManager()
				throw ();

			/**
			 * Destructor.
			 */
			inline ~ObjectManager()
				throw ();

			/**
			 * Add a resource to the manager.
			 *
			 * @param p_object   The object to add.
			 * @param p_id       The registration ID of the object.
			 */
			inline void addObject(Object const p_object,
								  const Key& p_id)
				throw (nettone::tools::Exception);

			/**
			 * Retrieve an object from its Id.
			 *
			 * @param p_id The registration ID of the object.
			 */
			inline Object getObject(const Key& p_id)
				throw (nettone::tools::Exception);

			/**
			 * Delete a resource from the manager.
			 * 
			 * @param p_id The registration ID of the object.
			 *
			 * @return The object removed from the manager.
			 */
			inline Object delObject(const Key& p_id)
				throw (nettone::tools::Exception);

			/**
			 * Get an handle on an object from its id.
			 *
			 * @param p_id The registration ID of the object.
			 */
			inline Handler getHandle(const Key& p_id)
				throw ();

			/**
			 * Get an handle on an object from its id.
			 *
			 * @param p_id The registration ID of the object.
			 */
			inline Handler checkAndGetHandle(const Key& p_id)
				throw (nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			ObjectManager(const ObjectManager<T, Key>& p_other);
			const ObjectManager<T, Key>& operator =(const ObjectManager<T, Key>& p_other);
			/// @}

			/**
			 * @var ObjectMapById m_objects
			 * Set of managed objects.
			 */
			typedef std::map<Key, Object> ObjectMapById;
			ObjectMapById m_objects;
		};
	}
}


#include "nettone_tools_ObjectManager.ih"


#endif // __NETTONE_TOOLS_OBJECTMANAGER_H__
