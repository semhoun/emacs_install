#ifndef __NETTONE_TOOLS_STRINGUTILS_H__
#define __NETTONE_TOOLS_STRINGUTILS_H__


#include <string>
#include <vector>
#include <map>
#include <list>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * String utils
		 */
		class StringUtils
		{
		public:
			static void replace(std::string& p_string,
								const std::string& p_what,
								const std::string& p_by)
				throw ();
			static void replace(std::string& p_string,
								const std::string& p_marker,
								const unsigned short p_strSize,
								const std::map<std::string, std::string>& p_map)
				throw ();
			/** 
			 * Replace list of string in p_string 
			 * Be careful of order of string in map ex: toto and to
			 * 
			 * @param p_string String where replace char
			 * @param p_map Map of string <what; by>
			 */
			typedef std::list<std::pair<std::string, std::string> > SubstitutionList;
			static void replace(std::string& p_string,
								const SubstitutionList& p_map)
				throw ();
				
			/**
			 * Découpe une chaine constituée de plusieurs sous chaines.
			 * 
			 * @param p_string 	La chaine à découper.
			 * @param p_sep 	Séparateur des sous-chaines.
			 * @param p_array 	Tableau de résultat, contient toutes les sous chaines.
			 */
			static void split(const std::string& p_string,
							  const std::string& p_sep,
							  std::vector<std::string>& p_array)
				throw ();
				
			/** 
			 * Converts an utf8 string to iso-8859-1
			 */
			static std::string utf8_latin(const std::string& p_src)
				throw (Exception);
			/**
			 * Converts a iso-8859-1 to utf8
			 */
			static std::string latin_utf8(const std::string& p_src)
				throw ();
				
			/**
			 * Returns the number of occurence of p_find contained in p_string
			 *
			 * @param p_string 	The string to test.
			 * @param p_find 	Element to find.
			 *
			 * @return Number of occurence of p_fing in p_string.
			 */
			static unsigned long nb_occur(const std::string& p_string, 
										  const std::string& p_find)
				throw (Exception);
				
			/**
			 * Tests is a string a the prefix of another string
			 * @param p_str reference string
			 * @param p_prefix prefix to search
			 * @return true if p_prefix is the prefix of p_str
			 */
			static bool isPrefix(const std::string& p_str,
								 const std::string& p_prefix)
				throw();

		private:
			/// @name Forbidden methods
			/// @{
			StringUtils();
			/// @}
		};
	}
}


#endif // __NETTONE_TOOLS_STRINGUTILS_H__
