#ifndef __NETTONE_TOOLS_IMODULE_H__
#define __NETTONE_TOOLS_IMODULE_H__


#include "cpptools/nettone_tools_IService.h"


namespace nettone
{
	namespace tools
	{
        class Configxml;

        struct TModuleBase
        {
            typedef Configxml* TStartParam;

            struct TStartAnswerParam
            {
                enum EBootStatus
                {
                    EBOOTSTATUS_SUCCEED,
                    EBOOTSTATUS_FAILED
                };
                EBootStatus status;

                std::string reason;
            };

            struct TStopAnswerParam
            {
            };
        };

		class IModule
            : public TModuleBase,
              public IService<TModuleBase>
		{
		public:
			virtual ~IModule() {}

            virtual bool requestStart(TStartParam const& p_param,
                                      IStart* const& p_handler) = 0;
            virtual bool requestStop(IStop* const& p_param) = 0;
		};
	}
}


#endif // __NETTONE_TOOLS_IMODULE_H__
