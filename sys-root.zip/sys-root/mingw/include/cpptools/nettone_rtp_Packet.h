
#pragma once

#include <memory>
#include <stdint.h>
#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_codec_identifiers.h"
#include "cpptools/nettone_net_Buffer.h"
#include "cpptools/nettone_net_Packet.h"
#include "cpptools/nettone_net_InetAddr.h"
 
 namespace nettone
{
	namespace net
	{
		class InetAddr;
	}
	
	namespace rtp
	{
		class Session;
		
		class Packet : public nettone::net::Packet
		{
			
			private:		
			/**
			 *  Header class used to handle Header manipulation
			 */
			class Header
			{
				friend class 	Packet;
				friend class	Session;
				
			public :
				/**
				 * Constants used according to RFC 3550 (use of defines is deprecated)
				 */
				static const uint8_t 		RTP_HEADER_MAXIMUM_SOURCE = 15;
				static const uint8_t		RTP_HEADER_VERSION = 2;
				static const uint32_t 		RTP_HEADER_MINIMUM_SIZE = 12;
				
				/**
				 * Header constructor
				 */
				Header()
					throw();
				
				/**
				 * Header destructor
				 */
				virtual ~Header()
					throw();
				
				
				/**
				 * @param p_packetRaw  	Buffer that contains a Packet 
				 * @param p_size		size of buffer
				 * Header constructor
				 */
				Header(uint8_t* p_packetRaw, unsigned int p_size)
					throw(nettone::tools::Exception);
				
				/**
				 * Build header with packet
				 */
				Header(nettone::net::Packet *p_rtpPacket)
					throw (nettone::tools::Exception);
				
				/**
				 * Return string with members values
				 */
				std::string toString()
					throw();
					
				/**
				 * Deserialize header from raw buffer
				 * Static function : tool for deserialize header anywhere
				 *
				 * @param p_header Header to fill with data
				 * @param p_rawPacket Full packet
				 * @param p_packet Size of packet
				 */
				static Header* deserializeHeader(uint8_t* p_packetRaw, unsigned int p_size)
					throw (nettone::tools::Exception);
					
				/**
				 * Serialization a header to uint8_t* 
				 * Static function tools for serialization of header
				 * @param p_header
				 * @return uint8_t * Raw buffer
				 * 
				 */
				static uint8_t* serialize(Header* p_header)
					throw(nettone::tools::Exception);
				/**
				 * Build Header with uint8_t *  from parameters
				 * User is responsible of destruction
				 * @param p_codec Payload type
				 * @param p_sequenceNumber SequenceNumber (incremented for each send) normal or randoam value in nettone::rtp::Session
				 * @param p_ssrc synchronization source identifier, identifier of the stream
				 * @param p_csrc The number of csrc identifiers that fow the fixed header [0..15rtpflowrtpflow]
				 * @param p_marker marker 
				 */
				 
				//TODO remettre ce prototype
				static Header* serialize(nettone::codec::CodecId p_codec,
							 uint16_t p_sequenceNumber,
							 uint32_t p_timestamp,
							 uint32_t p_ssrc,
							 uint32_t p_csrc,
							 bool p_marker)
					throw(nettone::tools::Exception);
				
				
				// TODO tester ce prototype 
				static uint8_t* serializeToRaw(nettone::codec::CodecId p_codec,
							 uint16_t p_sequenceNumber,
							 uint32_t p_timestamp,
							 uint32_t p_ssrc,
							 uint32_t p_csrc,
							 bool p_marker)
					throw(nettone::tools::Exception);	
					
				/**
				 * Get minimal size to allocate a buffer for header  
				 */
				static uint32_t getMinimumSizeOfHeader(Header* p_header)
					throw (nettone::tools::Exception);
				
				/**
				 * Accesors for version
				 */
				uint8_t getVersion()
					throw();
				
				/**
				 * Accesors for padding
				 */
				uint8_t getPadding()
					throw();
				
				/**
				 * Accesors for extension
				 */
				uint8_t getExtension()
					throw();
				
				/**
				 * Accesors for csrccount
				 */
				uint8_t getCsrcCount()
					throw();
				
				/**
				 * Accesors for marker
				 */
				uint8_t getMarker()
					throw();
				
				/**
				 * Accesors for payload type
				 */
				uint8_t getPayloadType()
					throw();
				
				/**
				 * Accesors for sequence number
				 */
				uint16_t getSequenceNumber()
					throw();
			
				/**
				 * Accesors for timestamp
				 */
				uint32_t getTimestamp()
					throw();
				
				/**
				 * Accesors for ssrc
				 */
				uint32_t getSsrc()
					throw();
					
				/**
				 *  Forbidden method
				 */
				Header(const Header& p_other) = delete;
				const Header& operator =(const Header& p_other) = delete;
				
			private :

				/**
				 * Version that idenfity the version of RTP
				 */ 
				uint8_t m_version;
				
				/**
				 * Padding bit 
				 */
				uint8_t m_padding;
				
				/**
				 * Extention : If the extension bit is set, the fixed header is followed by exactly one header extension
				 */
				uint8_t m_extension;
				
				/**
				 * The CSRC count contains the number of CSRC identifiers that follow the fixed header.
				 */
				uint8_t m_csrcCount;
				
				/**
				 * The interpretation of the marker is defined by a profile. 
				 * It is intended to allow significant events such as frame boundaries to be marked in the packet stream
				 * A profile may define additional marker bits or specify that there is no marker bit by changing the number of bits in the payload type field 
				 */
				uint8_t m_marker;
				
				/**
				 * Payload
				 */
				uint8_t m_payloadType;
				
				/**
				 * The sequence number increments by one for each RTP data packet sent,
				 * and may be used by the receiver to detect packet loss and to restore packet sequence.
				 */
				uint16_t m_sequenceNumber;
				
				/**
				 * The timestamp reflects the sampling instant of the first octet in the RTP data packet.
				 * The sampling instant must be derived from a clock that increments monotonically and linearly in time to allow synchronization and jitter calculations
				 * 
				 */
				uint32_t m_timestamp;
				
				/**
				 * The SSRC field identifies the synchronization sourc
				 */
				uint32_t m_ssrc;
				
				/**
				 * The CSRC list identifies the contributing sources for the payload contained in this packet. 
				 * The number of identifiers is given by the CC field. If there are more than 15 contributing sources, only 15 may be identified. 
				 * 
				 */ 				 
				uint32_t m_csrc[15];

				/**
				 * Buffer that contains header
				 */
				std::unique_ptr<uint8_t> m_rawHeader;

			}; // Header class
			
		public :
			
			/**
			 * Get RtpHeader
			 */
			Header* getRtpHeader()
				throw();
			/**
			 * Get raw packet buffer
			 */
			uint8_t* getRawPacket()
				throw();
			
			/**
			 * Get raw payload
			 */
			uint8_t* getRawPayload()
				throw();
			
			/**
			 * Get payload size
			 */
			unsigned long getRawPayloadSize()
				throw();
			
			/**
			 * Get rawpacket size
			 */
			unsigned long getRawPacketSize()
				throw();
			
			/**
			 * Deserialize from nettone::net::Packet
			 * User is responsible of deletion
			 */ 
			static nettone::rtp::Packet* deserialize(const nettone::net::Packet* p_packet)
				throw(nettone::tools::Exception);
			
			/**
			 * Deserialize from nettone::net::Buffer* 
			 * User is responsible of deletion
			 */
			static nettone::rtp::Packet* deserialize(nettone::net::InetAddr* const p_address, const nettone::net::Buffer *p_buffer, unsigned long p_size)
				throw(nettone::tools::Exception);
			
			/**
			 * Deserialize from uint8_t*
			 * User is responsible of deletion
			 */
			static nettone::rtp::Packet* deserialize(nettone::net::InetAddr* const p_address, uint8_t *p_rawBuffer, unsigned long p_size)
				throw(nettone::tools::Exception);
			
			/**
			 * Serialize from multiple parameters
			 * User is responsible of deletion
			 */
			static nettone::rtp::Packet* serialize(nettone::net::InetAddr* const p_address,
							       const nettone::net::Buffer* const p_payload,
							       const unsigned long p_size,
							       nettone::codec::CodecId p_codec,
							       uint16_t p_sequenceNumber,
							       uint32_t p_timestamp,
							       uint32_t p_ssrc,
							       uint32_t p_csrcCount,
							       bool p_marker)
				throw (nettone::tools::Exception);

			/**
			 * Serialize from multiple parameters
			 * User is responsible of deletion of p_payload and p_address
			 */ 
			static nettone::net::Packet* serializeToPacket(nettone::net::InetAddr* const p_address,
							       const nettone::net::Buffer* const p_payload,
							       const unsigned long p_size,
							       nettone::codec::CodecId p_codec,
							       uint16_t p_sequenceNumber,
							       uint32_t p_timestamp,
							       uint32_t p_ssrc,
							       uint32_t p_csrcCount,
							       bool p_marker)
				throw (nettone::tools::Exception);
			
			/**
			 * Get payload type
			 */
			nettone::codec::CodecId getPayloadType();

			/**
			 * Build packet with nettone::net::Packet 
			 */
			Packet(nettone::net::Packet *p_packet)
				throw(nettone::tools::Exception);
			
			/**
			 * Destructor
			 */
			 virtual ~Packet()
				 throw();
			 
		private:
			 			
			 /**
			  * Forbidden method
			  */
			Packet(const Packet& p_other);
			const Packet& operator =(const Packet& p_operation);
			 
			 /**
			 * Internal use for serialization
			 */
			Packet(nettone::net::InetAddr* const p_address,
					const nettone::net::Buffer* const p_data,
					const unsigned long p_size)
				throw (nettone::tools::Exception);
			
			/**
			 * Deserialize payload from uint8_t* and fill p_outPayloadSize
			 * **Internal use**
			 */
			static uint8_t*	deserializePayload(Header* p_rtpHeader, uint8_t* p_rawPacket, unsigned long p_size, uint8_t* p_outPayloadSize)
				throw(nettone::tools::Exception);
			 
			/**
			 * Pointer to Header class
			 */
			 std::unique_ptr<Header> m_rtpHeader;
			 
			/**
			 * Pointer to raw buffer Packet (ready to be sent)
			 */
			 std::unique_ptr<uint8_t> m_rawPacket;

			 /**
			 * Pointer to raw buffer of payload (ready to be sent)
			 */
			std::unique_ptr<uint8_t> m_rawPayload;

			/**
			 * Size of rawPacket
			 */ 
			 unsigned long m_rawPacketSize;
			 
			/**
			 * Size of payload
			 */
			unsigned long m_rawPayloadSize;

		}; // Packet class

	} // nettone rtp

} // nettone namespace
