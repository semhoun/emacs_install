#ifndef __NETTONE_LUA_WRAPORB_H__
#define __NETTONE_LUA_WRAPORB_H__


#include <omniORB4/CORBA.h>


namespace nettone
{
	namespace lua
	{
		struct WrapOrb
		{
			/**
			 * Handle on the ORB.
			 */
			CORBA::ORB_var orb;
		};
	}
}


#endif // __NETTONE_LUA_WRAPORB_H__
