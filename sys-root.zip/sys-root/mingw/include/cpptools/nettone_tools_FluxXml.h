#pragma once

#include <libxml/parser.h>
#include <libxml/xpath.h>

#include "nettone_tools_Exception.h"


namespace nettone::tools
{
	/**
	 * Retrieving information from XML string or ostringstream
	 *
	 * @note libxml2 must be initialized before construct an object (xmlInitParser() and xmlXPathInit()).
	 * 		 At the end of application using libxml2, you have to cleanup Parser (xlmCleanupParser()).
	 */
	class FluxXml
	{
	public:
		/**
		 * Constructor
		 *
		 * @param p_flux The flux to parse.
		 *
		 * @exception nettone::tools::Exception thrown when file is not well-formed.
		 */
		FluxXml(const std::string& p_flux)
			throw (Exception);

		/**
		 * Destructor
		 */
		~FluxXml()
		throw ();

		/**
		 * Test if the xpath mach with xml flux.
		 *
		 * @param p_xpath 	The xpath to test
		 *
		 * @return Bool if xpath is matching. False otherwise.
		 */
		bool match(const std::string& p_xpath)
			throw (Exception);

		/**
		 * Retrieve an integer entry using xpath
		 *
		 * @param p_xpath Xpath to the element to be retrieved
		 * @param p_resId ID of the result element to retrieve
		 *
		 * @return Integer result of given Xpath
		 *
		 * @exception nettone::tools::Exception thrown when no result found
		 */
		unsigned long getULong(const std::string& p_xpath,
							   const unsigned short p_resId = 0) const
			throw (Exception);

		/**
		 * Retrieve an integer entry using xpath
		 *
		 * @param p_xpath Xpath to the element to be retrieved
		 * @param p_resId ID of the result element to retrieve
		 *
		 * @return Integer result of given Xpath
		 *
		 * @exception nettone::tools::Exception thrown when no result found
		 */
		long getLong(const std::string& p_xpath,
					 const unsigned short p_resId = 0) const
			throw (Exception);

		/**
		 * Retrieve an text entry using xpath
		 *
		 * @param p_xpath Xpath to the element to be retrieved
		 * @param p_resId ID of the result element to retrieve
		 *
		 * @return All text found at XML element given by Xpath
		 *
		 * @exception nettone::tools::Exception thrown when no result found
		 */
		std::string getText(const std::string& p_xpath,
							const unsigned short p_resId = 0) const
			throw (Exception);

		/**
		 * Retrieve the name of given xpath
		 *
		 * @param p_xpath Xpath to the node to be retrieved
		 * @param p_resId ID of the result element to retrieve
		 *
		 * @return All text found at XML element given by xpath
		 *
		 * @exception nettone::tools::Exception thrown when no result found
		 */
		std::string getName(const std::string& p_xpath,
							const unsigned short p_resId = 0) const
			throw (Exception);


		/**
		 * Get the XML doc
		 */
		xmlDocPtr getXMLDoc()
			throw();

	private:
		/// @name Forbidden methods
		/// @{
		FluxXml(const FluxXml& p_other);
		const FluxXml& operator =(const FluxXml& p_other);
		/// @}

		/**
		 * Evaluate the xpath and return the set of result
		 *
		 * @param p_xpath Xpath to the element to be retrieved
		 *
		 * @return Set of nodes correspond to the Xpath.
		 *
		 * @exception nettone::tools::Exception thrown when no result found
		 */
		xmlXPathObjectPtr getXPathResult(const std::string& p_xpath) const
			throw (Exception);

		/**
		 * Get the first node from the set of results evaluated.
		 *
		 * @param p_result Set of results returned by getXpathResult
		 *
		 * @return The first node that correspond to the Xpath
		 *
		 * @deprecated
		 */
		xmlNodePtr getFirstResult(const xmlXPathObjectPtr p_result) const
			throw ();

		/**
		 * Get the first node from the set of results evaluated.
		 *
		 * @param p_result Set of results returned by getXpathResult
		 * @param p_nodeId Id of the result node to retrieve
		 *
		 * @return A pointer to a xmlNode object.
		 */
		xmlNodePtr getResultAtIndex(const xmlXPathObjectPtr p_result,
									const unsigned short p_nodeId) const
			throw (Exception);

		/**
		 * Get all text contained in a node
		 *
		 * @param p_node  Pointer to the node
		 *
		 * @return Set of nodes correspond to the Xpath.
		 *
		 * @exception nettone::tools::Exception thrown when node is empty or contained no unignorable text
		 */
		std::string getTextContent(const xmlNodePtr p_node) const
			throw (Exception);

		/**
		 * Pointer to the parsed flux
		 */
		xmlDocPtr m_doc;

		/**
		 * Current XPath request
		 */
		mutable std::string m_xpath;

		/**
		 * Current XPath-selected node set
		 */
		mutable xmlXPathObjectPtr m_nodeSet;
	};
}
