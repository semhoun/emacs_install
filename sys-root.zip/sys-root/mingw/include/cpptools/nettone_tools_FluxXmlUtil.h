#ifndef __NETTONE_TOOLS_FLUXXMLUTIL_H__
#define  __NETTONE_TOOLS_FLUXXMLUTIL_H__


#include "nettone_tools_FluxXml.h"


namespace nettone 
{
	namespace tools
	{
		class FluxXmlUtil
		{
		public:
 			/**
			 * Retrieve an integer entry using xpath
			 *
			 *  @param p_flux FluxXml Object
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 *
			 * @param p_default Default value to be returned in case error 
			 *
			 * @return Integer result of given Xpath
			 */
			static unsigned long getULong(const FluxXml* p_flux,
										  const std::string& p_xpath,
										  const unsigned long p_default)
				throw ();
			
			/**
			 * Retrieve an text entry using xpath
			 *
			 * @param p_flux FluxXml Object
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 *
			 * @param p_default Default value to be returned in case error 
			 *
			 * @return Text result of given Xpath
			 */
			static std::string getText(const FluxXml* p_flux,
									   const std::string& p_xpath,
									   const std::string& p_default)
				throw ();

			
		private:
			/// @name Forbidden methods
			/// @{
			FluxXmlUtil();
			~FluxXmlUtil();
			/// @}
		};
	}
}

#endif //  __NETTONE_TOOLS_FLUXXMLUTIL_H__
