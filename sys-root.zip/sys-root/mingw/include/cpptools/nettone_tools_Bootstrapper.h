#ifndef __NETTONE_TOOLS_BOOTSTRAPPER_H__
#define __NETTONE_TOOLS_BOOTSTRAPPER_H__


#include <map>
#include <string>
#include <vector>

#include "cpptools/nettone_tools_IModule.h"
#include "cpptools/nettone_tools_ServerDeferred.h"
#include "cpptools/nettone_tools_Configxml.h"


namespace nettone
{
	namespace tools
	{
		/**
		 * This class is NOT thread safe. Only one thread must be used to interact with an instance of Bootstrapper.
		 * 
		 * IDLE --- start() --> READY
		 * READY --- stop() --> IDLE
		 * READY --- requestStart() --> BOOTING
		 * BOOTING --- all or some requested modules started and some modules are booted --> BOOTED
		 * BOOTING --- all or some requested modules started and no module is booted --> READY
		 * BOOTED --- requestStart() --> BOOTING
		 * BOOTED --- requestStop() --> STOPPING
		 * helper : READY --- requestStop() --> READY 
		 * STOPPING --- no module sill booted --> READY
		 * STOPPING --- some modules sill booted --> BOOTED
		 * 
		 * 
		 * The class Bootstrapper uses a ServerDeferred to process handlers in its very own private thread. 
		 * One may wonder why.
		 * Suppose a module A owned a time server. Suppose a module B, depending on A uses this
		 * time server to deferred its stop after some delay. Suppose B is the very last module depending on A.
		 * When the delay B has set up when requested to stop by the Bootstrapper,  the handler associated to this
		 * delay will be processed by the time server. Then, as B is the last dependency on it, A will be immediatly
		 * (understand synchronously) requested to stop. So A will try to stop the time server. So the situation
		 * is : A will try to stop the time server while the time server is processing a handler.
		 * This will fail.
		 *
		 * By using it own thread (ServerDeferred), the Bootstrapper is sure it will never face a situation
		 * like the one described before.
		 */
		class Bootstrapper
		{
		public:
			Bootstrapper();

			void start();
			void stop();

			typedef std::string TModuleName;
			typedef unsigned short TModuleId;

			TModuleId addModule(const TModuleName& p_name,
								IModule* const p_module = NULL,
                                Configxml* const p_config = NULL);
			void addDependency(const TModuleName& p_moduleName,
							   const TModuleName& p_dependency,
							   const bool p_optional = false);

			class IBoot
			{
			public:
				struct SModuleBootStatus {
					std::string moduleName;
					IModule::TStartAnswerParam bootStatus;
				};

				typedef std::vector<SModuleBootStatus> ModuleBootStatusSet;

				virtual ~IBoot() {}
				virtual void handleBoot(const ModuleBootStatusSet& p_status) = 0;
			};

			typedef std::vector<std::string> ModuleNameSet;
			
			void requestBoot(IBoot* const p_handler);
			void requestBoot(const ModuleNameSet& p_modules,
							 IBoot* const p_handler);

			class IStop
			{
			public:
				struct SModuleStopStatus {
					std::string moduleName;
				};

				typedef std::vector<SModuleStopStatus> ModuleStopStatusSet;

				virtual ~IStop() {}
				virtual void handleStop(const ModuleStopStatusSet& p_status) = 0;
			};

			void requestStop(IStop* const p_handler);
			void requestStop(const ModuleNameSet& p_modules,
							 IStop* const p_handler);

		private:
			enum EStatus {
				STATUS_IDLE,
				STATUS_READY,
				STATUS_BOOTING,
				STATUS_BOOTED,
				STATUS_STOPPING
			};			
			EStatus m_status;
			
			TModuleId m_nextModuleId;

			typedef std::vector<TModuleId> ModuleIdSet;

			class ModuleDesc
			{
			public:
				TModuleName moduleName;
				TModuleId moduleId;
				IModule* moduleInterface;
                Configxml* moduleConfig;
				
				/*
				 * Depency means a direct link in the graph : A depends on B if such a dependency
				 * has been explicitly stated by a call to addDependency().
				 */
				ModuleIdSet backwardDependencies; // Set of ids of modules this module depends on
				ModuleIdSet forwardDependencies; // Set of ids of modules depending on this module
			};

			typedef std::map<TModuleName, ModuleDesc*> ModuleByNameMap;
			ModuleByNameMap m_moduleByNameMap;

			typedef std::map<TModuleId, ModuleDesc*> ModuleByIdMap;
			ModuleByIdMap m_moduleByIdMap;

			ModuleDesc* findModule(const TModuleName& p_name);
			ModuleDesc* findModule(const TModuleId& p_id);
			ModuleDesc* newModule(const TModuleName& p_name,
								  IModule* const p_module,
                                  Configxml* const p_config);
			void deleteModule(const TModuleName& p_name);
			void addBackwardDepency(ModuleDesc* const p_desc,
									const TModuleId& p_depId);
			void addForwardDepency(ModuleDesc* const p_desc,
								   const TModuleId& p_depId);
			void removeBackwardDepency(ModuleDesc* const p_desc,
									   const TModuleId& p_depId);
			void removeForwardDepency(ModuleDesc* const p_desc,
									  const TModuleId& p_depId);
			void bootModule(const TModuleId p_moduleId);
			void moduleStarted(const TModuleId p_moduleId);
			void moduleFailed(const TModuleId p_moduleId,
							  const std::string& p_reason);
			void bootFinished();
			void shutdownModule(const TModuleId p_moduleId);
			void moduleStopped(const TModuleId p_moduleId);
			void shutdownFinished();

			class ModuleStartedHandler
				: public nettone::tools::IModule::IStart
			{
			public:
				ModuleStartedHandler(const unsigned short p_moduleId,
									 Bootstrapper* const p_this)
					: m_moduleId(p_moduleId),
					  m_this(p_this)
				{
				}

				virtual void answerStart(IModule::TStartAnswerParam const& p_param);

				const unsigned short m_moduleId;
				Bootstrapper* const m_this;
			};
			friend class ModuleStartedHandler;

			class ModuleStoppedHandler
				: public nettone::tools::IModule::IStop
			{
			public:
				ModuleStoppedHandler(const unsigned short p_moduleId,
									 Bootstrapper* const p_this)
					: m_moduleId(p_moduleId),
					  m_this(p_this)
				{
				}

				virtual void answerStop(IModule::TStopAnswerParam const& p_param);

				const unsigned short m_moduleId;
				Bootstrapper* const m_this;
			};
			friend class ModuleStoppedHandler;

			typedef std::map<TModuleId, unsigned short> ModuleDepenciesCounterMap;
			ModuleDepenciesCounterMap m_moduleDepCounter;

			unsigned short m_moduleToStartCount;

			ModuleIdSet m_startedModules;

			IBoot* m_handler;
			IBoot::ModuleBootStatusSet m_bootResult;

			IStop::ModuleStopStatusSet m_stopResult;
			IStop* m_shutdownHandler;
			
			std::unique_ptr<ServerDeferred> m_taskProc;
		};
	}
}


#endif // __NETTONE_TOOLS_BOOTSTRAPPER_H__
