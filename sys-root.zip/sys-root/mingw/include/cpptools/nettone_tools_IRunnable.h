/* 
 * File:   nettone_tools_IRunnable.h
 * Author: nicolas
 *
 * Created on 14 octobre 2010, 14:14
 */

#ifndef __NETTONE_TOOLS_IRUNNABLE_H__
#define	__NETTONE_TOOLS_IRUNNABLE_H__


namespace nettone
{
    namespace tools
    {
        class IRunnable
        {
        public:
            virtual ~IRunnable() {}
            virtual void run() = 0;
        };
    }
}


#endif	// __NETTONE_TOOLS_IRUNNABLE_H__

