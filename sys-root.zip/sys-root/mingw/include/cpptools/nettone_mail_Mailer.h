#ifndef __NETTONE_MAIL_MAILER_H__
#define __NETTONE_MAIL_MAILER_H__


#include <mailutils/mailer.h>
#include <mailutils/registrar.h>
#include <mailutils/message.h>

#include <cpptools/nettone_tools_Exception.h>


namespace nettone
{
    namespace mail
    {
        class Message;

        /**
         * Class used to create an email
         */
        class Mailer
        {
        public:
            /**
             * Constructor for smtp use
             */
            Mailer(const std::string& p_smtpAddr)
                throw(nettone::tools::Exception);

            /**
             * Constructor for sendmail use
             */
            Mailer()
                throw(nettone::tools::Exception);


            ~Mailer()
                throw();

            /**
             * Send an email
             *
             * @param p_msg Email to send
             */
            void send(const nettone::mail::Message& p_msg)
                throw(nettone::tools::Exception);

            /**
             * Send an email
             *
             * @param p_msg   Email to send
             * @param p_from  Message sender
             * @param p_to    Message receiver
             */
            void send(const mu_message_t p_msg,
                      const mu_address_t p_from,
                      const mu_address_t p_to)
                throw(nettone::tools::Exception);

            /**
             * Create a mu_message to send from a nettone::mail::Message
             */
            static mu_message_t createMessageForSend(const nettone::mail::Message& p_msg)
                throw(nettone::tools::Exception);

        private:
            /// @name Forbidden methods
            /// @{
            Mailer(const Mailer& p_other);
            const Mailer& operator =(const Mailer& p_other);
            /// @}
        };
    }
}


#endif // __NETTONE_MAIL_MAILER_H__
