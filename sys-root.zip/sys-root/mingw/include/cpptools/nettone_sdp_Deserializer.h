#ifndef __NETTONE_SDP_DESERIALIAZER__
#define __NETTONE_SDP_DESERIALIAZER__


#include <string.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace sdp
	{
		class SDP;
		class Media;

		/**
		 * Class used for deserialized a SDP
		 * ie: std::string sdp -> nettone::sdp::SDP
		 */
		class Deserializer
		{
		public:
			enum Field {
				e_fieldVersion,
				e_fieldOrigin,
				e_fieldSession,
				e_fieldInformation,
				e_fieldConnection,
				e_fieldTime,
				e_fieldAttribute,
				e_fieldMedia,
				e_fieldCodec
			};


			class IErrorParameter
			{
			public:
				enum KindOfError {
					/// Misplaced filed
					e_errMisplaced,
					/// Already existant field
					e_errAlreadyExist,
					/// Undecodable field
					e_errUndecodable,
					/// Missing parameter
					e_errMissing
				};

				virtual ~IErrorParameter() {}
				
				/** 
				 * Handler called for error in argument
				 * 
				 * @param p_error	kind of error
				 * @param p_kind	problematic field
				 * @param p_line	line in error
				 * @param p_sdp		sdp in decoding process
				 * @param p_media	media in error (could be NULL)
				 */
				virtual void handler(const KindOfError p_error,
									 const Field p_kind,
									 const std::string& p_line,
									 SDP* p_sdp,
									 Media* p_media)
					throw (nettone::tools::Exception) = 0;
			};				

			/**
			 * Constructor.
			 */
			Deserializer()
				throw();

			/**
			 * Destructor.
			 */
			~Deserializer()
				throw();

			/**
			 * Transform string to class SDP
			 */
			SDP* deserialize(const std::string p_data,
							 IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);
			
			/**
			 * Get string associated to field
			 */
			static const char* field2str(const Field p_field)
				throw();

		private:
			/** 
			 * Get next line
			 * 
			 * @param p_data	parse this sdp' data
			 * @param p_fromPos	start parsing at this position, will be modify to indicate next position
			 *
			 * @exception nettone::tools::Exception No line decoded
			 */
			struct SdpLine {
				/**
				 * Kind of line "<char>="
				 */
				char kind;

				/**
				 * line data (right part)
				 */
				std::string data;
			};
			SdpLine getNextLine(const std::string p_data, 
								unsigned long& p_fromPos)
				throw (nettone::tools::Exception);

			/** 
			 * Get next param
			 * 
			 * @param p_line			line to parse
			 * @param p_sep				used separator
			 * @param p_fromPos			start parsing at this position, will be modify to indicate next position
			 * @param p_endOfLineAsSep	deal end of line as seperator
			 *
			 * @exception nettone::tools::Exception if can't found separator
			 */
			std::string getNextParam(const std::string p_line, 
									 const char p_sep,
									 unsigned long& p_fromPos,
									 bool p_endOfLineAsSep = true)
				throw (nettone::tools::Exception);
			
			/**
			 * Decode ProtoVersion
			 *
			 * @param p_line	line to decode
			 */
			void decodeProtoVersion(const std::string& p_line,
									SDP* const p_sdp,
									IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Origin
			 *
			 * @param p_line	line to decode
			 */
			void decodeOrigin(const std::string& p_line,
							  SDP* const p_sdp,
							  IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Session
			 *
			 * @param p_line	line to decode
			 */
			void decodeSession(const std::string& p_line,
							   SDP* const p_sdp,
							   IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Information
			 *
			 * @param p_line	line to decode
			 * @param p_media	paramaters associated to media, if null associated to sdp
			 */
			void decodeInformation(const std::string& p_line,
								   SDP* const p_sdp,
								   Media* const p_media,
								   IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Connection
			 *
			 * @param p_line	line to decode
			 * @param p_media	paramaters associated to media, if null associated to sdp
			 */
			void decodeConnection(const std::string& p_line,
								  SDP* const p_sdp,
								  Media* const p_media,
								  IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Time
			 *
			 * @param p_line	line to decode
			 */
			void decodeTime(const std::string& p_line,
							SDP* const p_sdp,
							IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Attributes
			 *
			 * @param p_line	line to decode
			 * @param p_media	paramaters associated to media, if null associated to sdp
			 */
			void decodeAttributes(const std::string& p_line,
								  SDP* const p_sdp,
								  Media* const p_media,
								  IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode AttrCodec
			 *
			 * @param p_data	data to decode
			 * @param p_sdp		sdp to fill
			 * @param p_media	paramaters associated to media, if null associated to sdp
			 */
			void decodeAttrCodec(const std::string& p_data,
								 SDP* const p_sdp,
								 Media* const p_media,
								 IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);

			/**
			 * Decode Media
			 *
			 * @param p_line	line to decode
			 */
			void decodeMedia(const std::string& p_line,
							 SDP* const p_sdp,
							 IErrorParameter* p_iErrorParameter)
				throw (nettone::tools::Exception);
		};
	}
}


#endif // __NETTONE_SDP_DESERIALIAZER__
