#ifndef __NETTONE_TOOLS_CONFIGXMLUTIL_H__
#define  __NETTONE_TOOLS_CONFIGXMLUTIL_H__


#include "nettone_tools_Configxml.h"


namespace nettone 
{
	namespace tools
	{
		class ConfigxmlUtil
		{
		public:
 			/**
			 * Retrieve an integer entry using xpath
			 *
			 * @param p_conf Objet Configxml
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 *
			 * @param p_default Default value to be returned in case error 
			 *
			 * @return Integer result of given Xpath
			 */
			static unsigned long getULong(const Configxml* p_conf,
										  const std::string& p_xpath,
										  const unsigned long p_default)
				throw ();
			
			/**
			 * Retrieve an text entry using xpath
			 *
			 * @param p_filename File XML to be parsed
			 *
			 * @param p_xpath Xpath to the element to be retrieved
			 *
			 * @param p_default Default value to be returned in case error 
			 *
			 * @return Text result of given Xpath
			 */
			static std::string getText(const Configxml* p_conf,
									   const std::string& p_xpath,
									   const std::string& p_default)
				throw ();

			
		private:
			/// @name Forbidden methods
			/// @{
			ConfigxmlUtil();
			~ConfigxmlUtil();
			/// @}
		};
	}
}

#endif //  __NETTONE_TOOLS_CONFIGXMLUTIL_H__
