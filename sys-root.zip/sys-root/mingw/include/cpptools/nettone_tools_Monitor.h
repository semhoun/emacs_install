#ifndef __nettone_tools_Monitor_h__
#define __nettone_tools_Monitor_h__


#include <pthread.h>

#include "nettone_tools_AutoLock.h"
#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		class Mutex;
		class Cond;


		/**
		 * A simple implementation of the "monitor" concept.
		 */
		class Monitor
		{
		public:
			/**
			 * Constructor.
			 */
			Monitor()
				throw (Exception);

			/**
			 * Destructor.
			 */
			virtual ~Monitor()
				throw ();

			/**
			 * Try to acquire the monitor.
			 * Wait if the monitor is already locked.
			 */
			void lock()
				throw (Exception);

			/**
			 * Release the monitor.
			 */
			void unlock()
				throw (Exception);

			/**
			 * Wait for the monitor to be released.
			 */
			void wait()
				throw (Exception);

			/**
			 * Same as wait, but wait is limited in time.
			 *
			 * @param p_milli Delay in millisecond.
			 *
			 * @retval true  The delay has expired before the condition
			 *               has been signaled
			 * @retval false The condition has been signaled before timeout.
			 */
			bool timedWait(const unsigned long p_milli) throw (Exception);

			/**
			 * Signal the monitor to ONE waiting thread.
			 */
			void signal()
				throw (Exception);

			/**
			 * Signal the monitor to all waiting threads.
			 */
			void broadcast()
				throw (Exception);

		private:
			/// @name Forbidden methods
			/// @{
			Monitor(const Monitor& p_other);
			const Monitor& operator =(const Monitor& p_other);
			/// @}

			/**
			 * The lock controlling access to the monitor.
			 */
			Mutex* m_mutex;

			/**
			 * Condition variable managed by the monitor.
			 */
			Cond* m_cond;
		};

		/**
		 * Automatic tool for monitor get/release
		 */
		typedef AutoLock<Monitor> AutoMonitor;
	}
}


#endif // __nettone_tools_Monitor_h__
