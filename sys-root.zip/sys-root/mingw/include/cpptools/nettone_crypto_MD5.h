#ifndef __NETTONE_CRYPTO_MD5_H__
#define __NETTONE_CRYPTO_MD5_H__

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace crypto
	{
		/**
		 * MD5 crypto 
		 */
		class MD5
		{
		public:
			static std::string hash(const std::string& p_password)
				throw();
			
		};
	}
}


#endif // __NETTONE_CRYPTO_MD5_H__
