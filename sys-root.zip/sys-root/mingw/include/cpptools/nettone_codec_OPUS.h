#ifndef __KERTEL_CONVERTER_OPUS_TO_PCM_FLAG__
#define __KERTEL_CONVERTER_OPUS_TO_PCM_FLAG__

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@ Includes
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#include <string.h>
#include <math.h>

#include "nettone_codec_identifiers.h"
#include "nettone_error_codes.h"
#include "nettone_codec_Generic.h"
#include <opus/opus.h>


namespace nettone {
	namespace codec {

		//========================================================================================
		// Opus timestamp increment rules
		//========================================================================================
		// Audio sampling frequency (Hz) : 2.5 ms	=> Timestamp += 120
		// Audio sampling frequency (Hz) : 5   ms	=> Timestamp += 240
		// Audio sampling frequency (Hz) : 10  ms	=> Timestamp += 480
		// Audio sampling frequency (Hz) : 20  ms	=> Timestamp += 960 ; <--- normal case ----
		// Audio sampling frequency (Hz) : 40  ms	=> Timestamp += 1920
		// Audio sampling frequency (Hz) : 60  ms	=> Timestamp += 2880

		//========================================================================================
		// Constants for codec OPUS
		//========================================================================================
		const int32_t	OPUS_WEBRTC_SAMPLE_RATE								= 48000;//48000;
		const int32_t	OPUS_TELEPHONY_SAMPLE_RATE							= 8000; //8000;

		const int32_t	OPUS_WEBRTC_NB_CHANNEL								= 2;//2;
		const int32_t	OPUS_TELEPHONY_NB_CHANNEL							= 1;//2;

		const int32_t	OPUS_DEFAULT_APPLICATION_TYPE						= OPUS_APPLICATION_VOIP; // 2048=voip, 2049=audio (music)
		const int32_t	OPUS_DEFAULT_ENCODER_BITRATE						= 64000;

		const uint32_t	OPUS_COMPRESSED_OFFICIAL_MAX_SIZE_IN_INT8			= 1500;
		const uint32_t	OPUS_COMPRESSED_KERTEL_MAX_SIZE_IN_INT8				= OPUS_COMPRESSED_OFFICIAL_MAX_SIZE_IN_INT8 * 2;

		const int32_t	OPUS_UNCOMPRESSED_AS_PCM_OFFICIAL_MAX_FRAME_SIZE	= 5760;
		const uint32_t	OPUS_UNCOMPRESSED_AS_PCM_KERTEL_MAX_FRAME_SIZE		= OPUS_UNCOMPRESSED_AS_PCM_OFFICIAL_MAX_FRAME_SIZE * 2;

		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// @@ Generic functions
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		void CheckValidityOfDestBufferSizeInInt16OpusToPcm	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt16, uint32_t& p_MinimumExpectedSizeInInt16);
		void CheckValidityOfDestBufferSizeInUint8PcmToOPUS	(int32_t& p_Iret, uint32_t p_DestBufferSizeInInt8, uint32_t& p_MinimumExpectedSizeInInt8);

		// *** Warning: Since Opus is a stateful codec, the encoding process starts with creating an encoder
		// state. An encoder state must not be used for more than one stream at the same time. 
		// Similarly, the encoder state must not be re-initialized for each frame.
		// ( the function 'opus_encoder_create' allocates memory for the state)
		//
		// Opus is a stateful codec with overlapping blocks and as a result Opus
		// packets are not coded independently of each other. Packets must be
		// passed into the decoder serially and in the correct order for a correct
		// decode. Lost packets can be replaced with loss concealment by calling
		// the decoder with a null pointer and zero length for the missing packet.
		class CConverterOPUSToPcm : public CConverterXXX
		{
		private:
			CConverterOPUSToPcm (const CConverterOPUSToPcm&) throw ();				// forbid copy
			CConverterOPUSToPcm& operator= (const CConverterOPUSToPcm&) throw (); 	// forbid copy

			uint8_t				m_RtpPayloadType;
			OpusDecoder *		m_OpusDecoderPtr;
			int32_t				m_LastOpusError;

		public:
			CConverterOPUSToPcm () throw ();
			~CConverterOPUSToPcm () throw ();
			void	Reset () throw ();
			void BeginConversion (int32_t& p_Iret, uint8_t p_RtpPayloadType) throw ();

			int32_t ConvertBufferFromOPUSToPcm(uint8_t *	p_EncodedData,
				uint32_t	p_EncodedDataLen,
				int16_t *	p_DecodedData,
				uint32_t	p_DecodedBufferSizeInInt16,
				uint32_t&	p_DecodedDataLenInInt16) throw ();

			void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
		};


		// *** Warning: Since Opus is a stateful codec, the encoding process starts with creating an encoder
		// state. An encoder state must not be used for more than one stream at the same time. 
		// Similarly, the encoder state must not be re-initialized for each frame.
		// ( the function 'opus_encoder_create' allocates memory for the state)
		//
		// Opus is a stateful codec with overlapping blocks and as a result Opus
		// packets are not coded independently of each other. Packets must be
		// passed into the decoder serially and in the correct order for a correct
		// decode. Lost packets can be replaced with loss concealment by calling
		// the decoder with a null pointer and zero length for the missing packet.
		class CConverterPcmToOPUS : public CConverterXXX
		{
		private:
			CConverterPcmToOPUS (const CConverterPcmToOPUS&) throw ();				// forbid copy
			CConverterPcmToOPUS& operator= (const CConverterPcmToOPUS&) throw ();	// forbid copy

			uint8_t				m_RtpPayloadType;

			OpusEncoder		*	m_OpusEncoderPtr;
			int32_t				m_LastOpusError;

		public:
			CConverterPcmToOPUS () throw ();
			~CConverterPcmToOPUS () throw ();
			void	Reset () throw ();
			void BeginConversion (int32_t& p_Iret, uint8_t p_RtpPayloadType) throw ();

			int32_t ConvertBufferFromPcmToOPUS(int16_t *	p_EncodedData,
				uint32_t	p_EncodedDataLenInInt16,
				uint8_t *	p_DecodedData,
				uint32_t	p_DecodedBufferSizeInByte,
				uint32_t&	p_DecodedDataLen) throw ();

			void	EndConversion	(int32_t& p_Iret, const char * p_From) throw ();
		};

	}// namespace codec
} // namespace nettone

#endif // __KERTEL_CONVERTER_OPUS_TO_PCM_FLAG__