#ifndef __NETTONE_TOOLS_BOOTSTRAPPERLOADER_H__
#define __NETTONE_TOOLS_BOOTSTRAPPERLOADER_H__


#include <string>

#include "cpptools/nettone_tools_Bootstrapper.h"
#include "cpptools/nettone_tools_IModuleFactory.h"


namespace nettone
{
	namespace tools
	{
		class BootstrapperLoader
		{
		public:
			BootstrapperLoader(IModuleFactory* const p_factory);

			void loadFromXmlFile(Bootstrapper* const p_bootstrapper,
								 const std::string& p_filename);

		private:
			BootstrapperLoader(const BootstrapperLoader& p_other);
			const BootstrapperLoader& operator =(const BootstrapperLoader& p_other);
			
			IModuleFactory* const m_factory;
		};
	}
}


#endif // __NETTONE_TOOLS_BOOTSTRAPPERLOADER_H__
