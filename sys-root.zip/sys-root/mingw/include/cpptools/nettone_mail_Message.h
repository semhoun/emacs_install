#ifndef __NETTONE_MAIL_MESSAGE_H__
#define __NETTONE_MAIL_MESSAGE_H__


#include <mailutils/message.h>
#include <mailutils/address.h>

#include <cpptools/nettone_tools_Exception.h>


namespace nettone
{
	namespace mail
	{
		class Mailer;
		class ServerMailer;

		/**
		 * Class used to create an email
		 */
		class Message
		{
			friend class Mailer;
			friend class ServerMailer;

		public:
			/**
			 * Constructor
			 */
			Message()
				throw(nettone::tools::Exception);

			~Message()
				throw();

			/**
			 * Init from draft
			 */
			void initFromDraft(const std::string& p_draft)
				throw(nettone::tools::Exception);

			/** 
			 * Set the message from
			 * 
			 * @param p_from Message sender mail
			 */
			void setFrom(const std::string& p_from)
				throw(nettone::tools::Exception);

			/** 
			 * Set the message to 
			 * 
			 * @param p_from Message receiver
			 */
			void setTo(const std::string& p_to)
				throw(nettone::tools::Exception);

			/** 
			 * Set the message subject
			 * 
			 * @param p_subject Message subject
			 */
			void setSubject(const std::string& p_subject)
				throw(nettone::tools::Exception);

			/** 
			 * Set the message body
			 * 
			 * @param p_body Message body
			 */
			void setBody(const std::string& p_body)
				throw(nettone::tools::Exception);

			/**
			 * King of attachment
			 */
			enum MimeType {
				e_mtApplicationOctet,
				e_mtApplicationRar,
				e_mtApplicationZip,
				e_mtApplicationExecutable,
				e_mtApplicationPdf,
				e_mtAudioMpeg,
				e_mtAudioGSM,
				e_mtAudioWave,
				e_mtImageGif,
				e_mtImageJpeg,
				e_mtImagePng,
				e_mtImageTiff,
				e_mtTextHtml,
				e_mtTextPlain,
				e_mtVideoMpeg
			};
					
			/** 
			 * Add a file to email, attachment must be added in last
			 * 
			 * @param p_name file name
			 * @param p_data data to add (not base64 encoded)
			 * @param p_size size of data
			 */
			void addAttachment(const std::string& p_name,
							   const char* p_data,
							   const unsigned long p_size,
							   const MimeType p_mime = e_mtApplicationOctet)
				throw(nettone::tools::Exception);

		private:
			/// @name Forbidden methods
			/// @{
			Message(const Message& p_other);
			const Message& operator =(const Message& p_other);
			/// @}
			
			/**
			 * Mail message
			 */
			mu_message_t m_message;
			
			/**
			 * From address
			 */
			mu_address_t m_from;

			/**
			 * To Address
			 */
			mu_address_t m_to;

			/**
			 * Message subject
			 */
			std::string m_subject;
		};
	}
}


#endif // __NETTONE_MAIL_MESSAGE_H__
