#pragma once

#include <mutex>
#include <thread>
#include <list>
#include <string>
#include <deque>
#include <vector>
#include <condition_variable>

#include "cpptools/nettone_http_HttpRequestor.h"

// note: nested namespaces are C++17 feature
//
namespace nettone::http
{
	class ServerHttpClient
	{
	public:
		struct Config
		{
			/**
			 * Ideal number of requests processors
			 */
			uint8_t nbProcessors;

			/**
			 * Minimal number of requestor processsors
			 */
			uint8_t nbProcessorsRequired;

			/**
			 * Max of pending requests
			 */
			uint32_t nbMaxPendingRequests;

			/**
			 * LdapRequestor configuration
			 */
			HttpRequestor::Config requestorConf;

		}; // struct Config

		/**
		 * Type of the request ID
		 */
		class RequestId
		{
		public:
			/**
			 * the null object
			 */
			static const RequestId null;

			/**
			 * Return a new unique RequestId object.
			 * Value loops 32 bits unsigned
			 */
			static RequestId getNewId()
				throw();

			/**
			 * Constructor
			 */
			RequestId()
			throw();

			/**
			 * Casting to an unsigned long
			 */
			operator unsigned long() const
			throw();

			/**
			 * Comparison operator
			 */
			bool operator ==(const RequestId& p_other)
				throw();

			/**
			 * Comparison operator
			 */
			bool operator !=(const RequestId& p_other)
				throw();

			/**
			 * Assigment operator
			 */
			const RequestId& operator =(const RequestId& p_other)
				throw();

		private:
			/*²*
			 * Constructor
			 */
			RequestId(const unsigned long p_reqId)
				throw();
			/**
			 * the id itself
			 */
			unsigned long m_reqId;

		}; // class RequestId

		class RequestProcessor
		{
		public:
			/*
			**
			* Constructor
			*
			* @param p_this the outter object
			*/
			explicit RequestProcessor(ServerHttpClient* const p_this)
				noexcept(true);

			/**
			 *  Destructor
			 */
			~RequestProcessor()
			noexcept(true);

			/**
			 *  Starting thread processor
			 */
			void start()
				noexcept(false);

			/**
			 * Stopping thread processor
			 */
			void stop()
				noexcept(false);

			/**
			 * Internal task to run
			 */
			void run()
				noexcept(true);

			/**
			 * Request to join internal thread
			 **/
			void join()
				noexcept(false);

			/**
			 * Flag used to stop running thread
			 */
			bool m_mustStop;

			HttpRequestor m_httpRequestor;

			/**
			 * C++11 thread
			 */
			std::thread m_thread;

			/**
			 *  Outter object
			 */
			ServerHttpClient* m_this;
		};

		/**
		 * Base definition of handler
		 */
		class HandlerHttpRequestBase
		{
		public:
			/**
			 *   Destructor
			 */
			virtual ~HandlerHttpRequestBase() {}

			/**
			 * Callback invoked on error on the server side
			 *
			 * @param p_reqId Id of the erroneous request
			 * @param p_error text of the error
			 */

			virtual void handleError(const nettone::http::ServerHttpClient::RequestId& p_reqId,
									 const std::string& p_error)
				noexcept(true);

			uint8_t m_statusCode;
		};

		/**
		 * Interface definition to handle response
		 */
		class IHandlerHttpRequest : public HandlerHttpRequestBase
		{
		public:
			/**
			 *   Destructor
			 */
			virtual ~IHandlerHttpRequest() {}

			/**
			 * Callback method called when the request has been successfully processed.
			 *
			 * @param p_result the extracted data
			 */

			virtual void handleResponse(const nettone::http::ServerHttpClient::RequestId& p_reqId,
										const nettone::http::HttpRequestor::Response& p_response)
				noexcept(true) = 0;
		};

		/**
		 * That struct contains informations to process Request
		 */
		struct IBaseRequest
		{
			/**
			 * Url endpoint
			 */
			std::string url;

			/**
			 * Headers
			 */
			nettone::http::HttpRequestor::RequestHeaders headers;

			/**
			 *  Method used for http request
			 */
			nettone::http::HttpRequestor::Method method;

			/**
			 * Some data
			 */
			std::string json;

			/**
			 * Used or not to process Http auth
			 */
			HttpRequestor::HttpAuth httpAuth;

			/**
			 * Id of the request
			 */
			RequestId requestId;

			/**
			 *  Identifcator of the reply;
			 */
			void*  key;

			IHandlerHttpRequest* errorHandler;

			/**
			 *  Explicit constructor
			 */
			explicit IBaseRequest(const std::string& p_url,
								  const nettone::http::HttpRequestor::RequestHeaders& p_headers,
								  const nettone::http::HttpRequestor::Method& p_method,
								  const std::string& p_json,
								  void* p_key);

			/**
			 * Virtual destructor
			 */
			virtual ~IBaseRequest();

			/**
			 * Method to implement
			 */
			virtual void process(ServerHttpClient* const p_server, nettone::http::HttpRequestor* p_requestor)
				noexcept(false) = 0;

		}; // class Request

		/**
		 * class that contains function to process Request
		 */
		class InternalRequest : public IBaseRequest
		{
		public:
			/**
			 * Constructor.
			 *
			 * @param p_query   The SQL query.
			 * @param p_key     The key identifying the request.
			 * @param p_handler The handler of result.
			 */
			InternalRequest(const std::string p_url,
							const nettone::http::HttpRequestor::RequestHeaders& p_headers,
							const nettone::http::HttpRequestor::Method& p_method,
							const std::string& p_json,
							void* const p_key,
							IHandlerHttpRequest* const p_handler)
				noexcept(true);

			/**
			 * Virtual destructor
			 */
			virtual ~InternalRequest();

		private:
			/// @name Methods from RequestBase
			/// @{
			virtual void process(ServerHttpClient* const p_server, nettone::http::HttpRequestor* p_requestor)
				noexcept(false);
			/// @}

			//HttpRequestor m_httpRequestor;
			/**
			 * Callback handler.
			 */
			IHandlerHttpRequest* const m_handler;
		};

		/**
		 * Constructor
		 */
		ServerHttpClient()
		noexcept(false);

		/**
		 *  Destructor
		 */
		~ServerHttpClient()
		noexcept(false);

		/**
		 * Start the server
		 *
		 * @param_p config the runtime configuration
		 */
		void start(const Config& p_config)
			noexcept(false);

		/**
		 * Stop the server
		 */
		void stop()
			noexcept(false);

		/**
		 * Send the query
		 */
		void sendRequest(ServerHttpClient::RequestId& p_reqId,
						 const std::string p_url,
						 const nettone::http::HttpRequestor::RequestHeaders& p_header,
						 const nettone::http::HttpRequestor::Method p_method,
						 const std::string& p_json,
						 IHandlerHttpRequest* const p_handler)
			noexcept(false);

		/**
		 * Send query with auth http
		 */
		void sendRequest(ServerHttpClient::RequestId& p_reqId,
						 const std::string p_url,
						 const nettone::http::HttpRequestor::HttpAuth& p_auth,
						 const nettone::http::HttpRequestor::RequestHeaders& p_headers,
						 const nettone::http::HttpRequestor::Method p_method,
						 const std::string& p_content,
						 IHandlerHttpRequest* const p_handler)
			noexcept(false);
		/**
		 * Send query with auth http
		 */
		void sendRequest(ServerHttpClient::RequestId& p_reqId,
						 const std::string p_url,
						 const nettone::http::HttpRequestor::HttpAuth& p_auth,
						 const nettone::http::HttpRequestor::RequestHeaders& p_headers,
						 const std::string& p_content,
						 IHandlerHttpRequest* const p_handler)
			noexcept(false);

		/**
		 * Flag that show if server is running
		 */
		bool isRunning()
			noexcept(true);
	private:
		/**
		 * Internal function to post request in deque
		 */
		void postRequest(RequestId& p_reqId,
						 IBaseRequest* const  p_request)
			noexcept(false);

		/**
		 * Flag used to know if server is running
		 */
		bool m_isRunning;

		/**
		 * Condiational variable used to process work when a request is added in deque
		 */
		std::condition_variable m_condVar;

		/**
		 * Mutex used to protect deque
		 */
		std::mutex m_mutex;

		/**
		 * Deque that handle requuets
		 */
		std::deque<IBaseRequest*> m_requests;

		/**
		 * Thread processors that handles requests
		 */
		std::vector<RequestProcessor*> m_procs;

		/**
		 * Server Configuraiton
		 */
		Config m_config;

	}; // class Server implemention

} // namespace nettone::http
