#ifndef __NETTONE_TOOLS_SYNCHRO_H__
#define __NETTONE_TOOLS_SYNCHRO_H__


#include <memory>

#include "nettone_tools_Monitor.h"


namespace nettone
{
	namespace tools
	{
		class Monitor;

		/**
		 * Helper base class used to synchronize asynchronous processing.
		 */
		class Synchro
		{
		public:
			class TimeoutException
				: public Exception
			{
			public:
				TimeoutException(const std::string& p_errorText) throw ();
			};
				
			/**
			 * Constructor.
			 */
			Synchro()
				throw (nettone::tools::Exception);

			/**
			 * Destructor.
			 */
			virtual ~Synchro() {}

			/**
			 * Start the synchronous sequence.
			 * Call doAsynCall(), then wait for completion (notified by a call to release()).
			 *
			 * @retval true  the asynchronous call has been posted and we can wait for completion. 
			 * @retval false the asynchronous has not been posted (because of an immediate answer, e.g.)
			 */
			bool start(const unsigned long p_delay = 0)
				throw (TimeoutException, nettone::tools::Exception);

		protected:
			/**
			 * Method starting the asynchronous call.
			 * Called from start().
			 *
			 * @retval true  the asynchronous call has been posted and we can wait for completion. 
			 * @retval false the asynchronous has not been posted (because of an immediate answer, e.g.)
			 */
			virtual bool doAsynCall()
				throw (nettone::tools::Exception) = 0;

			/**
			 * Method releasing the lock positionned in the start method. 
			 * Usually called from the handler of the asynchronous call 
			 * initiated in doAsynCall().
			 */
			void release()
				throw ();

			/**
			 * Lock use to transform the asynchronous operation in a synchronous call.
			 */
			std::unique_ptr<nettone::tools::Monitor> m_monitor;
            bool m_done;
		};
	}
}


#endif // __NETTONE_TOOLS_SYNCHRO_H__
