#ifndef __NETTONE_TOOLS_DAEMONIZER_H__
#define __NETTONE_TOOLS_DAEMONIZER_H__


namespace nettone
{
	namespace tools
	{
		/**
		 * Start an instance of Daemonized in a child process.
		 * Supervise the start phase.
		 */
		template <typename Daemonized>
		class Daemonizer
		{
		public:
			/**
			 * Constructor.
			 */
			Daemonizer();

			/**
			 * Destructor.
			 */
			virtual ~Daemonizer();

			/**
			 * Start a daemonized application, and supervize
			 * the application boot process.
			 *
			 * @see nettone::tools::App
			 */
			virtual int start(const int p_argc,
							  const char* const * const p_argv);

		private:
			/// @name Forbidden methods
			/// @{
			Daemonizer(const Daemonizer& p_other);
			const Daemonizer& operator =(const Daemonizer& p_other);
			/// @}

			/// The daemonized App-like object.
			Daemonized* m_daemon;
		};
	}
}


#include "nettone_tools_Daemonizer.inl"


#endif // __NETTONE_TOOLS_DAEMONIZER_H__
