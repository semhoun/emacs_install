#ifndef __NETTONE_TOOLS_SERVERFILE_H__
#define __NETTONE_TOOLS_SERVERFILE_H__

#include <map>

#include "nettone_tools_Buffer.h"
#include "nettone_tools_Exception.h"
#include "nettone_tools_IdManager.h"


namespace nettone
{
	namespace tools
	{
		class ServerDeferred;

		/**
		 * Server of file.
		 * Process asynchronously file operations.
		 */
		class ServerFile
		{
		public :
			/**
			 * Creation configuration.
			 */
			struct Config
			{
				/**
				 * Max number of pending requests.
				 */
				unsigned short maxPendingRequests;

				/**
				 * Default values for config parameters.
				 */
				enum {
					DEFAULT_MAX_PENDING_REQUESTS = 10
				};
			};

			/**
			 * Constructor.
			 */
			ServerFile()
				throw (Exception);

			/**
			 * Destructor.
			 */
			~ServerFile()
				throw ();

			/**
			 * Start the server.
			 *
			 * @param p_config The runtime configuration.
			 */
			void start(const Config& p_config)
				throw (Exception);
			
			/**
			 * Stop the server.
			 */
			void stop()
				throw ();

			/**
			 * Type of the request ID.
			 */
			class RequestId
			{
			public :
				/**
				 * The null object.
				 */
				static const RequestId null;

				/**
				 * Return a new unique RequestId object.
				 * Value loops on 32 bits unsigned.
				 */
				static RequestId getNewId()
					throw ();

				/**
				 * Constructor.
				 */
				RequestId()
					throw ();

				/**
				 * Casting to a unsigned long.
				 */
				operator unsigned long() const
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator ==(const RequestId& p_other)
					throw ();

				/**
				 * Comparison operator.
				 */
				bool operator !=(const RequestId& p_other)
					throw ();

				/**
				 * Assignement operator.
				 */
				const RequestId& operator =(const RequestId& p_other)
					throw ();

			private :
				/**
				 * Constructor.
				 */
				RequestId(const unsigned long p_reqId)
					throw ();

				/**
				 * The ID itself.
				 */
				unsigned long m_reqId;
			};
			
			/**
			 * Type for file id.
			 */
			typedef unsigned long FileId;
			
			/**
			 * Handler for open file request.
			 */ 
			class IOpen
			{
			public :
				/**
				 * Destructor.
				 */
				virtual ~IOpen()	{}
				
				/**
				 * Callback invoked when the requested file is opened.
				 *
				 * @param p_reqId  		Id of the request.
				 * @param p_filename	Name of opened file.
				 * @param p_fileId 		Id of the opened file.
				 */
				virtual void handleFileOpened(const RequestId& p_reqId,
											  const std::string& p_filename,
											  const FileId& p_fileId)
					throw () = 0;
					
				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId 		Id of the erroneous request
				 * @param p_filename	Name of erroneous file.
				 * @param p_error 		Text of the error
				 */
				virtual void handleFileOpenError(const RequestId& p_reqId,
												 const std::string& p_filename,
												 const std::string& p_error)
					throw () = 0;
			};
			
			/**
			 * Request to open a file.
			 * If the file does not exist, the server creates it.
			 *
			 * @param p_reqId     Where to store the ID of the request.
			 * @param p_filename  Filename to open.
			 * @param p_handler	  Handler on completion.
			 */
			void requestOpenFile(RequestId& p_reqId,
								 const std::string& p_filename, 
								 IOpen* const p_handler)
				throw (nettone::tools::Exception);
		
			/**
			 * Buffer
			 */ 
			typedef Buffer<unsigned char> FileBuf;
			
			/**
			 * Handler for write data in file.
			 */
			class IWrite
			{
			public :
				/**
				 * Destructor.
				 */
				virtual ~IWrite()	{}
				
				/**
				 * Callback invoked when the data have been written in file.
				 *
				 * @param p_reqId  Id of the request.
				 * @param p_buffer	The buffer written in file.
				 *
				 * @note The buffer must be destroyed by handler.
				 */
				virtual void handleWriteSucceeded(const RequestId& p_reqId, 
												  FileBuf* const p_buffer)
					throw () = 0;
					
				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId 	Id of the erroneous request.
				 * @param p_buffer	The buffer written in file.
				 * @param p_error 	Text of the error.
				 *
				 * @note The buffer must be destroyed by handler.
				 */
				virtual void handleWriteFailed(const RequestId& p_reqId,
											   FileBuf* const p_buffer,
											   const std::string& p_error)
					throw () = 0;
			};
			
			/**
			 * Request to write data in file.
			 *
			 * @param p_reqId     Where to store the ID of the request.
			 * @param p_fileId    ID of file where to store data.
			 * @param p_buffer	  Buffer of data to write.
			 * @param p_handler	  Handler on completion.
			 */
			void requestWrite(RequestId& p_reqId,
							  const FileId& p_fileId,
							  FileBuf* const p_buffer,
							  IWrite* const p_handler)
				throw (nettone::tools::Exception);
			
			/**
			 * Handler for close file request.
			 */ 
			class IClose
			{
			public :
				/**
				 * Destructor.
				 */
				virtual ~IClose()	{}
				
				/**
				 * Callback invoked when the requested file is closed.
				 *
				 * @param p_reqId  Id of the request.
				 * @param p_fileId Id of the opened file.
				 */
				virtual void handleFileClosed(const RequestId& p_reqId,
											  const FileId& p_fileId)
					throw () = 0;
					
				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleFileCloseError(const RequestId& p_reqId,
												  const std::string& p_error)
					throw () = 0;
			};
			
			/**
			 * Request to close a file.
			 *
			 * @param p_reqId     Where to store the ID of the request.
			 * @param p_fileId	  ID of file to close.
			 * @param p_handler	  Handler on completion.
			 */
			void requestCloseFile(RequestId& p_reqId, 
								  const FileId& p_fileId,
								  IClose* const p_handler)
				throw (Exception);
			
			/**
			 * Handler for remove file request.
			 */
			class IRemove
			{
			public :
				/**
				 * Destructor.
				 */
				virtual ~IRemove()	{}
				
				/**
				 * Callback invoked when the requested file is removed.
				 *
				 * @param p_reqId  Id of the request.
				 */
				virtual void handleFileRemoved(const RequestId& p_reqId)
					throw () = 0;
					
				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleFileRemoveError(const RequestId& p_reqId,
												   const std::string& p_error)
					throw () = 0;
			};
			
			/**
			 * Request to remove a file.
			 *
			 * @param p_reqId     Where to store the ID of the request.
			 * @param p_fileId	  ID of file to close.
			 * @param p_handler	  Handler on completion.
			 */
			void requestRemoveFile(RequestId& p_reqId, 
								   const FileId& p_fileId, 
								   IRemove* const p_handler = NULL)
				throw (Exception);
			
			/**
			 * Handler for rename request.
			 */
			class IRename
			{
			public :
				/**
				 * Destructor.
				 */
				virtual ~IRename()	{}
				
				/**
				 * Callback invoked when the requested file is renamed.
				 *
				 * @param p_reqId  Id of the request.
				 */
				virtual void handleFileRenamed(const RequestId& p_reqId)
					throw () = 0;
					
				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleFileRenameError(const RequestId& p_reqId,
												    const std::string& p_error)
					throw () = 0;
			};
			
			/**
			 * Request to rename a file.
			 *
			 * @param p_reqId     		Where to store the ID of the request.
			 * @param p_oldFilename		Old finename.
			 * @param p_newFilename 	New filename.
			 * @param p_handler	 		Handler on completion.
			 *
			 * @Must be called when file is closed.
			 */
			void requestRenameFile(RequestId& p_reqId,
								   const std::string& p_oldFilename,
								   const std::string& p_newFilename,
								   IRename* const p_handler)
				throw (Exception);
			
			/**
			 * File statistics
			 */
			struct Stats
			{	
				/**
				 * Size in Bytes (octets fr).
				 */
				unsigned long size;
			};
			
			/**
			 * Handler for  get stats request.
			 */
			class IGetStats
			{
			public :
				/**
				 * Destructor.
				 */
				virtual ~IGetStats()	{}
				
				/**
				 * Callback invoked when the requested stats are obtained.
				 *
				 * @param p_reqId  Id of the request.
				 */
				virtual void handleGetStats(const RequestId& p_reqId, 
											const Stats& p_stats)
					throw () = 0;
					
				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleGetStatsError(const RequestId& p_reqId,
												 const std::string& p_error)
					throw () = 0;
			};
			
			/**
			 * Request to stats of a file.
			 *
			 * @param p_reqId     	Where to store the ID of the request.
			 * @param p_filename	Filename.
			 * @param p_handler	 	Handler on completion.
			 */
			void requestGetStats(RequestId& p_reqId, 
								 const std::string& p_filename, 
								 IGetStats* const p_handler)
				throw (Exception);
			
			/**
			 * Base interface for handlers of request result.
			 */
			class IHandlerLoadFile
			{
			public:
				/**
				 * Destructor.
				 */
				virtual ~IHandlerLoadFile()	{}

				/**
				 * Callback invoked when the requested file is loaded.
				 *
				 * @param p_reqId  Id of the request.
				 * @param p_buffer Buffer containing the loaded file.
				 *
				 * @note The callee is responsible for the objet pointed 
				 *       by p_buffer. It must delete it when no more used.
				 */
				virtual void handleFileLoaded(const RequestId& p_reqId,
											  FileBuf* const p_buffer)
					throw () = 0;

				/**
				 * Callback invoked on error on the server side.
				 *
				 * @param p_reqId Id of the erroneous request
				 * @param p_error Text of the error
				 */
				virtual void handleFileError(const RequestId& p_reqId,
											 const std::string& p_error)
					throw () = 0;
			};

			/**
			 * Load a file.
			 *
			 * @param p_reqId    Where to store the ID of the request.
			 * @param p_filename The name of the file to load.
			 * @param p_handler  The handler to notify on event (error or success).
			 */
			void loadFile(RequestId& p_reqId,
						  const std::string& p_filename,
						  IHandlerLoadFile* const p_handler)
				throw (Exception);
			
		private:
			/// @name Forbidden methods
			/// @{
			ServerFile(const ServerFile& p_other);
			const ServerFile& operator =(const ServerFile& p_other);
			/// @}
			
			/**
			 * File representation.
			 */
			struct File
			{
				/**
				 * File name
				 */
				std::string filename;
				
				/**
				 * Interface to write data to files as output streams.
				 */
				std::ofstream* stream;
			};
			
			/**
			 * Map of opened files.
			 */
			typedef std::map<FileId, File*> OpenedFiles;
			OpenedFiles m_opened;
			
			/**
			 * ID generator
			 */
			std::unique_ptr<IdManager<FileId> > m_idmanager;
			
			/**
			 * Server configuration
			 */
			Config m_config;

			/**
			 * Request processor.
			 */
			std::unique_ptr<ServerDeferred> m_processor;
		};
	}
}


#endif // __NETTONE_TOOLS_SERVERFILE_H__
