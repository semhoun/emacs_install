#ifndef __NETTONE_EVENT_EVENTDISPATCHER_H__
#define __NETTONE_EVENT_EVENTDISPATCHER_H__


#include <map>

#include "cpptools/nettone_event_Event.h"
#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace event
	{
		/**
		 * Dispatch events to observers, based on registrations.
		 * Registration/ungistration and dispatching are SYNCHRONOUS, and
		 * *NOT* thread safe.
		 */
		class EventDispatcher
		{
		public:
			/// @name Construction/Destruction
			/// @{
			EventDispatcher()
				throw ();

			virtual ~EventDispatcher()
				throw ();
			/// @}

			/// @name Observers management
			/// @{
			/**
			 * Interface to implement to be able to observe events.
			 */
			class IObserver
			{
			public:
				virtual ~IObserver() {}

				/**
				 * Method called when an event occurs that the implementor
				 * is registred as an observer.
				 */
				virtual void handleEvent(Event& p_event)
					throw () = 0;
			};

			/**
			 * Register p_observer as an observer of the event specified by p_eventId.
			 *
			 * @param p_eventId  ID of the event to observe.
			 * @param p_observer Observer.
			 */
			void registerObserver(const Event::EventId& p_eventId,
								  IObserver* const p_observer)
				throw (nettone::tools::Exception);
			
			/**
			 * Unregister an observer for an event.
			 *
			 * @param p_eventId  ID of the event to observe.
			 * @param p_observer Observer.
			 */
			void unregisterObserver(const Event::EventId& p_eventId,
									IObserver* const p_observer)
				throw (nettone::tools::Exception);

			/**
			 * Unregister an observer to all event.
			 *
			 * @param p_observer Observer.
			 */
			void unregisterObserver(IObserver* const p_observer)
				throw (nettone::tools::Exception);
			/// @}

			/// @name Method(s) related to event dispatching
			/// @{
			void dispatchEvent(Event& p_event)
				throw (nettone::tools::Exception);
			/// @}
			
		private:
			/**
			 * @var ObserverMap m_observerMap
			 * Map of event observers indexed by event id.
			 */
			typedef std::vector<IObserver*> ObserverSet;
			typedef std::map<Event::EventId, ObserverSet*> ObserverMap;
			ObserverMap m_observerMap;
		};
	}
}


#endif // __NETTONE_EVENT_EVENTDISPATCHER_H__
