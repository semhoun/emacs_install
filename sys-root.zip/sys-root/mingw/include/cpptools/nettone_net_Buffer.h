#ifndef __nettone_net_Buffer__
#define __nettone_net_Buffer__


#include "nettone_tools_Buffer.h"


namespace nettone
{
	namespace net
	{
		/**
		 * @name Aliases for various buffer types.
		 * 
		 * @todo Make some measure to see if the std::vector class can
		 *       be used instead of my custom Buffer template class.
		 */
		/// @{
		typedef nettone::tools::Buffer<char> Buffer;
		/// @}
	}
}


#endif // __nettone_net_Buffer__
