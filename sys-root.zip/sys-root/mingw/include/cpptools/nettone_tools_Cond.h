#ifndef __nettone_tools_Cond_h__
#define __nettone_tools_Cond_h__


#include <pthread.h>

#include "nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		class Mutex;


		/**
		 * Wrapper around pthread condition variables.
		 */
		class Cond
		{
		public:
			/**
			 * Constructor.
			 */
			Cond() throw (Exception);

			/**
			 * Destructor.
			 */
			virtual ~Cond() throw (Exception);

			/**
			 * Wait for the condition to be signaled.
			 * the Mutex object passed as parameter must be locked prior
			 * calling this method.
			 * 
			 * @param p_mutex The mutex associated to the condition.
			 */
			void wait(Mutex& p_mutex) throw (Exception);

			/**
			 * Same as wait, but wait is limited in time.
			 *
			 * @param p_mutex The mutex associated to the condition.
			 * @param p_milli Delay in millisecond.
			 *
			 * @retval true  The delay has expired before the condition
			 *               has been signaled
			 * @retval false The condition has been signaled before timeout.
			 */
			bool timedWait(Mutex& p_mutex,
						   const unsigned long p_milli) throw (Exception);

			/**
			 * Signal the condition to ONE waiting thread.
			 */
			void signal() throw (Exception);

			/**
			 * Signal the condition to all thread.
			 */
			void broadcast() throw (Exception);

		private:
			/// @name Forbidden methods
			/// @{
			Cond(const Cond& p_other);
			const Cond& operator =(const Cond& p_other);
			/// @}

			/// id of the underlying pthread.
			pthread_cond_t m_condId;
		};
	}
}


#endif // __nettone_tools_Cond_h__
