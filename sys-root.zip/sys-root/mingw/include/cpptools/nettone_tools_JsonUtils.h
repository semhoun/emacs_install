#pragma once

#include "json/json.h"
#include "cpptools/nettone_tools_Exception.h"


namespace nettone
{
	namespace tools
	{
		class JsonUtils
		{
		public:
			/**
			 * Convert a string to JSon
			 */
			static Json::Value fromString(const std::string& p_data)
				throw(Exception);

			/**
			 * Serialize a JSon value
			 */
			static std::string toString(const Json::Value& p_json,
										const bool p_compact = true)
				throw(Exception);
		};
	}
}
