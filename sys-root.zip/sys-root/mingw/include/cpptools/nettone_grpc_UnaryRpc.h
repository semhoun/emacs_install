
#ifndef __NETTONE_GRPC_UNARYRPC_H__
#define __NETTONE_GRPC_UNARYRPC_H__

#include <thread>
#include <functional>
#include <algorithm>

#include <grpcpp/grpcpp.h>
#include <grpc/support/log.h>

#include <google/protobuf/message.h>

using grpc::Server;
using grpc::ServerAsyncResponseWriter;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using grpc::ServerCompletionQueue;

namespace nettone
{
	namespace grpc
	{
		namespace UnaryRpc
		{
		// Structure to build specific responder 
		//
		struct BaseResponder
		{
			::grpc::ServerContext* serverContext;
			
			inline virtual ~BaseResponder(){}
		};
		
		// We add a TagProcessor to the completion queue for each event. This way, each tag know to process itself
		//
		using TagProcessor = std::function<void(bool)>;

		struct TagInfo
		{
			// The function to be called to process incoming event
			//
			TagProcessor* tagProcessor;

			// The result of tag processing as indicated by GRPC library. Calling it 'ok' to be  in sync with GRPC examples
			//
			bool ok;
		};

		using TagList = std::list<TagInfo>;

		/**
		 * A base class for various rpc type. with Grpc it is necessary to keep track of pending async operations
		 * Only 1 async operation can be pending at a time with an exception that both async read and write can be pending at the same time 
		 */
		class RpcJob
		{
		public:
			enum AsyncOpType
			{
				ASYNC_OP_TYPE_QUEUED_REQUEST,
				ASYNC_OP_TYPE_READ,
				ASYNC_OP_TYPE_WRITE,
				ASYNC_OP_TYPE_FINISH
			};

			inline RpcJob();
			
			inline virtual ~RpcJob();

			inline void asyncOpStarted(AsyncOpType opType);

			// returns true if the rpc processing should keep going. false otherwise.
			//
			inline bool asyncOpFinished(AsyncOpType opType);

			// Tag processor for the 'done' event of this rpc from gRPC library
			//
			inline void OnDone(bool );

			// Each different rpc type need to implement the specialization of action when this rpc is done.
			//
			virtual void done() = 0;

		private:
		
			int32_t m_asyncOpCounter;

			bool m_asyncReadInProgress;

			bool m_asyncWriteInProgress;

			// In case of an abrupt rpc ending (for example, client process exit), gRPC calls OnDone prematurely even while an async operation is in progress
			// and would be notified later. An example sequence would be
			//
			// 1. The client issues an rpc request.
			// 2. The server handles the rpc and calls Finish with response. At this point, ServerContext::IsCancelled is NOT true.
			// 3. The client process abruptly exits.
			// 4. The completion queue dispatches an OnDone tag followed by the OnFinish tag. If the application cleans up the state in OnDone, OnFinish invocation would result in undefined behavior.
			// This actually feels like a pretty odd behavior of the gRPC library (it is most likely a result of our multi-threaded usage) 
			 //so we account for that by keeping track of whether the OnDone was called earlier.
			// As far as the application is considered, the rpc is only 'done' when no asyn Ops are pending.
			bool m_onDoneCalled;
		}; // END of RpcJob implementation
		
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///
		/// RpcsHandlers definition
		///
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		/**
		 *  The application code communicates with our utlity classes using these handlers
		 */
		template <typename ServiceType, typename RequestType, typename ResponseType>
			struct RpcsHandlers
			{
				// Alias used for Rpc this to inform the application of a new request to be processed
				//
				using ProcessRequestHandlers = std::function<void(ServiceType*, RpcJob*, const RequestType*)>;
				using CreateRpcHandler = std::function<void()>;
				using RpcDoneHandler = std::function<void(ServiceType*, RpcJob*, bool)>;

				using SendResponseHandler = std::function<bool(const ResponseType*)>; // GRPC_TODO - change to a unique_ptr instead to avoid internal copying.
				using RpcContextHandler = std::function<void(ServiceType*, 
															nettone::grpc::UnaryRpc::RpcJob*, 
															::grpc::ServerContext*, 
															SendResponseHandler)>;

				// Rpc calls this to informe  the application of a new request to be processed
				//
				ProcessRequestHandlers processRequest;

				// Rpc calls this to inform th application to create a new Rpc of this type
				//
				CreateRpcHandler createRpcJob;

				// Rpc calls this to inform the application that this job is done now.
				//
				RpcDoneHandler rpcJobDone;

				// Application code to job
				// Rpc calls this to inform the application of the entities it can use to respond to the rpc request.
				RpcContextHandler rpcJobContext;
			};
		
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///
		/// UnaryRpcJobHandlers definition
		///
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		template<typename ServiceType, typename RequestType, typename ResponseType>
			struct UnaryRpcJobHandlers : public RpcsHandlers<ServiceType, RequestType, ResponseType>
			{
			public:
				
				using GrpcResponder = ::grpc::ServerAsyncResponseWriter<ResponseType>;
				using RegisterCall = std::function<void(ServiceType*, ::grpc::ServerContext*, RequestType*, GrpcResponder*,
									::grpc::CompletionQueue*, ::grpc::ServerCompletionQueue*, void *)>;

				RegisterCall registerCall;
			};

		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///
		/// UnaryRpcJob definition
		///
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		template<typename ServiceType, typename RequestType, typename ResponseType>
		class UnaryRpcJob : public RpcJob
		{
			using ThisRpcTypeJobHandlers = UnaryRpcJobHandlers<ServiceType, RequestType, ResponseType>;
			
		public:
			UnaryRpcJob(ServiceType* p_service, 
					   ::grpc::ServerCompletionQueue* p_cq, 
					   ThisRpcTypeJobHandlers p_jobHandlers);

			UnaryRpcJob(ThisRpcTypeJobHandlers p_hand);

		private:

			bool sendResponse(const ResponseType* p_response);
			void onRead(bool ok);
			void onFinish(bool ok);
			void done() override;

		private:

			ServiceType* m_service;
			::grpc::ServerCompletionQueue* m_cq;
			::grpc::ServerContext m_serverContext;
			typename ThisRpcTypeJobHandlers::GrpcResponder m_responder;

			RequestType 	m_request;
			ResponseType 	m_response;
			
			ThisRpcTypeJobHandlers m_handlers;

			typename ThisRpcTypeJobHandlers::SendResponseHandler m_sendResponse;

			TagProcessor m_onRead;
			TagProcessor m_onFinish;
			TagProcessor m_onDone;

		}; // class UnaryRpcJob
		
		} // namespace UnaryRpc
		
	} // namespace grpc
	
} // namespace nettone

#include "nettone_grpc_UnaryRpc.ih"

#endif // __NETTONE_GRPC_UNARYRPC_IH__
