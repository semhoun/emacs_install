#ifndef __NETTONE_TOOLS_FSMCLASS_H__
#define __NETTONE_TOOLS_FSMCLASS_H__


#include "nettone_tools_FSM.h"


namespace nettone
{
	namespace tools
	{
		template <typename T, typename STATE, typename EVENT>
		class FSMClass
			: public nettone::tools::FSM<SHandler<T>, STATE, EVENT, SDefaultHandler<FSMClass<T, STATE, EVENT>, STATE, EVENT> >
		{
		protected:
			FSMClass(const STATE& p_state);

			virtual void defaultTransitionHandler(const STATE& p_state,
												  const EVENT& p_event,
												  void* const& p_data);

			void registerMyFSMHook(const STATE& p_state,
								   const EVENT& p_event,
								   void (T::* p_handler)(void* const& p_data),
								   const STATE& p_nextState,
								   const bool p_final = false);
		};
	}
}


#include "nettone_tools_FSMClass_i.h"


#endif // __NETTONE_TOOLS_FSMCLASS_H__
