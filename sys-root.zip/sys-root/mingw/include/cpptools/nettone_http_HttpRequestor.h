#pragma once

// STANDARDS INCLUDE
//
#include <list>
#include <thread>
#include <mutex>
#include <unordered_map>

#include "cpptools/nettone_tools_Exception.h"

// C INCLUDES
//
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <iostream>
#include <sstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <curl/curl.h>

// note: nested namespace is a new feature in C++17
//
namespace nettone::http
{
	class HttpRequestor
	{
	public:
		/**
		 * Forward declaration of HttpClient
		 */
		class HttpClient;

		/**
		 * Supported content
		 */
		enum Method
		{
			GET = 1,
			POST = 2,
			PUT = 3,
			PATCH = 4,
			DELETE = 5
		};

		/**
		 * Brand new type def used to rename types (C++11)
		 */
		using RequestHeaders = std::unordered_map<std::string, std::string>;

		struct HttpAuth
		{

			std::string login;

			std::string password;
		};

		// note : use struct because all members are publics
		//
		struct Request
		{
			nettone::http::HttpRequestor::Method method;

			std::string url;

			std::string json;

			RequestHeaders headers;

			HttpAuth httpAuth;

			void addHeader(const std::string& p_headerName, const std::string& p_value)
				noexcept(false);

			void addHttpAuth(const std::string& p_login, const std::string& p_password)
				noexcept(false);
		};

		struct Response
		{
			uint16_t statusCode;

			uint32_t size;

			std::string content;
		};

		class CurlRequestor
		{
		private:

			struct Reply
			{
				uint32_t statusCode = 0;

				uint32_t size = 0;

				std::string content {};

				void reset() { statusCode = 0; size = 0; content.clear();}
			};

			/**
			 * Constructor
			 */
			CurlRequestor(HttpRequestor* const p_outclass)
				noexcept(false);

			/**
			 * Destructor
			 */
			~CurlRequestor()
				noexcept(true);

			/**
			 *  Set timeout set in config
			 */
			void setTimeout(uint8_t p_timeout)
				noexcept(false);

			/**
			 *  Set url
			 */
			void setUrl(const std::string& p_url)
				noexcept(false);
			/**
			 *
			 */
			void setHttpVersion(const std::string& p_verion)
				noexcept(false);
			/**
			 * Set Method
			 */
			void setMethod(const nettone::http::HttpRequestor::Method& p_method)
				noexcept(false);

			/**
			 * Set http auth
			 */
			void setHttpAuth(const HttpAuth& p_auth)
				noexcept(false);

			/**
			 * Set callback
			 */
			void setCallBack()
				noexcept(false);

			/**
			 * Set data
			 */
			void setData(const std::string& p_data)
				noexcept(false);

			/**
			 *  Set header
			 */
			void setHeader(const std::string& header, const std::string& value)
				noexcept(false);

			/**
			 * Get erreur
			 */
			void setResponseCode()
				noexcept(false);

			/**
			 *  prepare request
			 */
			void prepareRequest(const Request& p_request)
				noexcept(false);

			/**
			 * Perform request
			 */
			void executeRequest()
				noexcept(false);

			/**
			 *  Get reply struct
			 */
			Reply& getReply()
					noexcept;

			/**
			 * Reset reply with defaut value
			 */
			void resetReply()
				noexcept;

			/**
			 * Callback needed by c=url
			 */
			static size_t writeData(void *p_contents, size_t p_size, size_t p_nmemb, std::string* p_writerData)
					noexcept(true);

			/**
			 * Curl Handler
			 */
			CURL* m_curl = nullptr;

			/**
			 * Headers
			 */
			struct curl_slist* m_headers = nullptr;

			/**
			 * Reply of request
			 */
			Reply m_reply;

			/**
			 * Outter pointer
			 */
			HttpRequestor* m_httpRequestor;

			friend class HttpRequestor::HttpClient;
		};

	public:

		class HttpClient
		{
		public:
			/**
			 * User credential authentication
			 */
			struct Config
			{
				/**
				 * Maximum time to process request, when reached an exception is raised (value in seconds)
				 */
				uint16_t timeout;

				/**
				 * flag that indicate if debug is activated
				 */
				bool debug;

			}; // class  Connection::Config

			/**
			 * Constructor
			 */
			HttpClient(HttpRequestor* const p_this)
				noexcept(true);

			/**
			 * Destructor
			 */
			~HttpClient()
				noexcept(true);

			/**
			 * Retrieve token auth et set status
			 */
			void init(const Config& p_config)
				noexcept(false);

			/**
			 * Internal executor, will call curl handles with right parameters
			 */
			void  executeRequest(HttpRequestor::Request& p_request, HttpRequestor::Response& p_response)
				noexcept(false);

			/**
			 * Connexion configuration.
			 */
			Config m_config;

			/**
			 * Curl wrapper
			 */
			CurlRequestor m_curlRequestor;

			/**
			* Outclass
			*/
			HttpRequestor* const m_this;

		}; // class Connection

		/**
		 * HttpRequestor configuration structure
		 */
		struct Config
		{
			HttpClient::Config httpClientConfig;

			/*
			* Maximal number of connexions.
			*/
			unsigned maxNumberHttpClient;

			/**
			* Maximal number of stand-by connexions.
			*/
			unsigned maxStandbyHttpClient;
		};

		/**
		 * Constructor
		 */
		HttpRequestor()
			noexcept(true);

		/**
		 * Destructor
		 */
		~HttpRequestor()
			noexcept(true);
		/**
		 *  C++11 notation for forbidden function
		 */
		HttpRequestor(const HttpRequestor& p_other) = delete;
		const HttpRequestor& operator=(const HttpRequestor& p_other) = delete;

		/**
		 * Start the request and may throw exception it is
		 * well initialized
		 */
		void start(const HttpRequestor::Config& p_config)
			noexcept(false);

		/**
		 * Get authenticated connection
		 */
		HttpClient* getHttpClient()
			noexcept(false);


		// Utility function to easily insert headers inside request, like std::[...] utilities function
		//
		static void addHeader(Request& p_request, const std::string& p_headerName, const std::string& p_value)
			noexcept(false);

		// Utility function to easily insert headers inside request, like std::[...] utilities function
		static void addHeader(RequestHeaders& p_request, const std::string& p_headerName, const std::string& p_value)
			noexcept(false);


		/**
		 * Place active HttpClient into standby HttpClient list
		 */
		void releaseHttpClient(HttpRequestor::HttpClient* p_httpClient)
			noexcept(false);

		/**
		* Release all connexions.
		*/
		void releaseAllHttpClient()
			noexcept(false);

		/**
		 * Get active http client count
		 */
		int	getActiveHttpClientCount()
			noexcept(true);

		/**
		 * Get standby http client count
		 */
		int getStandbyHttpClientCount()
			noexcept(true);
	private :

		/**
		 * Check if Method is supported by Requestor
		 */
		bool isSupportedMethod(const nettone::http::HttpRequestor::Method& p_method)
			noexcept(true);

		/**
		 * List of active connection
		 */
		std::list<HttpClient*> m_activeHttpClients;

		/**
		 * List of inactive connection
		 */
		std::list<HttpClient*> m_standbyHttpClients;

		/**
		 * Mutex used to protect
		 */
		std::mutex	m_mutex;

		/**
		 *  Configuration
		 */
		Config		m_config;

		/**
		 * Flag for initizalization
		 */
		bool  m_initialized;

}; // class Requester

} // namespace nettone::http
