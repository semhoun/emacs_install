#pragma once
#include <string>
#include <stdint.h>
#include <sstream>
#include <vector>
#include <list>

#include "nettone_error_codes.h"
#include "nettone_tools_Exception.h"

// RTP.header = 12 bytes
// ----------------------
//   |
//	 |--RTP.CompressedBody.G729
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: 10 bytes  ; 10 to 230 in multiples of 10
//	 |		|		|-- uncompressed frame	: 80 * sizeof(int16_t)
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 20 bytes  ; 10 to 230 in multiples of 10
//	 |				|-- uncompressed frame	: 80 * 2 * sizeof(int16_t)
//	 |
//	 |--RTP.CompressedBody.G711_A / G711_U
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: 80 bytes
//	 |		|		|-- uncompressed frame	: 80 * sizeof(int16_t)
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 160 bytes
//	 |				|-- uncompressed frame	: 160 * sizeof(int16_t)
//   |
//	 |--RTP.CompressedBody.G722_64
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: 80 bytes
//	 |		|		|-- uncompressed frame	: 80 * sizeof(int16_t)
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 160 bytes
//	 |				|-- uncompressed frame	: 160 * sizeof(int16_t)
//   |
//   |--RTP.CompressedBody.ILBC
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: <NONE> ; does not exist
//	 |		|		|-- uncompressed frame	: <NONE> ; does not exist
//	 |		|
//	 |		|--- 20 Msec :
//	 |				|-- compressed frame	: 38 bytes
//	 |				|-- uncompressed frame	: 160 * sizeof(int16_t)
//	 |
//	 |--RTP.CompressedBody.ILBC_13
//	 |		|--- 10 Msec :
//	 |		|		|-- compressed frame	: <NONE> ; does not exist
//	 |		|		|-- uncompressed frame	: <NONE> ; does not exist
//	 |		|
//	 |		|--- 20 Msec :
//	 |		|		|-- compressed frame	: <NONE> ; does not exist
//	 |		|		|-- uncompressed frame	: <NONE> ; does not exist
//	 |		|
//	 |		|--- 30 Msec :
//	 |				|-- compressed frame	: 50 bytes
//	 |				|-- uncompressed frame	: 240 * sizeof(int16_t)
//
//=================================================================================================================

namespace nettone
{
    namespace codec
    {

        //================================================================
        // in the database, the codecs have a human-readable name
        //================================================================
        const std::string	CODEC_NAME_IN_DB_G729		= "G729";
        const std::string	CODEC_NAME_IN_DB_G711_PCMA	= "PCMA";
        const std::string	CODEC_NAME_IN_DB_G711_PCMU	= "PCMU";
        const std::string	CODEC_NAME_IN_DB_G722_64	= "G722_64";
        const std::string	CODEC_NAME_IN_DB_OPUS_64	= "OPUS_64";
        const std::string	CODEC_NAME_IN_DB_DIGIT		= "TELEPHONE-EVENT";

        enum CodecId {
            e_cPCMU			= 0,
            e_cGSM			= 3,
            e_cG723     = 4,
            e_cPCMA     = 8,
            e_cG722_48  = 114,
            e_cG722_56	= 113,
            e_cG722_64	= 9,
            e_cG729			= 18,
            e_cPcmWav		= 94,   // 94=unassigned in Iana list => use it for PCM (wav)
            e_cDigit		= 101,	// for "telephone-event" case, or any other being not a real codec
            e_cOpus_64	= 107,
            e_ciLBC			= 116,	// iLBC		: Sampling=20ms|PayloadSize=38 bytes
            e_ciLBC_13	= 120,  // iLBC_13	: Sampling=30ms|PayloadSize=50 bytes
            e_cUnknow   = 255,
        };
        typedef std::list<CodecId> CodecsId;

        // RTP frame structure:
        // - version							-	1 byte (upon RFC 1889) 	- offset: 0
        // - Payload type						-	1 byte (0x12 = G729)	- offset: 1
        // - Sequence number					-	2 bytes					- offset: 2
        // - Timestamp							-	4 bytes					- offset: 4
        // - Synchronysation source identifier	-	4 bytes 				- offset: 8 <<<<<<< hijacked to contain the RTP body size
        // - Payload							-	X bytes (remaining)
        const uint32_t	KERTEL_RTP_HEADER_SIZE_IN_BYTE			 = 12;
        const uint32_t	KERTEL_PAYLOAD_TYPE_OFFSET_IN_RTP_PACKET = 1;

        const uint8_t	KERTEL_G729_PAYLOAD_TYPE_FLAVOUR_1		= 0x12; // same value as nettone::codec::CodecId::e_cG729
        const uint8_t	KERTEL_G729_PAYLOAD_TYPE_FLAVOUR_2		= 0x92; // when the MSB is set

        const uint8_t	KERTEL_G722_48_PAYLOAD_TYPE_FLAVOUR_1	= 0x72;
        const uint8_t	KERTEL_G722_48_PAYLOAD_TYPE_FLAVOUR_2	= 0xF2;

        const uint8_t	KERTEL_G722_56_PAYLOAD_TYPE_FLAVOUR_1	= 0x71;
        const uint8_t	KERTEL_G722_56_PAYLOAD_TYPE_FLAVOUR_2	= 0xF1;

        const uint8_t	KERTEL_G722_64_PAYLOAD_TYPE_FLAVOUR_1	= 0x09;
        const uint8_t	KERTEL_G722_64_PAYLOAD_TYPE_FLAVOUR_2	= 0x89;

        const uint8_t	KERTEL_G711_PAYLOAD_TYPE_ALAW_FLAVOUR_1 = 0x08;
        const uint8_t	KERTEL_G711_PAYLOAD_TYPE_ALAW_FLAVOUR_2 = 0x88;

        const uint8_t	KERTEL_G711_PAYLOAD_TYPE_ULAW_FLAVOUR_1 = 0x00;
        const uint8_t	KERTEL_G711_PAYLOAD_TYPE_ULAW_FLAVOUR_2 = 0x80;

        const uint8_t	KERTEL_GSM_PAYLOAD_TYPE_FLAVOUR_1		= 0x03;
        const uint8_t	KERTEL_GSM_PAYLOAD_TYPE_FLAVOUR_2		= 0x83;

        const uint8_t	KERTEL_ILBC_PAYLOAD_TYPE_FLAVOUR_1		= 0x74;
        const uint8_t	KERTEL_ILBC_PAYLOAD_TYPE_FLAVOUR_2		= 0xF4;

        const uint8_t	KERTEL_ILBC_13_PAYLOAD_TYPE_FLAVOUR_1	= 0x78;
        const uint8_t	KERTEL_ILBC_13_PAYLOAD_TYPE_FLAVOUR_2	= 0xF8;

        const uint8_t	KERTEL_OPUS_PAYLOAD_TYPE_FLAVOUR_1		= 0x6B;

        //================================================================================
        // Functions
        //================================================================================
        std::string RtpPayloadTypeToString					(uint8_t p_RtpPayloadType) throw ();
        std::string RtpPayloadTypeToStringRfcCompatible		(uint8_t p_RtpPayloadType) throw ();
        uint8_t		NormalizeRtpPayloadType					(uint8_t p_RtpPayloadType) throw ();


        bool		IsRtpTrafficTypeG711					(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeG711ALaw				(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeG711ULaw				(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeG729					(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeG722					(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeILBC					(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeGSM						(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpTrafficTypeOPUS					(uint8_t p_RtpTrafficType) throw ();
        bool		IsRtpPayloadTypeSupportedForDecoding	(uint8_t p_RtpTrafficType) throw ();
        bool		IsRealAudioTrafficType					(uint8_t p_RtpTrafficType) throw ();
        bool		GetG722CodecRate						(uint8_t p_G722RtpPayloadType, unsigned long& p_ExtractedRate);
        bool		GetDefaultCodecRate						(uint8_t p_RtpPayloadType, unsigned long& p_ExtractedRate);

        /**
         * Get List of codecs Ids from a string separator is ";"
         */
        CodecsId csv2codecsId(const std::string& p_codecsStr)
            throw ();

        CodecId payload2codecId(uint8_t p_payload)
            throw();
    }
}

