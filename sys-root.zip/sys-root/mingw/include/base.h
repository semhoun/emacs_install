// charset=utf-8
#ifndef __BASE_H_
#define __BASE_H_

#include <string.h>
#include <set>
#include <list>
#include <map>
#include <vector>
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <signal.h>
#include <sys/time.h>

using namespace std;

//------------------------
//! Base object
/*! This object is designed to be used as a root object. It serves no precise purpose. */
class object_t
{
public:
    /*! This destructor is empty {} */
    virtual ~object_t() {};
};

//! valeur de retour standard d'une fonction
struct Rval {
    bool ok;
    int code;
    string msg;
    friend ostream& operator<<(ostream& os, Rval& x);
    Rval(bool ok=true)                  : ok(ok), code((ok)?0:-1)      {}
    Rval(bool ok, int code)             : ok(ok), code(code)           {}
    Rval(bool ok, int code, string msg) : ok(ok), code(code), msg(msg) {}
};

//! closes a given file when destructed

class AutoCharArray
{
public:
    char* x;
    void alloc(size_t s) {
        free();
        x=new char[s];
    }
    void free(void) {
        if (x) {
            delete[] x;
            x=0;
        }
    }
    AutoCharArray(void) : x(0) {};
    AutoCharArray(size_t s) : x(0) {
        alloc(s);
    }
};

//! permet d'obtenir l'heure du jour à la micro(ou nano)-seconde près
class precise_time_t
{
public:
    struct timeval t0;
    char buf[25];
    precise_time_t(void);
    char* get_str(void);
    double get_double(void);
    static int get_uniqueId(void); // returns a 1e9 + temps en milisecondes%1e9
};

//------------------------


/*! \addtogroup global_ref Global references
@{ */

//! Constant string
/* Used to store static text */
typedef char const* const const_str;

//! maximum integer value
/*! on 32 bits machines, this is 2^31-1 */
extern int max_int;
extern int min_int;

//! specifies the level of details stored in the log file
extern unsigned long debug_level;

#define IF_DBG_LEV(x) if ((debug_level&15)>=(x))
#define IF_DBG_FLAG(x) if (debug_level&(x))

class instance_id_t
{
    string id;
    int idNum;
public:
    const string& str(void) const {
        return id;
    }
    int num(void) {
        return idNum;
    }
    void set(const string str); // une chaÃ®ne contenant un entier (1<=n<=99) permettant de différencier les instances de ce même programme
    void set(int n); //  1<=n<99
    instance_id_t(void) : id("1") {}
};

extern instance_id_t instance_id;

//! permet de générer l'heure réelle à la microseconde près
extern precise_time_t global_timer;
//! @}

void sleep_ms(int duration);

string html_hid_header(void);
string html_hid_start(string label="");
string html_hid_stop(void);

string html_style(void);	// inclure le contenu entre <style></style> dans la section <head>


//---- string processing --------------------------------

/*! \addtogroup global_stringproc Global string processing
@{ */

//!	converts a long int to a string
/*! \param l integer to convert
	\param align alignment <ul>
		<li> if !=0 the number of caracters
		<li> if ==0 no alignment
		</ul>
	\param align_char padding character
*/
string long2string(long l, int align=0, char align_char='0');
string ulong2string(unsigned long l, int align=0, char align_char='0');
string bool2string(bool b);
string ptr2string(void* p);
string double2string(double l);
string& cropCrLf(string& s);
string trimString(string s, const char* delim);

//! Tests is a string a the prefix of another string
/*! \param str reference string
	\param prefix prefix to search
	\return true if \em prefix is the prefix of \em str */
bool IsPrefix_c(const_str str, const_str prefix);
bool IsPrefix(const string str, const string prefix);
bool IsPostfix(const string str, const string postfix);

class TextTemplate
{
public:
    //*! replace replaces occurences of $varName$ with the value of var["narName"]. Use $$ for $.
    static int replace(const char* src, int srcLen, char* dst, int dstMaxLen, map<string,string>& var);
    static string replace(string src, map<string,string>& var, int margin=2048);
    static bool isPresent(const char* src, int srcLen, string var);
    static bool isPresent(string src, string var) {
        return isPresent(src.data(), src.size(), var);
    }
};

//! returns "true" or "false" depending on the value of \em x
inline const char* 	bool_str(bool x)
{
    if (x) {
        return "true";
    }
    else {
        return "false";
    }
}

//! explodes a string into an array
/*! takes a list of arguments separated by \em sep and splits them into \em res
	\param input input string (for instance "monday,tuesday,friday")
	\param res (output) array to store the results (--> {"monday", "tuesday", "friday"} )
	\param sep separator (',' in this example)
	\param keep_empty retain empty strings
*/
int explode_vector(string input, vector<string>& res, char sep=' ', bool keep_empty=true);
int explode_list(string input, list<string>& res, char sep=' ', bool keep_empty=true);
int explode_multiset(string input, multiset<string>& res, char sep=' ', bool keep_empty=true);

string utf8_latin(string src, bool* invalid=0); //!< converts an utf8 string to iso-8859-1. If invalid!=NULL *invalid says whether the input was a valid or an invalid utf-8 string
string latin_utf8(string str); //!< converts a iso-8859-1 to utf8

//! remove accents
/*! takes a 8-bits string (iso-8859-1) and converts it to a 7-bits string
	by removing the accents. For instance: "élève" --> "eleve" */
void no_accent(char* s);

//! removes any occurence of \em c in \em s
string rem_char(string s, char c);

//! takes an utf-8 string and converts it to 7 bits ascii string (utf8_latin+no_accent)
string utf8_ascii(const char* s);

string readToken(string& cmd, const char sep=' ');  // \r \n \" \\ chars must be escaped IF the token is between "", else SPACE is the end delimiter only
string peepToken(string  cmd, const char sep=' ');	// same than peepToken but does not remove the token from cmd
string escapeToken(string tok); // escapes \r \n \" \\ chars
string inline wrapToken(string tok)
{
    return "\""+escapeToken(tok)+"\"";    // escapes \r \n \" \\ chars
}

unsigned matchStr(const char* str, const char** array, unsigned defaultIndex); // finds str in array (last entry of the array must be 0)
string removeTrailingCrOrLf(string s);

string textUrlEncode(const char* src);
string textUrlDecode(const char* src);

class ValStr
{
public:
    static bool isNum(const char* p, const char* desc=0); // non-empty and only digits
    static bool isNum(string& s, const char* desc=0) {
        return isNum(s.c_str(), desc);    // non-empty and only digits
    }
    static bool noQuote(string& s, const char* desc=0); // no quote character
    static bool notEmpty(string& s, const char* desc=0);
};

bool validateStrNum(string& s);

string htmlspecialchars(string s);

//-----------------------------------

//! Test version number type 1.0.2.0 (only number)
int versioncmp(string version1, string version2);

bool createDirPath(string s, unsigned mode=0777); // crée les répertoires manquants pour le chemin d'accès au fichier spécifié

string expandPath(string s);

/* génère un nom de sous-répertoire en insérant des "/" tous les width. La partie variable commence au caractère "cur" */
string id2multiDir(string s, unsigned width, std::size_t cur=0, unsigned nbMax = 999);

//! @}

/*! \addtogroup global_ref Global references
@{ */

//! Displays a block of memory in hexadecimal and ascii
/*! The output looks like:

\verbatim
62 6F 6E 6A 6F 75 72 20 63 65 63 69 20 65 73 74 bonjour ceci est
20 75 6E 20 74 65 73 74 00                       un test.
\endverbatim
*/

//! convertit une date en secondes depuis 1970 en chaÃ®ne affichable
string seconds_to_string(time_t t);
string timestamp_str();

//! affiche le contenu d'une zone mémoire en hexadécimal et ascii
string hex_dump(const void* buf, int size);

//! returns a string of hexadecimal, no space, upcase only
string bin2hex(const void* buf, int size);

//! builds binary from an even number of upper case hexadecimal digits. Output must point to an allocated space of sufficient size
//! \return the number of bytes decoded
unsigned hex2bin(const char* hex, void* output);

//! revoie le pgcd de deux entiers positifs
long calc_pgcd(long a, long b);

//! limite l'excustion de \c x entre \c min et \c max
inline long bound_long(long x, long min, long max)
{
    if (x<=min) {
        return min;
    }
    if (x>=max) {
        return max;
    }
    return x;
}

//! catches any exception and throws it away
#define NOEX(A) { try { A } catch(...) {} }

//! displays a localization string (for debug purposes)
/*! displays thread filaname and line <br> example: "thread 123, toto.c, 45" */
#define DBi clog << "thread " << pthread_self() << ", " <<  __FILE__ << ", " << __LINE__ << " t=" << global_timer.get_str() << "s" << db_cr;

//--------------------- HTML constants ---------------------

#define PRPTR(os,a) (((a)==0)?(os<<"(nothing)"):(os<<*(a)))

string table_open(const string title="");
string table_line(const string name, const string value);
string table_separ(void);
string table_close(void);
#define qt1 "<a class=quot>"
#define qt0 "</a>"

//--- manipulators -----------------------------------------

//! inserts and html line break in the stream
extern const string db_cr_str;
inline ostream& db_cr(ostream& s)
{
    return s<<db_cr_str<<flush;
}

//! inserts and html horizontal rule in the stream
inline ostream& db_hr(ostream& s)
{
    return s << " <hr>\n";
}


//! défini dans le fichier de main(), pas dans object.cpp
/*! \param severity 1=informative, 2=warning, 3=error
 * typically gLogEv send an SNMP trap and also produces an output with err_on/off or warn_on/off
 */

void gLogEv(long severity, long code, string msg, ostream* os=0);

class LogFacility
{
public:
    virtual void write(int severity, int errorCode, string& message)=0;
    void trace(string message) {
        write(0,0,message);
    }
    void error(int severity, string message) {
        write(severity, 0, message);
    }
    virtual ~LogFacility(void) {}
};

class LogFacilityStream : public LogFacility
{
    ostream& os;
public:
    string prefix;
    void write(int severity, int errorCode, string& message) {
        string m=prefix+message;
        if (severity>0) {
            gLogEv(severity,errorCode,m,&os);
        }
        else {
            os << m << endl;
        }
    }
    LogFacilityStream(ostream& os) : os(os) {}
};

//! inserts and html code to highlight an error
ostream& err_on (ostream& s);
ostream& err_off(ostream& s);

//! inserts and html code to highlight a warning
ostream& warn_on (ostream& s);
ostream& warn_off(ostream& s);

//! inserts and html code to highlight in green
ostream& info_on (ostream& s);
ostream& info_off(ostream& s);

extern const string info_on_str;
extern const string info_off_str;

//! inserts and html code to add info
string title_on ();
string title_off();

//! inserts and html code to stop info
ostream& title_off(ostream& s);

//! inserts the current local date & time
ostream& log_time(ostream& s);

//! @}

//------------------ Base 64 ----------------
class Base64
{
public:
    static const char alphabet[64+1];
    static const int maxCharPerLine = 76; // (must be a multiple of 4). carriage return not included.
    static int encodedLen(unsigned int srcLen); // space to reserve for "dst" before calling "encode()"
    static int decodedLen(unsigned int srcLen); // space to reserve for "dst" before calling "encode()"
    static int encode(char* dst, const char* src, unsigned int len); // returns the actual length of the encoded stream
    static int decode(char* dst, const char* src, unsigned int len); // returns the actual length of the decoded stream or -1 of error
    static std::string encode(std::string src);
    static std::string decode(std::string src);
    static void randStr(char* s, int len); // will fill the string with len-1 random characters from the alphabet, plus terminal 0
    static std::string randStr(int len); // will return a string with len random characters from the alphabet
};

//------------------ DEMONIZE ----------------


#define DEMONIZE_GLOBAL \
	semaphore_t sync_sem(0,1); \
	const int sync_sig=SIGUSR1; \
	void sync_handler(int n) { sync_sem.unlock(); }

#define DEMONIZE_INIT \
	signal(sync_sig,sync_handler); \
	signal(SIGCLD, SIG_IGN); \
	pid_t fpid=getpid(); \
	{	pid_t pid=fork(); \
		if (pid) { cout << pid << endl; sync_sem.lock(); return 0; } \
	} \
	signal(sync_sig,SIG_DFL); \
	setsid();


#define DEMONIZE_READY \
	kill(fpid,sync_sig);


class ArgvClass
{
    unsigned cur;
public:
    static const unsigned argvSize=30;
    char* (data[argvSize]);

    void add(string s) {
        add(s.c_str());
    }
    void add(const char* s);
    void add(list<string>& l);
    void clear(void);
    string print(void);
    ArgvClass(void);
    ~ArgvClass(void) {
        clear();
    }
};

void disableSignal(int signum); /* SIGPIPE, SIGCLD,... */

bool execCommand(char* const argv[], FILE** f_stdin, FILE** f_stdout, FILE** f_stderr, pid_t* child_pid=0);
/* if you not wait() or waidpid(), call disableSignal(SIGCLD) first to avoid defunct process (also done my DEMONIZE_INIT) */
/* argv terminé par NULL et le premier arg est une copie du nom du program de path */
/* il est recommandé de capturer le signal SIGPIPE au cas ou le fils meurt prématurément. Ex: signal(SIGPIPE, SIG_IGN); */
//********/

#endif
