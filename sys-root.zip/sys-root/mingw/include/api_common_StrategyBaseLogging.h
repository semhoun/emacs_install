#pragma once


#define MODULE_NAME "api.common.strategybase"

#define MODULE_LOG_DEBUG 1
#define MODULE_LOG_INFO  1
#define MODULE_LOG_WARN  1
#define MODULE_LOG_ERROR 1
#define MODULE_LOG_FATAL 1


#include "cpptools/nettone_log_Logging.h"
