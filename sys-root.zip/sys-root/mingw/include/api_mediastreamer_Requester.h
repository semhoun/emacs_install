#pragma once

// CPPTOOLS include
//
#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"
#include "cpptools/nettone_codec_identifiers.h"
#include "cpptools/nettone_grpc_Server.h"

#include "api_common_IRequester.h"

// GRPC include
//
#include <grpcpp/grpcpp.h>
#include <grpc/support/log.h>
#include <google/protobuf/message.h>

// IDL includes
//
#include "mediastreamer_MediaStreamerGW.grpc.pb.h"

// GRPC using
//
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

// Using namespace for Request and Reply of MediastreamerGW
//
using mediastreamer::EmptyRequest;
using mediastreamer::BooleanReply;
using mediastreamer::StreamInfo;
using mediastreamer::ListenerInfo;
using mediastreamer::LoadInfo;

using mediastreamer::CreateListenerRequest;
using mediastreamer::CreateListenerReply;

using mediastreamer::StartListenerRequest;

using mediastreamer::ListenerRequest;
using mediastreamer::RemoveAllListenersRequest;

using mediastreamer::GetStreamsInfoRequest;
using mediastreamer::GetStreamsInfoReply;

using mediastreamer::GetListenersInfoRequest;
using mediastreamer::GetListenersInfoReply;

using mediastreamer::GetLoadInfoRequest;
using mediastreamer::GetLoadInfoReply;

#define __DEBUG_REQUESTER__

namespace api
{
    namespace mediastreamer
    {
        /**
         * Send request to one instance of mediastreamer.
         */
        class Requester
            : public api::common::IRequester
        {
        public:
			/**
             * Constructor.
             *
             * @brief: Channel is used by grpc to configure addr and port
             */
            Requester(const nettone::grpc::Server::Endpoint &p_endpoint)
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~Requester()
                throw ();

            /**
             * Return the GRPC endpoint name
             */
            const std::string getName() const
                throw();

            /**
             * get the object Id.
             */
            virtual unsigned long getId() const
                throw ();

            /**
             * Set the Endpoint GRPC server to contact
             * Must be called before start
             */
            void setEndpoint(const nettone::grpc::Server::Endpoint& p_endoint)
                throw();

            /**
             * Get the full name of the mediastreamer.
             *
             * @return The Endpoint.
             */
            nettone::grpc::Server::Endpoint& getEndpoint()
             throw();

            /**
             * @todo Comment.
             */
            class IHandler
            {
            public:
                virtual ~IHandler() {}

                /**
                 * Error kind.
                 */
                enum Error {
                    COMM_FAILURE,
                    REQUEST_FAILURE
                };

                /**
                 * @todo Comment.
                 */
                virtual void handleError(const Error p_error)
                    throw () = 0;
            };

            /**
             * @todo Comment.
             */
            class IConnect
                : public IHandler
            {
            public:
                virtual void handleConnect()
                    throw () = 0;
            };

            /**
             * Ping server when connecting
             * Must be the first service called.
             */
            void requestConnect(IConnect* const p_handler)
                throw (nettone::tools::Exception);

			/**
              * Interface used to get result of the streamInfo request
              */
            class IGetStreamsInfo
                : public IHandler
            {
                public:

                virtual ~IGetStreamsInfo() {}

                /**
                 * Handle the result
                 */
                virtual void handleGetStreamsInfo(const ::google::protobuf::RepeatedPtrField<::mediastreamer::StreamInfo >& p_streamsInfoList) = 0;
            };

            class IGetLoadInfo
                : public IHandler
            {
                public:
                    virtual ~IGetLoadInfo() {;}
                    /**
                     * Handle mediastreamer::LoadInfo
                     */
                    virtual void handleGetLoadInfo(const LoadInfo& p_loadInfo)
                    throw() = 0;
            };

            /**
             * Get the LoadInfo
             */
            void requestGetLoadInfo(IGetLoadInfo* const p_handler)
                throw (nettone::tools::Exception);


            /**
             * Get the stream info of the mediastremaer
             */
            void requestGetStreamsInfo(uint32_t p_begin,
                                        uint32_t p_nbToGet,
                                        IGetStreamsInfo* const p_handler)
                throw(nettone::tools::Exception);

            /**
             *  Interface used to Listeners info
             */
            class IGetListenersInfo
            : public IHandler
            {
                public:

                IGetListenersInfo() {}

                /**
                 * Handle the result of getListenersInfo request
                 */
                virtual void handleGetListenersInfo(const ::google::protobuf::RepeatedPtrField<::mediastreamer::ListenerInfo >& p_listenersInfoList) = 0;
            };
            void requestGetListenersInfo(nettone::codec::CodecId p_codecId,
                                        uint32_t p_streamId,
                                        uint32_t p_begin,
                                        uint32_t p_nbToGet,
                                        IGetListenersInfo* const p_handler)
                throw(nettone::tools::Exception);


            /**
             * @todo Comment.
             */
            class ICreateListener
                : public IHandler
            {
            public:
                virtual ~ICreateListener() {}
                virtual void handleCreateListener(const unsigned long p_listenerId,
                                                  const std::string& p_sdp)
                    throw () = 0;
            };

            /**
             * Request add a new listener for a stream.
             *
             * @param p_clientId ID of the client requesting the operation.
             * @param p_streamId ID of the media to stream to the listener.
             * @param p_codecs	 Codecs wanted for the stream
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The listener id, and the sdp
             */
            void requestCreateListener(const unsigned long p_clientId,
                                       const unsigned long p_streamId,
                                       const nettone::codec::CodecsId p_codecs,
                                       ICreateListener* const p_handler)
                throw (nettone::tools::Exception);

            /*
             * @todo Comment.
             */
            class IStartListener
                : public IHandler
            {
            public:
                virtual ~IStartListener() {}
                virtual void handleStartListener()
                    throw () = 0;
            };

            /**
             * Request add a new listener for a stream.
             *
             * @param p_listenerId ID of the listener to start
             * @param p_hostId   Host name or IP address of the listener.
             * @param p_port     Port onto which the listener is listening.
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The listener id.
             */
            void requestStartListener(const unsigned long p_listenerId,
                                      const std::string& p_hostId,
                                      const unsigned long p_port,
                                      IStartListener* const p_handler)
                throw (nettone::tools::Exception);

            /*
             * @todo Comment.
             */
            class IStopListener
                : public IHandler
            {
            public:
                virtual ~IStopListener() {}
                virtual void handleStopListener()
                    throw () = 0;
            };

            /**
             * Request add a new listener for a stream.
             *
             * @param p_listenerId ID of the listener to stop
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The listener id.
             */
            void requestStopListener(const unsigned long p_listenerId,
                                     IStopListener* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Request to remove a listener.
             *
             * @param p_listenerId ID of the listener to remove.
             */
            void requestRemoveListener(const unsigned long p_listenerId)
                throw (nettone::tools::Exception);

            /**
             * Request to remove all clientId's listener.
             *
             * @param p_clientId ID of the client.
             */
            void requestRemoveAllListeners(const unsigned long p_clientId)
                throw (nettone::tools::Exception);

        private:
            /// @name Forbidden methods
            /// @{
            Requester(const Requester& p_other);
            const Requester& operator =(const Requester& p_other);
            /// @}
            
            /**
             * Initialize port and ip with remote server
             */
            void initializeInternalStub() 
                noexcept(false);

            /**
             * Object Id.
             */
            unsigned long m_id;

            /**
             * MediastreamerGW stub
             */
             std::unique_ptr<::mediastreamer::MediaStreamerGW::Stub> m_mediastreamer;

            /**
             * GRPC server endpoint
             */
            nettone::grpc::Server::Endpoint m_endpoint;
        };
    }
}
