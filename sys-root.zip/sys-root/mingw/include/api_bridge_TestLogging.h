#ifndef __BRIDGE_API_TESTLOGGING_H__
#define __BRIDGE_API_TESTLOGGING_H__


#define MODULE_NAME "bridge.api.test"

#define MODULE_LOG_DEBUG 1
#define MODULE_LOG_INFO  1
#define MODULE_LOG_WARN  1
#define MODULE_LOG_ERROR 1
#define MODULE_LOG_FATAL 1


#include "cpptools/nettone_log_Logging.h"


#endif // __BRIDGE_API_TESTLOGGING_H__
