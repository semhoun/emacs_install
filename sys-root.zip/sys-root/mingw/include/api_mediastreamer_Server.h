#pragma once

#include <vector>
#include <map>
#include <memory>
#include <unordered_map>

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"
#include "cpptools/nettone_codec_identifiers.h"
#include "cpptools/nettone_grpc_Server.h"

#include "mediastreamer_MediaStreamerGW.pb.h"

namespace nettone
{
    namespace tools
    {
        class ServerTimer;
        class Mutex;
    }
}


namespace api
{
	namespace common
	{
		class IStrategy;
	}

    namespace mediastreamer
    {

        class Requester;
        class StopMonitor;

        /**
         * Wrap access to a set of mediastreamer.
         */
        class Server
            : public nettone::tools::ServerDeferred
        {
        public:
            friend class StopMonitor;

            /**
             * Constructor.
             */
            Server()
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~Server()
                throw ();

            /**
             * Start the server.
             */
            void start()
                throw (nettone::tools::Exception);

            /**
             * Stop the server.
             */
            void stop()
                throw ();

            class IAddMediaStreamer
            {
            public:
                virtual ~IAddMediaStreamer() {}
                virtual void handleError(const nettone::grpc::Server::Endpoint &p_endpoint,
                                         const std::string& p_error)
                    throw () = 0;
                virtual void handleAddMediaStreamer(const nettone::grpc::Server::Endpoint& p_endpoint)
                    throw () = 0;
            };

            /**
             * Get information about requester
             */
            std::vector<nettone::grpc::Server::Endpoint> getRequestersInfo()
                noexcept(false);

            /**
             * Add a MediaStreamer.
             *
             * @param p_fqn     The GRPC endpoint of the mediastreamer to add.
             * @param p_handler Observer of completion (optional).
             */
            void addMediaStreamer(const nettone::grpc::Server::Endpoint& p_endpoint,
                                  IAddMediaStreamer* const p_handler = NULL)
                throw (nettone::tools::Exception);

            /**
             * Interface notified on completion of a request to remove a MediaStreamer.
             * Todo: remove this handler 
             */
            class IRemoveMediaStreamer
            {
            public:
                virtual ~IRemoveMediaStreamer() {}
                virtual void handleRemoveMediaStreamer(const nettone::grpc::Server::Endpoint& p_endpoint)
                    throw () = 0;
            };

            /**
             *
             * Remove a MediaStreamer.
             *
             * @param p_endpoint    The GRPC endpoint of the mediastreamer to remove.
             * @param p_handler Observer of completion (optional)
             *
			 */
            void removeMediaStreamer(const nettone::grpc::Server::Endpoint& p_endpoint,
                                     IRemoveMediaStreamer* const p_handler = NULL)
                throw (nettone::tools::Exception);

            /**
             * @todo Comment.
             */
            class ICreateListener
            {
            public:
                virtual ~ICreateListener() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleCreateListener(const unsigned long p_listenerId,
                                                  const std::string& p_sdp)
                    throw () = 0;
            };

            /**
             * Request add a new listener for a stream.
             *
             * @param p_clientId ID of the client requesting the operation.
             * @param p_streamId ID of the media to stream to the listener.
             * @param p_codecs	 Codecs wanted for the stream
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The listener id, and the sdp
             */
            void requestCreateListener(const unsigned long p_clientId,
                                       const unsigned long p_streamId,
                                       const nettone::codec::CodecsId p_codecs,
                                       ICreateListener* const p_handler)
                throw (nettone::tools::Exception);

            /*
             * @todo Comment.
             */
            class IStartListener
            {
            public:
                virtual ~IStartListener() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleStartListener()
                    throw () = 0;
            };

            /**
             * Request add a new listener for a stream.
             *
             * @param p_listenerId ID of the listener to start
             * @param p_hostId   Host name or IP address of the listener.
             * @param p_port     Port onto which the listener is listening.
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The listener id.
             */
            void requestStartListener(const unsigned long p_listenerId,
                                      const std::string& p_hostId,
                                      const unsigned long p_port,
                                      IStartListener* const p_handler)
                throw (nettone::tools::Exception);

            /*
             * @todo Comment.
             */
            class IStopListener
            {
            public:
                virtual ~IStopListener() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleStopListener()
                    throw () = 0;
            };

            /**
             * Request add a new listener for a stream.
             *
             * @param p_listenerId ID of the listener to stop
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The listener id.
             */
            void requestStopListener(const unsigned long p_listenerId,
                                     IStopListener* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Request to remove a listener.
             *
             * @param p_listenerId ID of the listener to remove.
             */
            void requestRemoveListener(const unsigned long p_listenerId)
                throw (nettone::tools::Exception);

            /**
             * Request to remove all clientId's listener.
             *
             * @param p_clientId ID of the client.
             */
            void requestRemoveAllListeners(const unsigned long p_clientId)
                throw (nettone::tools::Exception);

            /**
             * Convert nettone::codec::CodecId to mediastreamer::CodecType
             *
             * @param p_codec nettone::codec::CodecId to convert
             */
            static ::mediastreamer::CodecType nettoneToCodecType(nettone::codec::CodecId p_codec)
                throw();

        private:
            /**
             * Remove a requester from the server.
             *
             * @param p_requester The requester to remove.
             * @param p_handler   Completion observer (optional).
             *
             * @note Must be called from a protected section.
             */
            void removeRequester(Requester* const p_requester,
                                 IRemoveMediaStreamer* const p_handler = NULL)
                throw (nettone::tools::Exception);

            /**
             * Handle connection error with requesters.
             *
             * @param p_requester A requester that is in failure.
             */
            void handleRequesterError(Requester* const p_requester)
                throw ();

            /**
             * Record which requester holds a listenerId.
             * Needed to remove a listener.
             *
             * @param p_requester  The requester owning the listener.
             * @param p_listenerId Id of the listener to store.
             */
            void recordListenerId(Requester* const p_requester,
                                  const unsigned long p_listenerId)
                throw (nettone::tools::Exception);

            /**
             * Erase which requester holds a listenerId.
             *
             * @param p_listenerId Id of the listener to store.
             */
            void eraseListenerId(const unsigned long p_listenerId)
                throw ();

            /**
             * Retrieve the Requester owning a listener Id.
             *
             * @param p_listenerId The ID of the listener.
             *
             * @return A pointer to the Requester owning the ID.
             */
            Requester* getRequesterByListenerId(const unsigned long p_listenerId)
                throw (nettone::tools::Exception);

            /// @name Forbidden methods
            /// @{
            Server(const Server& p_other);
            const Server & operator =(const Server& p_other);
            /// @}

            /**
             * Lock used when accessing internal structure.
             */
            std::unique_ptr<nettone::tools::Mutex> m_lock;

            /**
             * Timesource.
             */
            std::unique_ptr<nettone::tools::ServerTimer> m_timesource;

            /**
             * The strategy selecting requester to handle requests.
             */
            std::unique_ptr<api::common::IStrategy> m_strategy;

            /**
             * @var Requesters m_requesters;
             *
             * Requesters handling MediaStramer instances.
             */
            typedef std::vector<Requester*> Requesters;
            Requesters m_requesters;

            /**
             * @var MapRequestersByLid m_mapRequestersByLid
             *
             * Store which requester holds which listenerid.
             */
            typedef std::unordered_map<unsigned long, Requester*> MapRequestersByLid;
            MapRequestersByLid m_mapRequestersByLid;
        };
    }
}

