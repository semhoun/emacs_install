 #ifndef __UDPBRIDGE_API_SERVER_H__
#define __UDPBRIDGE_API_SERVER_H__

#include <vector>
#include <map>
#include <list>
#include <unordered_map>

#include "cpptools/nettone_tools_IdManager.h"
#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"
#include "cpptools/nettone_codec_identifiers.h"
#include "cpptools/nettone_grpc_Server.h"

namespace nettone
{
    namespace tools
    {
        class ServerTimer;
        class Mutex;
    }
}


namespace api
{
	namespace common
	{
        class IStrategy;
	}

    namespace mproxy
    {
		class Requester;

        /**
         * Wrap access to a set of udpbridge.
         */
        class Server
            : public nettone::tools::ServerDeferred
        {
        public:
            typedef unsigned long UdpBridgeId;
            typedef unsigned long ContextId;
            typedef unsigned long AnchorId;

            /**
             * Constructor.
             */
            Server()
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~Server()
                throw ();

            /**
             * Start the server.
             */
            void start()
                throw (nettone::tools::Exception);

            /**
             * Stop the server.
             */
            void stop()
                throw ();

            /**
             * Interface notified on completion of a request to add a UdpBridge.
             */
            class IAddUdpBridge
            {
            public:
                virtual ~IAddUdpBridge() {}
                virtual void handleError(const nettone::grpc::Server::Endpoint& p_endpoint,
                                         const std::string& p_error)
                    throw () = 0;
                virtual void handleAddUdpBridge(const nettone::grpc::Server::Endpoint& p_endpoint,
                                                const UdpBridgeId p_rid)
                    throw () = 0;
            };

            /**
             * Add a UdpBridge.
             *
             * @param p_endpoint The GRPC endpoint of udpbridge to add
             * @param p_handler Observer of completion (optional).
             */
            bool requestAddUdpBridge(const nettone::grpc::Server::Endpoint& p_endpoint,
                                     IAddUdpBridge* const p_handler = NULL)
                throw (nettone::tools::Exception);

            /**
             * Interface notified on completion of a request to remove a UdpBridge.
             */
            class IRemoveUdpBridge
            {
            public:
                virtual ~IRemoveUdpBridge() {}
                virtual void handleRemoveUdpBridge(const nettone::grpc::Server::Endpoint& p_endpoint)
                    throw () = 0;
            };

            /**
             * Remove a UdpBridge.
             *
             * @param p_fqn     The GRPC endpoint of the udpBridge to remove.
             * @param p_handler Observer of completion (optional).
             */
            bool requestRemoveUdpBridge(const nettone::grpc::Server::Endpoint& p_endpoint,
                                        IRemoveUdpBridge* const p_handler = NULL)
                throw (nettone::tools::Exception);

            /**
             * Create context handler
             */
            class ICreateContext
            {
            public:
                virtual ~ICreateContext() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleCreateContext(const ContextId p_contextId)
                    throw () = 0;
            };

            /**
             * Operating mode.
             */
            enum OpMode
            {
                /**
                 * Relay stream between anchors.
                 */
                Relay,

                /**
                 * Recording stream between anchors.
                 */
                Recording
            };

            /**
             * Descriptor of the need for resource of a new context.
             */
            struct ResourceDesc
            {
                /**
                 * Count of anchors surely needed.
                 * Anchor creation requests will be satisfied.
                 */
                unsigned short lockedAnchors;

                /**
                 * Count of anchors that MAY be needed.
                 * This count is only a wish. Reserved anchors may be not
                 * available we anchor creation is requested.
                 */
                unsigned short requestedAnchors;
            };
            
            /**
             * Get information about requester
             */
            std::vector<nettone::grpc::Server::Endpoint> getRequestersInfo()
                noexcept(false);

            /**
             * Request create a new context.
             *
             * @param p_clientId 	ID of the client requesting the operation.
             * @param p_opMode		Operating mode of context.
             * @param p_resources	Describe the resources needed for the new context.
             * @param p_handler  	Handler to notify when the result is available.
             *
             * @return The context id.
             */
                                                       void requestCreateContext(const unsigned long p_clientId,
                                                                                 const OpMode p_opMode,
                                                                                 const ResourceDesc &p_res,
                                                                                 ICreateContext *const p_handler) throw(nettone::tools::Exception);

            /**
             * Request create a new context.
             * And specify udpBridge used
             *
             * @param p_handler  Handler to notify when the result is available.
             *
             * @return The context id.
             */
            void requestCreateContextUdpBridgeSpecified(const unsigned long p_clientId,
                                                        const UdpBridgeId p_uid,
                                                        const OpMode p_opMode,
                                                        const ResourceDesc& p_res,
                                                        ICreateContext* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Set context parameters handler.
             */
            class ISetContextParam
            {
            public:
                virtual ~ISetContextParam() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleSetParams(const ContextId p_contextId)
                    throw () = 0;
            };

            /**
             * Descriptor of context parameters.
             */
            struct ContextParam
            {
                /**
                 * Call Id from INCAS.
                 */
                unsigned long incasCallId;

                /**
                 * Call Id from MCMS.
                 */
                unsigned long mcmsCallId;

                /**
                 * Lines which ask to be recorded.
                 */
                typedef std::list<std::string> AskingLines;
                AskingLines askingLines;
            };

            /**
             * Set params of a context.
             *
             * @param p_contextID	ID of the context to set params.
             * @param p_params		Describe the parameters associated to the context.
             */
            void requestSetContextParams(const unsigned long p_contextID,
                                         const ContextParam p_params,
                                         ISetContextParam* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Request to release a context.
             *
             * @param p_releaseId ID of the context to release.
             */
            void requestReleaseContext(const ContextId p_cid)
                throw (nettone::tools::Exception);

            /**
             * Request to release all clientId's context.
             *
             * @param p_clientId ID of the client.
             */
            void requestReleaseAllContexts(const unsigned long p_clientId)
                throw (nettone::tools::Exception);

            /**
             * Additionnal codec parameter
             */
            struct CodecParam
            {
                /**
                 * Codec
                 */
                nettone::codec::CodecId codec;

                /**
                 * Payload value for this codec
                 */
                unsigned int payload;
            };
            typedef std::list<CodecParam> CodecsParam;

            /**
             * Descriptor of a anchor cration request.
             */
            struct AnchorParam
            {
                /**
                 * I/O mode.
                 */
                enum IOMode {
                    /**
                     * Read only : data are read on the anchor, routed, but no data can be sent through the anchor.
                     */
                    e_ioRead,

                    /**
                     * Write only : data are routed to the anchor, but no data are read from it.
                     */
                    e_ioWrite,

                    /**
                     * Both : data are read from and routed through the anchor.
                     */
                    e_ioReadWrite
                } ioMode;

                /**
                 * Kind of connection
                 */
                enum CnxMode {
                    /**
                     * Not connected mode
                     */
                    e_cnxLoose,

                    /**
                     * Auto learn, learn addr:port with n first packet
                     */
                    e_cnxAutoLearn,

                    /**
                     * Connected mode, use provided host and port
                     */
                    e_cnxConnected
                } cnxMode;

                /**
                 * Remote host address.
                 *
                 * Meaningful only when connected is true.
                 */
                std::string host;

                /**
                 * Remote host port.
                 *
                 * Meaningful only when connected is true.
                 */
                unsigned long port;

                /**
                 * Nb packet needed to learn an addr
                 *
                 * Meaningful only when mode is autolearn.
                 */
                unsigned long nbPacketToLearn;

                /**
                 * List of codecs param
                 */
                CodecsParam codecsParam;
            };

            /**
             * Descriptor of a created anchor.
             */
            struct AnchorDesc
            {
                /**
                 * Anchor ID.
                 */
                AnchorId anchorId;

                /**
                 * IP Address of the Bridge.
                 */
                std::string bridgeAddress;

                /**
                 * UDP port on the bridge associated to the anchor.
                 */
                unsigned long bridgePort;
            };

            /**
             * Handler for notify create anchor result
             */
            class ICreateAnchor
            {
            public:
                virtual ~ICreateAnchor() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleCreateAnchor(const AnchorDesc& p_anchorDesc)
                    throw () = 0;
            };

            /**
             * Request to create an anchor.
             *
             * @param p_contextID ID of the context holding the new anchor.
             * @param p_params    Descriptor of the anchor to create.
             * @param p_anchorID  ID of the created Anchor.
             */
            void requestCreateAnchor(const ContextId p_contextId,
                                     const AnchorParam& p_params,
                                     ICreateAnchor* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Handler for notify update anchor result
             */
            class IUpdateAnchor
            {
            public:
                virtual ~IUpdateAnchor() {}
                virtual void handleError(const std::string& p_error)
                    throw () = 0;
                virtual void handleUpdateAnchor()
                    throw () = 0;
            };

            /**
             * Request to update an anchor.
             *
             * @param p_contextID ID of the context holding the anchor to update.
             * @param p_anchorId  ID of the anchor to update.
             * @param p_params    Descriptor of the anchor to update.
             * @param p_anchorID  ID of the updated Anchor.
             */
            void requestUpdateAnchor(const ContextId p_contextId,
                                     const AnchorId p_anchorId,
                                     const AnchorParam& p_params,
                                     IUpdateAnchor* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Request to release an anchor.
             *
             * @param p_contextID		ID of the context owning the anchor.
             * @param p_anchorId		ID of the anchor to release.
             */
            void requestReleaseAnchor(const ContextId p_contextId,
                                      const AnchorId p_anchorId)
                throw (nettone::tools::Exception);

            /**
             * Request to link 2 anchors.
             *
             * @param p_contextID ID of the context owning the anchors.
             * @param p_anchorID1 The first anchor.
             * @param p_anchorID2 The second anchor.
             */
            void requestLinkAnchors(const ContextId p_contextId,
                                    const AnchorId p_anchorId1,
                                    const AnchorId p_anchorId2)
                throw (nettone::tools::Exception);

            /**
             * Request to break link between 2 anchors.
             *
             * @param p_contextID ID of the context owning the anchors.
             * @param p_anchorID1 The first anchor.
             * @param p_anchorID2 The second anchor.
             */
            void requestUnlinkAnchors(const ContextId p_contextId,
                                      const AnchorId p_anchorId1,
                                      const AnchorId p_anchorId2)
                throw (nettone::tools::Exception);

        private:
            /**
             * Remove a requester from the server.
             *
             * @param p_requester The requester to remove.
             * @param p_handler   Completion observer (optional).
             *
             * @note Must be called from a protected section.
             */
            void removeRequester(Requester* const p_requester,
                                 IRemoveUdpBridge* const p_handler = NULL)
                throw ();

            /**
             * Handle connection error with requesters.
             *
             * @param p_requester A requester that is in failure.
             */
            void handleRequesterError(Requester* const p_requester)
                throw ();

            /**
             * @var ContextMap m_contexts
             * Map of contexts indexed by context id.
             */
            struct ContextMapEntry {
                /**
                 * List of anchors associated with this context
                 */
                std::list<AnchorId> anchors;

                /**
                 * Real Context Id (send by requester).
                 */
                unsigned long externalId;

                /**
                 * Requester
                 */
                Requester* requester;

                /**
                 * Parameters associated to this context.
                 */
                ContextParam params;
            };
            typedef std::unordered_map<ContextId, ContextMapEntry> ContextMap;
            ContextMap m_contexts;

            /**
             * Get a new contextId and insert it in ContextMap
             *
             * @return a new ContextId
             */
            ContextId getAndInsertContextId()
                throw (nettone::tools::Exception);

            /**
             * Set information associted with Context Id, remapping Server::ContextId -> Requester::ContextId
             *
             * @param p_cid Internal context id
             * @param p_cid Requester point of view context id
             * @param p_req Requester
             */
            void setContextIdInfo(const Server::ContextId p_cid,
                                  const unsigned long p_rcid,
                                  const Requester* const p_req)
                throw (nettone::tools::Exception);

            /**
             * Set parameters associted with Context Id. (See requestSetContextParams)
             *
             * @param p_cid 	Internal context id
             * @param p_params  Context Parameters (see strucct ContextParam)
             */
            void setContextIdParams(const Server::ContextId p_cid,
                                    const ContextParam& p_params)
                throw (nettone::tools::Exception);

            /**
             * Get data associated with a contextId
             *
             * @param p_cid Internal context id
             *
             * @return Requester point of view context id and requester
             */
            const ContextMapEntry& getContextIdInfo(const ContextId p_cid) const
                throw (nettone::tools::Exception);

            /**
             * Remove a context Id from map
             */
            void removeContextId(const ContextId p_cid)
                throw (nettone::tools::Exception);

            /**
             * Remove all contextId associated to a requester
             */
            void removeContextIdFromRequester(const Requester* p_req)
                throw (nettone::tools::Exception);

            /**
             * Add an anchor to context' list
             *
             * @param p_cid context id
             * @param p_aid anchor id
             */
            void addAnchorToContext(const Server::ContextId p_cid,
                                    const Server::AnchorId p_aid)
                throw (nettone::tools::Exception);

            /**
             * Remove an anchor from context' list
             *
             * @param p_cid context id
             * @param p_aid anchor id
             */
            void removeAnchorFromContext(const Server::ContextId p_cid,
                                         const Server::AnchorId p_aid)
                throw (nettone::tools::Exception);

            /**
             * @var AnchorMap m_anchors
             * Map of anchors indexed by anchor id.
             */
            typedef std::pair<unsigned long, Requester*> AnchorMapEntry;
            typedef std::unordered_map<AnchorId, AnchorMapEntry> AnchorMap;
            AnchorMap m_anchors;

            /**
             * Get a new anchorId and insert it in AnchorMap
             *
             * @return a new AnchorId
             */
            AnchorId getAndInsertAnchorId()
                throw (nettone::tools::Exception);

            /**
             * Set information associted with Anchor Id, remapping Server::AnchorId -> Requester::AnchorId
             *
             * @param p_aid Internal anchor id
             * @param p_aid Requester point of view anchor id
             * @param p_req Requester
             */
            void setAnchorIdInfo(const Server::AnchorId p_aid,
                                 const unsigned long p_raid,
                                 const Requester* const p_req)
                throw (nettone::tools::Exception);

            /**
             * Get data associated with a anchorId
             *
             * @param p_aid Internal anchor id
             *
             * @return Requester point of view anchor id and requester
             */
            const AnchorMapEntry& getAnchorIdInfo(const AnchorId p_aid) const
                throw (nettone::tools::Exception);

            /**
             * Remove a anchor Id from map
             */
            void removeAnchorId(const AnchorId p_aid)
                throw (nettone::tools::Exception);

            /**
             * Remove all anchorId associated to a requester
             */
            void removeAnchorIdFromRequester(const Requester* p_req)
                throw (nettone::tools::Exception);

            /// @name Forbidden methods
            /// @{
            Server(const Server& p_other);
            const Server& operator =(const Server& p_other);
            /// @}

            /**
             * Lock used when accessing internal structure.
             */
            std::unique_ptr<nettone::tools::Mutex> m_lock;

            /**
             * Timesource.
             */
            std::unique_ptr<nettone::tools::ServerTimer> m_timesource;

            /**
             * The strategy selecting requester to handle requests.
             */
            std::unique_ptr<api::common::IStrategy> m_strategy;
        
            /**
             * @var Requesters m_requesters;
             *
             * Requesters handling UdpBridge instances.
             */
            typedef std::vector<Requester*> Requesters;
            Requesters m_requesters;

            /**
             * @var RequestersById m_requestersById;
             *
             * Requesters handling UdpBridge instances.
             */
            typedef std::unordered_map<UdpBridgeId, Requester *> RequestersById;
            RequestersById  m_requestersById;

            /**
             * Requesters Ids
             */
            std::unique_ptr<nettone::tools::IdManager<UdpBridgeId> > m_udpBridgeIds;

            /**
             * Contexts Ids
             */
            std::unique_ptr<nettone::tools::IdManager<ContextId> > m_contextIds;

            /**
             * Anchors Ids
             */
            std::unique_ptr<nettone::tools::IdManager<AnchorId> > m_anchorIds;
        };
    }
}


#endif // __UDPBRIDGE_API_SERVER_H__
