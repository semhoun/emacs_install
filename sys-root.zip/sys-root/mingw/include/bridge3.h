#ifndef __BRIDGE3_H__
#define __BRIDGE3_H__

#include "thread_utils.h"
#include "BeoBuf.h"
#include "sock_class.h"
#include "configurator.h"

/********************************** Connexion **********************************/

class Connexion3;
typedef adep_t <Connexion3> Connexion3A;

class Connexion3 : public adeo_mt_t
{

    /********************************************* types *********************************************/
/********/ private: /********/
    class Header
    {
    public:
        unsigned handle;
        bool query;
        Header(unsigned handle=handleQuery, bool query=true) : handle(handle), query(query) {}
        static const unsigned insert_size;
        void insert(BeoBuf& b) {
            b.write_int(handle);
            b.write_int(query);
        }
        void extract(BeoBuf& b) {
            handle=b.read_int();
            query=b.read_int();
        }
    };

    struct Bbal : public adeo_mt_t { // BeoBuf AirLock
        Airlock<BeoBufA> x;
        Bbal(void) {}
        Bbal(BeoBufA s) {
            x.put(s);
        }
    };
    typedef	adep_t<Bbal> BbalA;

    struct AirlockItem {
        unsigned handle;
        BbalA al;
        AirlockItem(unsigned handle=0, BbalA al=0) : handle(handle), al(al) {}
    };

    class AirlockTable
    {
        Connexion3* connexion;
        struct CompareAirlockItem {
            bool operator()(const AirlockItem a, const AirlockItem b) const {
                return a.handle<b.handle;
            }
        };
        set<AirlockItem, CompareAirlockItem> table;
    public:
        bool insert(AirlockItem& airlockItem);
        bool retrieve(unsigned handle, AirlockItem& airlockItem);
        void clear();
        void setConnexion(Connexion3* connexion) {
            this->connexion=connexion;
        }
        AirlockTable(Connexion3* connexion=0) : connexion(connexion) {}
    } airlockTable;
    friend class AirlockTable;

/*****/ protected: /*****/

    class SetBusy
    {
    public:
        sig_var_t<unsigned>& busy;
        SetBusy(sig_var_t<unsigned>& busy) : busy(busy)	{
            busy.m.lock();
            busy.x++;
            busy.m.unlock();
        }
        ~SetBusy(void)	{
            busy.m.lock();
            if ((--busy.x)==0) {
                busy.m.broadcast();
            }
            busy.m.unlock();
        }
    };

/*****/ public: /*****/

    class error : public msg_error_t
    {
    public:
        ERROR_PREFIX("Connexion: ")
        enum { connexion_closed	= 1	};
    };
    struct Message {
        unsigned handle;
        BeoBufA f;
        Connexion3A connexion;
        Message(Connexion3* connexion=0, unsigned handle=0, BeoBufA f=0) : handle(handle), f(f), connexion(connexion) {}
    };
    enum { handleQuery=0, handleFirstUsableValue=1 };

    /********************************************* variables *********************************************/
/********/ private: /********/

    mt_var_t<unsigned> currentHandle;
    static const unsigned BeoBuf_provision_internal;

/*****/ protected: /*****/

    sig_var_t<bool> online;
    sig_var_t<unsigned> busy;	// busy=true empèche de passe de l'état online=false à online=true

/*****/ public: /*****/

    Airlock<Message>* airlockMessage;
    adep_at userData;
    static const unsigned BeoBuf_provison;

    /********************************************* méthodes *********************************************/
/********/ private: /********/

    unsigned getNewHandle(void) {
        unsigned rv;
        currentHandle.m.lock();
        rv=++currentHandle.x;
        currentHandle.m.unlock();
        return rv;
    }

/*****/ protected: /*****/

    void waitNotBusy(void); /* si la connexion a déjà servi, waitNotBusy() doit être appelé avant setOnline() */
    void setOnline(void);

    virtual void reset(void) {
        airlockTable.clear();
    }
    void receiveData(BeoBufA& f);

    virtual bool transportData(BeoBuf& src)=0;

/*****/ public: /*****/

    bool isOnline(void);
    void setOffline (void);
    bool waitIsOnOffline(bool waitOnline, int delay_ms=0);

    void sendData(BeoBuf& src, BeoBufA* response, unsigned handle, bool* timedout=0, int delay_ms=0);
    virtual string transportId(void)=0;

    Connexion3(void) : currentHandle(handleFirstUsableValue-1), online(false), busy(0), airlockMessage(0) {
        airlockTable.setConnexion(this);
    }
};


/********************************** TcpConnexion3 **********************************/

class TcpConnexion3 : public Connexion3
{
    /********************************************* types *********************************************/
/*****/ public: /*****/

    class Header
    {
    public:
        enum typeIdent_t { handlePayload=1, handleKeepAlivePing=2, handleKeepAlivePong=3  };

        unsigned size, typeIdent;
        static const unsigned insert_size;

        void insert(BeoBuf& b) const {
            b.write_int(size+sizeof(typeIdent));
            b.write_int(typeIdent);
        }
        void extract(BeoBuf& b)      {
            size=b.read_int();
            assert(size>=sizeof(typeIdent));
            size-=sizeof(typeIdent);
            typeIdent=b.read_int();
        }

        Header(unsigned size=0, typeIdent_t typeIdent=handlePayload) : size(size), typeIdent((unsigned)typeIdent) {}
    };

    class ParamSet
    {
    public:
        int timeout_idle_ms, timeout_ping_ms, timeout_data_ms;
        ParamSet(void) : timeout_idle_ms(-2), timeout_ping_ms(-2), timeout_data_ms(-2) {};
    };

    class ReadThread : public thread_t
    {
    public:
        TcpConnexion3* tcpConnexion;
        ReadThread(TcpConnexion3* tcpConnexion=0) : tcpConnexion(tcpConnexion) {}
        void run(void) {
            try {
                tcpConnexion->read();
            }
            CATCH_STD_ERRORS("ReadThread")
        }
    } readThread;

/*****/ public: /*****/
    /********************************************* variables *********************************************/
    /*****/
private: /*****/
    mutex_t sock_write;
/*****/ public: /*****/
    sock_t sock;                    // pour TcpServerConnexion3 uniquement
    string addr_display;            // pour TcpServerConnexion3 uniquement
    static bool reverse_DNS_lookup; // pour TcpServerConnexion3 uniquement

    ParamSet paramSet;

    /********************************************* méthodes *********************************************/
/*****/ private: /*****/

    bool sendPacket(Header::typeIdent_t typeIdent, BeoBuf* src);

/*****/ protected: /*****/

    bool transportData(BeoBuf& src);

/*****/ public: /*****/
    static void getParamSetFromConf(ParamSet& paramSet, configurator_t& conf, string prefix="");

    void setOnline(void) {
        Connexion3::setOnline();    // pour TcpServerConnexion3 uniquement
    }

    void read(void);

    string hostname;
    int default_port;

    virtual void connect(void);
    TcpConnexion3(string hostname="", int default_port=0) : hostname(hostname), default_port(default_port) {}

    /****** virtual functions ******/
    void reset(void);
    string transportId(void) {
        return addr_display;
    }

};

typedef adep_t <TcpConnexion3> TcpConnexion3A;

class BasicTelnetConnexion : public adeo_mt_t
{
    /********************************************* types *********************************************/
public:
    class ParamSet
    {
    public:
        int timeout_ms;
        unsigned  bufSize;
        ParamSet(void) : timeout_ms(-1), bufSize(4096) {};
    };

    /********************************************* variables *********************************************/
/*****/ private: /*****/
    mt_var_t<bool> online;

/*****/ public: /*****/
    sock_t sock;
    string addr_display;
    static bool reverse_DNS_lookup;
    ParamSet paramSet;

    /********************************************* méthodes *********************************************/
/*****/ public: /*****/
    void read(void);
    void close(void) {
        sock.noex_close();
        online=false;
    }
    void setOnline(void) {
        online=true;
    }

    bool isOnline(void) {
        return online;
    }

    void remove_ctrl_char_in(char* s);
    void remove_ctrl_char_out(string& s);

    virtual string process_line(string param)=0;

};

class BasicTaggedTelnetConnexion : public BasicTelnetConnexion
{
public:
    virtual string process_cmd(string s)=0;
    string process_line(string param);
};

template <class CNX>
class GenTcpServerConnexion3 : public adeo_mt_t
{
    /********************************************* types *********************************************/
/*****/ public: /*****/
    class ListenThread : public thread_t
    {
    public:
        GenTcpServerConnexion3<CNX>* tsc;
        void run(void) {
            try {
                tsc->listen();
            }
            CATCH_STD_ERRORS("ListenThread")
        }
        bool start(bool assert_ok=true) {
            if (!thread_t::start(1,assert_ok)) {
                return false;
            }
            tsc->listening.lock();
            return true;
        }

        ListenThread(GenTcpServerConnexion3<CNX>* tsc=0) : tsc(tsc) {}
    };
    /********************************************* variables *********************************************/
/*****/ private: /*****/
    sock_t srv;
    mt_bool_t online;
/*****/ public: /*****/
    unsigned port;
    semaphore_t listening;
    class CNX::ParamSet default_paramSet;
    Airlock<adep_t<CNX>> airlockConnexion;
    /********************************************* méthodes *********************************************/
/*****/ public: /*****/

    void listen(void) {
        online=true;
        srv.listen(port,true,0);
        listening.unlock();
        while (airlockConnexion.wait_waiting()) {
            adep_t<CNX> connexion = new CNX;
            srv.accept(&connexion->sock);
            if (!online) {
                break;
            }
            connexion->addr_display=connexion->sock.get_peer_addr(true, connexion->reverse_DNS_lookup);
            connexion->setOnline();
            connexion->paramSet = default_paramSet;
            if (!airlockConnexion.put_and_wait(connexion)) {
                break;
            }
        }
        srv.noex_close();
    }

    void stop(void) {
        online=false;
        sock_t s;
        try {
            s.open("localhost",port);
            s.noex_close();
        }
        catch (...) {}
    }

    GenTcpServerConnexion3(unsigned port=0) : online(false), port(port), listening(0,1) {}
};

typedef GenTcpServerConnexion3<TcpConnexion3> TcpServerConnexion3;
typedef adep_t <TcpServerConnexion3> TcpServerConnexion3A;


class MultiSockClient
{
    /*********************************** variables ******************************/
private:
    vector<string> hostname;
    int current_host;
    mutex_t r_mtx, w_mtx, counter_mtx;
    signal_mutex_t queue_mtx;
    sig_bool_t connecting;
    unsigned counter;
    list<string> queue;
    sock_t sock;

public:
    mt_bool_t connected;
    int reconnect_delay_ms;
    int write_retry;
    int to_ms;
    string label;
    /*********************************** méthodes ******************************/
protected:
    //	void write(const char* buf, size_t n, long timeout_ms=-1);
    //	void print_str(const string buf, long timeout_ms=-1) { write(buf.data(),buf.size(),timeout_ms); }
    //	void readstr(char* buf, int n, char terminator='\n', long first_timeout_ms=-1, long next_timeout_ms=-1);

    bool write_cmd(string cmd);
    bool read_cmd(char* buf, int n);

public:
    string get_current_hostname(void) {
        return hostname[current_host];
    }
    void set_host(char const* hostname) {
        explode_vector(hostname, this->hostname, ' ');
    }

    void connect(void);
    string send_cmd_once(string cmd, bool expect_response=true);
    string send_cmd(string cmd, bool expect_response=true);

    MultiSockClient(void) : current_host(-1), connecting(false), counter(0), reconnect_delay_ms(1000), write_retry(1), to_ms(-1) {}
    ~MultiSockClient(void);
};

#endif
