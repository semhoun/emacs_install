#pragma once

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"

namespace api
{
	namespace common
	{
		/**
		 * Requester Interface
		 */
		class IRequester
			: public nettone::tools::ServerDeferred
		{
		public:
			/**
			 * Destructor.
			 */
			virtual ~IRequester()
				throw () {}

			/**
             * get the object Id.
             */
            virtual unsigned long getId() const
                throw () = 0;
		};
	}
}
