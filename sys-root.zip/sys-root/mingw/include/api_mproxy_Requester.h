#pragma once

#include "cpptools/nettone_tools_Exception.h"
#include "cpptools/nettone_tools_ServerDeferred.h"
#include "cpptools/nettone_codec_identifiers.h"
#include "cpptools/nettone_grpc_Server.h"

#include "api_common_IRequester.h"

// GRPC includes
//
#include <grpcpp/grpcpp.h>
#include <grpc/support/log.h>
#include <google/protobuf/message.h>

// IDL includes
//
#include "udpbridge_UdpBridgeGW.grpc.pb.h"

#include <vector>

// GRPC struct used to manage GRPC server
//
using grpc::Server;
using grpc::ServerAsyncResponseWriter;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using grpc::ServerCompletionQueue;

// GRPC struc and used to store data API defined in udpbridge_UdpBridgeGW.idl
//
using udpbridge::OpMode;
using udpbridge::Cap;
using udpbridge::LoadInfo;
using udpbridge::ResourceDesc;
using udpbridge::ContextParam;
using udpbridge::CodecName;
using udpbridge::AnchorParam;
using udpbridge::AnchorDesc;
using udpbridge::AnchorInfo;

// Grpc message used to request and reply
//
using udpbridge::BooleanReply;
using udpbridge::EmptyRequest;
using udpbridge::GetCapsReply;
using udpbridge::GetLoadReply;
using udpbridge::CreateContextRequest;
using udpbridge::CreateContextReply;
using udpbridge::SetContextParamRequest;
using udpbridge::ReleaseContextRequest;
using udpbridge::ReleaseAllContextsRequest;
using udpbridge::CreateAnchorRequest;
using udpbridge::CreateAnchorReply;
using udpbridge::UpdateAnchorRequest;
using udpbridge::ReleaseAnchorRequest;
using udpbridge::LinksAnchorRequest;
using udpbridge::UnlinksAnchorRequest;
using udpbridge::GetContextsInfoRequest;
using udpbridge::GetContextsInfoReply;



namespace api
{
    namespace mproxy
    {
        /**
         * Send request to one instance of udpbridge.
         */
        class Requester
            : public api::common::IRequester
        {
        public:
            /**
             * Constructor.
             */
            Requester(const nettone::grpc::Server::Endpoint& p_endpoint)
                throw (nettone::tools::Exception);

            /**
             * Destructor.
             */
            virtual ~Requester()
                throw ();


			/**
             * get the object Id.
             */
            virtual unsigned long getId() const
                throw ();

            /**
             * Return the name as a string.
             */
            const std::string getName() const
                throw();

            /**
             * Set the Endpoint GRPC server to contact 
             * Must be called before start
             */
            void setEndpoint(const nettone::grpc::Server::Endpoint& p_endoint)
                throw();
            /**
             * Get the endpoint (not const => allow update when instance changes its port)
             */
            nettone::grpc::Server::Endpoint& getEndpoint()
                throw();
            /**
             * Operating mode.
             */
            enum OpMode
            {
                /**
                 * Relay stream between anchors.
                 */
                Relay,

                /**
                 * Recording stream between anchors.
                 */
                Recording
            };
            typedef std::list<OpMode> OpModes;

            /**
             * Default error handler
             */
            class IHandler
            {
            public:
                virtual ~IHandler() {}

                /**
                 * Error kind.
                 */
                enum Error {
                    COMM_FAILURE,
                    REQUEST_FAILURE
                };

                /**
                 * @todo Comment.
                 */
                virtual void handleError(const Error p_error)
                    throw () = 0;
            };

            /**
             * Connection handle
             */
            class IConnect
                : public IHandler
            {
            public:
                virtual void handleConnect()
                    throw () = 0;
            };

            /**
             * TODO remove try to resolve the CORBA name by requesting the NameServer.
             * Must be the first service called.
             *
             * @return false if handler will never be called, it's NOT indicate an error
             */
            void requestConnect(IConnect* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * GetCaps handler
             */
            class IGetCaps
                : public IHandler
            {
            public :
                ~IGetCaps() {}

                virtual void handleGetCaps(const udpbridge::Cap& p_caps)
                    throw () = 0;
            };

            /**
             *  Class used to handle ping result
             */
            class IPing
                : public IHandler
            {
            public :
                ~IPing() {}

                virtual void handlePing()
                    throw () = 0;
            };

            /**
             * Used to know if distant grpc server is UP
             */
            void requestPing(IPing* const p_handler)
                throw (nettone::tools::Exception);

	    /**
	     * Class used to handle load info
	     */
	       
	    class IGetLoadInfo
		    : public IHandler
	    {
	    public:
		    virtual ~IGetLoadInfo() {}

		    /**
		     * Handle load info 
		     */
		    virtual void handleGetLoadInfo(const udpbridge::LoadInfo& p_loadInfo) = 0;
	    };
	    
	    /**
	     * Request to load info
	     */
	    void requestGetLoadInfo(IGetLoadInfo * const p_handler)
		    throw (nettone::tools::Exception);
		    
	    
            /**
             * Handler for notify create context result
             */
            class ICreateContext
                : public IHandler
            {
            public:
                virtual ~ICreateContext() {}
                virtual void handleCreateContext(const unsigned long p_contextId)
                    throw () = 0;
            };

            /**
             * Descriptor of the need for resource of a new context.
             */
            struct ResourceDesc
            {
                /**
                 * Count of anchors surely needed.
                 * Anchor creation requests will be satisfied.
                 */
                unsigned short lockedAnchors;

                /**
                 * Count of anchors that MAY be needed.
                 * This count is only a wish. Reserved anchors may be not
                 * available we anchor creation is requested.
                 */
                unsigned short requestedAnchors;
            };

            /**
             * Request to create a context.
             *
             * @param p_clientId		ID of the client requesting the operation.
             * @param p_resources		Describe the resources needed for the new context.
             * @param p_handler			Handler to notify when the result is available.
             *
             * @return The context id.
             */
            void requestCreateContext(const unsigned long p_clientId,
                                      const OpMode p_opMode,
                                      const ResourceDesc& p_resources,
                                      ICreateContext* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Handler for set context param result.
             */
            class ISetContextParam
                : public IHandler
            {
            public:
                virtual ~ISetContextParam() {}
                virtual void handleSetContextParam(const unsigned long p_contextId)
                    throw () = 0;
            };

            /**
             * Descriptor of context parameters.
             */
            struct ContextParam
            {
                /**
                 * Call Id from INCAS.
                 */
                unsigned long incasCallID;

                /**
                 * Call Id from MCMS.
                 */
                unsigned long mcmsCallID;

                /**
                 * Lines which ask to be recorded.
                 */
                typedef std::list<std::string> AskingLines;
                AskingLines askingLines;
            };

            /**
             * Set params of a context.
             *
             * @param p_contextID	ID of the context to set params.
             * @param p_params		Describe the parameters associated to the context.
             */
            void requestSetContextParams(const unsigned long p_contextID,
                                         const ContextParam p_params,
                                         ISetContextParam* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Request to release a context.
             *
             * @param p_contextId ID of the context to release.
             */
            void requestReleaseContext(const unsigned long p_contextId)
                throw (nettone::tools::Exception);

            /**
             * Request to release all client's context.
             */
            void requestReleaseAllContexts(const unsigned long p_clientId)
                throw (nettone::tools::Exception);

            /**
             * Additionnal codec parameter
             */
            struct CodecParam
            {
                /**
                 * Codec
                 */
                nettone::codec::CodecId codec;

                /**
                 * Payload value for this codec
                 */
                unsigned int payload;
            };
            typedef std::list<CodecParam> CodecsParam;

            /**
             * Descriptor of a anchor cration request.
             */
            struct AnchorParam
            {
                /**
                 * I/O mode.
                 */
                enum IOMode {
                    /**
                     * Read only : data are read on the anchor, routed, but no data can be sent through the anchor.
                     */
                    e_ioRead,

                    /**
                     * Write only : data are routed to the anchor, but no data are read from it.
                     */
                    e_ioWrite,

                    /**
                     * Both : data are read from and routed through the anchor.
                     */
                    e_ioReadWrite
                } ioMode;

                /**
                 * Kind of connection
                 */
                enum CnxMode {
                    /**
                     * Not connected mode
                     */
                    e_cnxLoose,

                    /**
                     * Auto learn, learn addr:port with n first packet
                     */
                    e_cnxAutoLearn,

                    /**
                     * Connected mode, use provided host and port
                     */
                    e_cnxConnected
                } cnxMode;

                /**
                 * Remote host address.
                 *
                 * Meaningful only when connected is true.
                 */
                std::string host;

                /**
                 * Remote host port.
                 *
                 * Meaningful only when connected is true.
                 */
                unsigned long port;

                /**
                 * Nb packet needed to learn an addr
                 *
                 * Meaningful only when mode is autolearn.
                 */
                unsigned long nbPacketToLearn;

                /**
                 * List of codecs param
                 */
                CodecsParam codecsParam;
            };

            /**
             * Descriptor of a created anchor.
             */
            struct AnchorDesc
            {
                /**
                 * Anchor ID.
                 */
                unsigned long anchorId;

                /**
                 * IP Address of the bridge.
                 */
                std::string bridgeAddress;

                /**
                 * UDP port on the bridge associated to the anchor.
                 */
                unsigned long bridgePort;
            };

            /**
             * Handler for notify create anchor result
             */
            class ICreateAnchor
                : public IHandler
            {
            public:
                virtual ~ICreateAnchor() {}
                virtual void handleCreateAnchor(const AnchorDesc& p_anchorDesc)
                    throw () = 0;
            };
            
            /**
             * Request to create an anchor.
             *
             * @param p_contextID ID of the context holding the new anchor.
             * @param p_params    Descriptor of the anchor to create.
             * @param p_anchorID  ID of the created Anchor.
             */
            void requestCreateAnchor(const unsigned long p_contextId,
                                     const AnchorParam& p_params,
                                     ICreateAnchor* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Handler for notify update anchor result
             */
            class IUpdateAnchor
                : public IHandler
            {
            public:
                virtual ~IUpdateAnchor() {}
                virtual void handleUpdateAnchor()
                    throw () = 0;
            };

            /**
             * Request to update an anchor.
             *
             * @param p_contextID ID of the context holding the anchor.
             * @param p_anchorId  ID of the anchor to update.
             * @param p_params    Descriptor of the anchor to update.
             * @param p_anchorID  ID of the updated Anchor.
             */
            void requestUpdateAnchor(const unsigned long p_contextId,
                                     const unsigned long p_anchorId,
                                     const AnchorParam& p_params,
                                     IUpdateAnchor* const p_handler)
                throw (nettone::tools::Exception);

            /**
             * Request to release an anchor.
             *
             * @param p_contextID		ID of the context owning the anchor.
             * @param p_anchorId		ID of the anchor to release.
             */
            void requestReleaseAnchor(const unsigned long p_contextId,
                                      const unsigned long p_anchorId)
                throw (nettone::tools::Exception);

            /**
             * Request to link 2 anchors.
             *
             * @param p_contextID ID of the context owning the anchors.
             * @param p_anchorID1 The first anchor.
             * @param p_anchorID2 The second anchor.
             */
            void requestLinkAnchors(const unsigned long p_contextId,
                                    const unsigned long p_anchorId1,
                                    const unsigned long p_anchorId2)
                throw (nettone::tools::Exception);

            /**
             * Request to break link between 2 anchors.
             *
             * @param p_contextID ID of the context owning the anchors.
             * @param p_anchorID1 The first anchor.
             * @param p_anchorID2 The second anchor.
             */
            void requestUnlinkAnchors(const unsigned long p_contextId,
                                      const unsigned long p_anchorId1,
                                      const unsigned long p_anchorId2)
                throw (nettone::tools::Exception);

        private:
            /// @name Forbidden methods
            /// @{
            Requester(const Requester& p_other);
            const Requester& operator =(const Requester& p_other);
            /// @}

            void initializeInternalStub()
                noexcept(false);

			/***
			 * Object Id.
			 */
			unsigned long m_id;

            /**
             * Suppported operating mode by udpbridge.
             */
            OpModes m_opModes;

            /**
             * Remote object.
             */
            std::unique_ptr<udpbridge::UdpBridgeGW::Stub> m_udpbridgeApi;

            /**
             * GRPC server endpoint
             */
            nettone::grpc::Server::Endpoint m_endpoint;
        };
    }
}

