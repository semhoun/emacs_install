#ifndef __DEOBUF_H__
#define __DEOBUF_H__

#include <errno.h>
#include <string.h>
#include "adex_class.h"
#include "base.h"
#include <netinet/in.h>
#include "msg_error.h"

#define DEFAULT_BEOBUF_SIZE 10240

class BeoBuf : public adeo_mt_t
{
    /************************************* variables *************************************/
public:
    char* bBuf, *bDat, *rCur, *wCur, *eDat, *eBuf; // beginning/end of buffer/data, curent (read/write) position
    bool autoDel;

    /************************************* types *************************************/
public:
    class error : public msg_error_t
    {
    public:
        ERROR_PREFIX("BeoBuf: ")
        enum { code_write_overflow = 1, code_read_overflow = 2, code_out_of_memory = 3, code_no_front_reserve = 3 };
    };

    /************************************* functions *************************************/
private:
    BeoBuf(BeoBuf&);
    BeoBuf& operator=(BeoBuf&);
    void zero(void) {
        bBuf=bDat=rCur=wCur=eDat=eBuf=0;
        autoDel=true;
    }

public:

    /*** read/write ***/

    char* write_skip(unsigned l);
    char* read_skip(unsigned l);

    void write(const char* p, unsigned l) {
        memcpy(write_skip(l),p,l);
    }
    void read (      char* p, unsigned l) {
        memcpy(p,read_skip(l),l);
    }

    static const unsigned sizeof_int;
    void write_int(int x) {
        *( (int*) write_skip(4) )=htonl(x);
    }
    int   read_int(void)  {
        return ntohl(*( (int*)read_skip(4) ));
    }

    void write_string(string s) {
        unsigned l=s.size();
        write_int(l);
        write(s.data(),l);
    }
    string read_string(void) {
        unsigned l=read_int();    // pas propre car x.data() est un "const char *"
        string x=string(l,'X');
        read((char*)x.data(),l);
        return x;
    }

    void write_BeoBuf(BeoBuf& b) {
        write(b.rCur, b.eDat-b.rCur);
    }

    /*** pointers ***/

    unsigned available_back(void) {
        return eBuf-eDat;
    }
    unsigned available_front(void) {
        return bDat-bBuf;
    }
    unsigned size(void) {
        return eDat-bDat;
    }
    void rewind(void) {
        rCur=wCur=bDat;
    }
    void rewindR(void) {
        rCur=bDat;
    }
    void rewindW(void) {
        wCur=bDat;
    }
    void append(void)  {
        wCur=eDat;
    }

    /*** alloc/unalloc, copies ***/

    void unalloc(void);
    BeoBuf* allocate(unsigned size = DEFAULT_BEOBUF_SIZE, unsigned provision=0);
    void alias_from(BeoBuf& b);

    BeoBuf(void)  {
        zero();
    }
    ~BeoBuf(void) {
        unalloc();
    }
};

typedef adep_t<BeoBuf> BeoBufA;

#endif
