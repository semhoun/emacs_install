// charset=utf-8
#ifndef __COWEP_H_
#define __COWEP_H_

#include "base.h"

// pour les curieux, cowep sont les initiales de Copy-On-Write Enabled Pointer, nom historique

#define CLONE_OBJ(my_type) clonable_t* clone(void) const { return new my_type(*this); }
#define CLONE_OBJ_ABSTRACT clonable_t* clone(void) const =0;

class clonable_t : public virtual object_t
{
public:
    virtual CLONE_OBJ_ABSTRACT
    inline virtual ~clonable_t(void)=0;
};
clonable_t::~clonable_t(void) {}

//! Système de gestion des pointeurs avec compteur de références et libération automatique
/*! \c T doit hériter de \c B, \c B doit être définie à ce niveau alors que \c T peut être une déclaration forward */
template <class T, class B=object_t>
class cowep
{
private:

    //! sert à compter le nombre de références vers l'objet
    /*! \c node pointe toujours vers un objet !=<tt>NULL</tt>, sauf peut-être temporairement au sein d'une fonction de <tt>cowep</tt>, mais jamais en sortie, de façon durable */
    class node_t
    {
        node_t(node_t&);
        node_t& operator=(node_t&);
    public:
        //! nombre de références
        int counter;
        //! pointeur vers objet lui-même
        T* p;
        node_t(T* p) : counter(1), p(p) {}
        ~node_t(void) {
            if (p) {
                delete static_cast<B*>(p);
            }
        }
    }* node;

    void del(void) {
        if (!--node->counter) {
            delete node;    // lÃ¢che le noeud
        }
    }

public:
    //! affectation: on pointe vers le même noeud et on incrémente son compteur de références
    cowep& operator=(const cowep& a) {
        if (a.node==node) {
            return *this;
        }
        del();
        node=a.node;
        node->counter++;
        return *this;
    }

    //! affectation d'un objet: on libère le noeud et on en crée un autre pour cet objet
    /*! ATTENTION, ne pas affecter un poiteur non libérable.<br>
     \verbatim int toto; mon_cowep=&toto;\endverbatim est invalide car <tt>delete &toto</tt> est impossible<br>
     \verbatim mon_cowep=mon_cowep.x();\endverbatim est invalide car l'affectation libère l'ancien objet de \c mon_cowep
     qui se trouve aussi être la nouvelle, donc on se retrouve avec un pointeur vers une zone libérée */
    cowep& operator=(T* p) {
        assert(!p || (node->p!=p));
        del();
        node=new node_t(p);
        return *this;
    }

    //! compare l'objet avec un pointeur vers un autre objet
    bool operator==(T* p) {
        return node->p==p;
    }

    //! lÃ¢che l'instance de l'objet, i.e. l'objet de sera pas libéré lors de la destruction du \c cowep
    T* drop(void) {
        assert(node->counter==1);
        T* t=node->p;
        node->p=0;
        return t;
    }

    //! renvoie un pointeur vers l'objet
    T* x(void) const			{
        return node->p;
    }

    //! renvoie un pointeur vers l'objet
    operator T* (void) const	{
        return node->p;
    }

    //! renvoie un pointeur vers l'objet
    T* operator ->(void) const	{
        return node->p;
    }

    //! construit un cowep qui prend en charge l'objet passé en paramètre
    cowep (T* p=0)		{
        node=new node_t(p);
    }

    //! constructeur de copie
    cowep (const cowep& a)		{
        node=a.node;
        node->counter++;
    }

    ~cowep(void)				{
        del();
    }
};

typedef cowep<object_t, object_t> object_pt;

#endif
